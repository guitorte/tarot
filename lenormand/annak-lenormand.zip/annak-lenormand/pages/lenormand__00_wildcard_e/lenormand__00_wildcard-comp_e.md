---
title: "lenormand | wild card | comparisons"
source: https://www.annak-tarot.at/lenormand/00_wildcard-comp_e.html
---

wild card - click it to flip it!

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Wild Card, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Gender**

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  | **Wild Card**: Genderqueer, non-binary. Androgenous. Anyone who prefers not to be labeled with their gender. |
|  |  |  | **The Men**: Male. Masculine. A man or boy (cis or non-cis) who identifies strongly with his gender. |
|  |  |  | **The Women**: Female. Feminine. A woman or girl (cis or non-cis) who identifies strongly with her gender. |

 **As persons**

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  | **Wild Card**: A specific genderqueer person. A person the querent doesn't yet know (is relevant for their concern). Wild card, oddball, the odd one out. |
|  |  |  | **The Men**: Specific men or boys. |
|  |  |  | **The Women**:Specific women or girls. |

 **Wondering, not understanding, confusion**

|  |  |
| --- | --- |
|  | **Wild Card**:  To wonder about something. To not understand something in the sense that there are no categories we could sort it into, so it's impossible to talk about it with precision - but we can actually see it clearly. To not understand something *yet*. |
|  | **Clouds**: To be confused about something. To not understand something because we lack clarity of mind, or because it conceils itself from us on purpose. Misunderstandings. |
|  | **Key**: The act (or experience) of understanding. The moment in which we transition from wondering about something to knowing the answer. |
|  | **Book**: To (intellectually) understand; to be able to explain something, sort it into categories. To be in possession of all the facts, so there's no more wondering. |

 **Ambivalence / ambiguity**

|  |  |
| --- | --- |
|  | **Wild Card**:  Something or someone *is* ambivalent or ambiguous in the sense that they don't fit into one category exclusively - they might fit into one category in some respects, into another in other respects, (etc.), but not fully in either. Something actually *is* ambiguous by nature. |
|  | **Crossroads**: Someone has ambivalent feelings about something - for in their view, this something has both good and bad aspects, pleasant and unpleasant aspects, so they can't give a black-and-white judgement on the issue, or find it difficult to make a clear decision for or against it. Something *looks* ambiguous to us. |
