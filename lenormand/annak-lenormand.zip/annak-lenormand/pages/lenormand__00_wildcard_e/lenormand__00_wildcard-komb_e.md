---
title: "lenormand | wild card | combinations"
source: https://www.annak-tarot.at/lenormand/00_wildcard-komb_e.html
---

**COMBINATIONS WITH THE
WILD CARD
- click it to flip it!**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Wild Card - Rider
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Something yet to come/happen; "I know something needs to be done but don't know what!"; a change already in the making but not quite palpable yet. To feel overwhelmed by a question mark (or question marks in general); someone tries to force an answer although there is no answer yet; to finally tackle something which hadn't been tackled yet. A (possibly genderqueer) person with the attributes of the Rider (see the Rider's keywords).

**Wild Card - Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A lucky opportunity not seized yet. To not take it too seriously that there is no answer (yet). Irresponsible handling of a major question mark; unwillingness to deal with a major question mark. *Not* a relevant or not a very important question mark. A (possibly genderqueer) person with the attributes of the Clover (see the Clover's keywords).

**Wild Card - Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Journey not taken yet; journey with an open route or open end. "I want to change but don't know how or in which direction yet!" Very definitely uncharted waters! To go explore although there is no clear idea *what*. To go where there is question marks; to go in search for an answer. A (possibly genderqueer) person with the attributes of the Ship (see the Ship's keywords).

**Wild Card - House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A home not made yet; a home in an unexpected place. The family that is waiting for us outside of the one we're born into. Something is not a habit or tradition yet. Yet unfamiliar. A plan not fixed yet. A question mark regarding one's home or family. A (possibly genderqueer) person with the attributes of the House (see the House's keywords).

**Wild Card - Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Something hasn't physically manifested yet. Something that is yet to grow. A question mark regarding one's body; a bodily need that hasn't yet come up but is already there. Something has not taken root quite yet; a root not discovered yet. A (possibly genderqueer) person with the attributes of the Tree (see the Tree's keywords).

**Wild Card - Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To not see the question mark; to be totally confused by something that can't be expressed or is indeterminate yet. There no despair yet; there's yet the possibility to prevent confusion or misunderstanding or getting lost. So much isn't fixed yet that there is disorientation. A (possibly genderqueer) person with the attributes of the Clouds (see the Cloud's keywords).

**Wild Card - Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A craving never followed yet. To be unaware - yet! - of what we truly want; to be, yet, directionless. To be motivated by something that can't be clearly expressed (yet). To strive for understanding the yet incomprehensible, for finding an answer to open questions, for directing the yet directionless, for fulfilling yet unfulfilled desires. Question mark regarding someone's desires, goals, motivations. A (possibly genderqueer) person with the attributes of the Snake (see the Snake's keywords).

**Wild Card - Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Something hasn't ended yet but the end is already in the making. Question mark regarding an end, regarding *how* something will end, or *what*. Something is buried deep down but we're not sure what it is. To suppress the knowledge that there's a question mark, that something is not determined yet. Loss of the sense of "open end" - now everything is fixed, defined. A (possibly genderqueer) person with the attributes of the Coffin (see the Coffin's keywords).

**Wild Card - Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
The ugly duckling. Something not pleasant or pretty yet; to be uninvited - yet; yet unsociable. A question mark regarding one's social life. It could be flattery or honest compliments - it's not clear yet. Not rewarded yet; not praised yet. To glorify indefiniteness or indetermination; to gloss over question marks. A (possibly genderqueer) person with the attributes of the Bouquet (see the Bouquet's keywords).

**Wild Card - Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To put an end to question marks; to cut off something (or someone) that is indeterminable. Question mark concerning what we will reap. Not yet ready to be harvested. A cut that hasn't happened yet. Still attached - yet. Yet untidy or cluttered. Yet inefficient. A question mark that comes up very suddenly and possibly unexpectedly. A (possibly genderqueer) person with the attributes of the Scythe (see the Scythe's keywords).

**Wild Card - Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A conflict in the making - although it is not conspicuous yet, or what it is about is still indeterminate. Who is to blame??? A yet hidden victim or perpetrator. Question mark regarding compensation, or punishment. To feel punished without knowing exactly how or why. An underlying conflict which is very important but indefinite yet. Open questions cause conflict; or: someone's indeterminableness, indefiniteness, causes conflict. A (possibly genderqueer) person with the attributes of the Whip (see the Whip's keywords).

**Wild Card - Birds![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)**
Open questions cause nervousness or worries. To be exited about something indeterminate. We know we should react quickly - but don't know how. Something important is hidden within the chaos. Someone's fickleness makes them very unpredictable, indefinite, undefinable. A situation which is chaotic makes it seem volatile - everything and nothing at once seems possible. Obsessive and unproductive brooding over open questions to which there just is no answer yet. A (possibly genderqueer) person with the attributes of the Birds (see the Bird's keywords).

**Wild Card - Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A child who is transgender or intersex. Open questions regarding a child or having children. Our inexperience leads to there being many things that seem indeterminate to us, or which we don't know yet at all. Something hasn't started yet. To think little of something only because there is noclear label for it. There is *something* there which is very important - but it's fragile! A playful approach to things which we don't have an answer to yet. A (possibly genderqueer) person with the attributes of the Child (see the Child's keywords).

**Wild Card - Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
We know we need to look after ourselves better - but we don't know how yet. A person with an identity that doesn't fit into readily available categories. Question mark regarding someone's self-care. To adapt to a situation which is very indeterminate. To survive (or do what is necessary) in indeterminate times. To tread cautiously when someone or something is unpredictable; to be suspicious of a person who is not predictable - or to suspect that they are not predictable. A (possibly genderqueer) person with the attributes of the Fox (see the Fox's keywords).

**Wild Card - Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A factor, while unknown to us, is still dominant. An influence which is there but we don't see it clearly yet. Not yet a parent/teacher/boss. Yet unprotected. Question mark regarding parent, teacher, or boss. When there are open questions, you need your parent, teacher, or boss, to guide you. Something which is yet indeterminate, or open, has a major influence on you. Ability to deal with question marks competently. A (possibly genderqueer) person with the attributes of the Bear (see the Bear's keywords).

**Wild Card - Stars [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Wishes, hopes, dreams which we haven't even voiced to ourselves yet. Something is already taking shape and will happen in the future but it is impossible to know it at present time. A dream we haven't tried to follow yet; a vision whose realisation we haven't attempted yet. A hope so vague we can't express it yet. Question mark regarding what we should aspire to. A (possibly genderqueer) person with the attributes of the Stars (see the Stars' keywords).

**Wild Card - Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A longing which is very strong but we can't see it clearly. A transformation which is happening but is intangible yet. Someone's true nature is unfathomable. An unknown factor which is nevertheless very relevant is transforming. To allow a transformation, or reorientation, even though the journey and/or goal is unknown. Question marks regarding a transition. Who know if X will return? To not know why something keeps reoccurring. A (possibly genderqueer) person with the attributes of the Stork (see the Stork's keywords).

**Wild Card - Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Question mark regarding someone's loyalties. To follow where the question marks lead. Please someone tell me what to do regarding this thing I don't see clearly! A friend who you don't yet know you already have, or, someone who you don't realise could be your friend. Support not yet received. Something or someone that can help with open questions. A (possibly genderqueer) person with the attributes of the Dog (see the Dog's keywords).

**Wild Card - Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A "no" which hasn't yet been said. A position of power that hasn't yet been taken. Something is not yet controlled. Excellence hasn't been reached yet. Pride or arrogance whose cause can't be quite understood; pride founded on something which is very real but can't be expressed. To look at a question mark rationally. To try to calculate rationally with an unknown factor (which is attempt likely to fail). Who has the power; who is controlling this??? A (possibly genderqueer) person with the attributes of the Tower (see the Tower's keywords).

**Wild Card - Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Not public yet; still in the closet. A very different culture or subculture that doesn't fit into what we already know. Social networks we are not part of yet. Teamworking is not yet going on. Public image as the oddball. To present as genderqueer; to come out as genderqueer. The unknown factor that influences or is behind a society, culture, subculture
A (possibly genderqueer) person with the attributes of the Garden (see the Garden's keywords).

**Wild Card - Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A very obvious, impossible-to-overlook, question mark. No one talks about the question mark; no one talks about the oddball. It's so outside of everything we are used to that it's impossible to express or talk about. Not permanent yet. It might still be moved. Not clear at all if it can ever be moved. An unknown factor might present an insurmountable hurdle. To silence or put hurdles in the way of genderqueer people. To try and block one's own genderqueerness.
A (possibly genderqueer) person with the attributes of the Mountain (see the Mountain's keywords).

**Wild Card - Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Extremely ambivalent; exceptionally undecided and/or indeterminate. The options can't yet be determined. An unknown factor influences someone's decision. Hesitation because of an unknown factor; to procrastinate an important decision because things aren't clear-cut (yet). Potentials yet unfulfilled. Multiple question marks; several issues are not clear-cut. Tolerance for questions unanswered yet.
A (possibly genderqueer) person with the attributes of the Crossroads (see the Crossroads' keywords).

**Wild Card - Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Something indeterminable is gnawing at you; a question mark is draining you. Dwindling wonder. The question mark(s) are become less (less pronounced). Someone is doing something bad behind your back, but you don't know who. Someone is putting on a poker face for harmful reasons. A mystery illness. To badmouth the oddball; to do or say things which harm genderqueer or gender-nonconforming people.
A (possibly genderqueer) person with the attributes of the Mice (see the Mice's keywords).

**Wild Card - Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To wonder about (someone's) love, or, more negatively, to question it. Someone loves us but we don't know it yet. There could be love for us but we haven't realised it yet. To love a person exactly for what they are. To have a soft spot for the oddball. Compassion or care from someone we don't expect it from. To fall in love with someone who is genderqueer. Loving (possibly romantic) relationships which don't fit into readily available relationship categories.
A (possibly genderqueer) person with the attributes of the Heart (see the Heart's keywords).

**Wild Card - Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A connection not yet made. Question mark regarding commitment, or regarding (the keeping of) a promise. A link or relationship is the unknown factor that influences the issue we've asked about. Questionable reliability. To commit to a genderqueer person. To share a quality that is hard to define; to share an oddity.
A (possibly genderqueer) person with the attributes of the Ring (see the Ring's keywords).

**Wild Card - Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To wonder about the truth; to question the facts. Question mark regarding our education. To (vainly) try and categorise something which just cannot be put into a specific category. To learn about what the unknown factors regarding our concern are. Conflict between thinking outside the box (Wild Card) and thinking inside the box (Book). Only some people have the knowledge that there are open questions still.
A (possibly genderqueer) person with the attributes of the Book (see the Book's keywords).

**Wild Card - Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Conversation about an open question. The express oneself clearly when there are still questions open. Someone expresses themselves in a way that is unusual, or hard to understand. Communication which is not clear-cut. Something hasn't been communicated yet. Communication about something that is hard to express. To try and communicate with someone who puts on a poker face. Communication about genderqueerness. Non-verbal expressions of genderqueerness.
A (possibly genderqueer) person with the attributes of the Letter (see the Letter's keywords).

**Wild Card - Man (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Man who is androgynous. Possibly: transgender or intersex man. A man does something with a genderqueer person. The oddball. A man wonders; to wonder about a man. A question mark regarding a man. A man is the unknown factor in the equation. Masculine in some ways but not in others. A man is important but we don't know which man.

**Wild Card - Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Woman who is androgynous. Possibly: transgender or intersex woman. A woman does something with a genderqueer person. The oddball. A woman wonders; to wonder about a woman. A question mark regarding a woman. A woman is the unknown factor in the equation. Feminine in some ways but not in others. A woman is important but we don't know which woman.

**Wild Card - Man (b)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Man who is androgynous. Possibly: transgender or intersex man. A man does something with a genderqueer person. The oddball. A man wonders; to wonder about a man. A question mark regarding a man. A man is the unknown factor in the equation. Masculine in some ways but not in others. A man is important but we don't know which man.

**Wild Card - Woman (b)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Woman who is androgynous. Possibly: transgender or intersex woman. A woman does something with a genderqueer person. The oddball. A woman wonders; to wonder about a woman. A question mark regarding a woman. A woman is the unknown factor in the equation. Feminine in some ways but not in others. A woman is important but we don't know which woman.

**Wild Card - (Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Unusual or uncommon sexual/sensual pleasures. Never lived out sexual passion. Great talent that hasn't been discovered or lived out yet. Not harmonious yet; not sated or satisfied yet. Atypical, non-conforming, sexuality. Question mark regarding sexuality; the unknown factor in one's sex-life. Very slowly dawning sexual awareness. Very slow process of realising that issue X contains many indeterminable aspects (and which these are). You need maturity to dare be the oddball. To feel attracted to the oddball, to a person who dares be who they are even if this is someone very unusual.
You are profoundly beautiful just the individual way you are!
A (possibly genderqueer) person with the attributes of the Sensual Lily (see the Sensual Lily's keywords).

**Wild Card - (Virtuous)Lily[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Question mark regarding the morality of something. A morally relevant issue that isn't clear-cut. Not peaceful yet; not pure yet. To wonder about the morality of something. Moral dilemmas. Morally correct handling of an unknown factor. In order to do the morally right thing you will have to think outside the box. Virtuousness isn't always obvious. Virtuousness from someone you didn't expected it from. To make a morally relevant issue out of genderqueerness. Fair treatment of genderqueer people.
A (possibly genderqueer) person with the attributes of the Virtuous Lily (see the Virtuous Lily's keywords).

**Wild Card - Sun [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
Conflict between something which is clear and obvious vs. something which is not clear-cut, indeterminate. Weirdly funny. There's great joy in something for you, but you haven't discovered it yet. An obvious question mark. An open question which isn't that important. To shine light on an unknown factor. Someone with strong oddball vibes. Someone broadcasts their genderqueerness confidently.
To spend a day with a genderqueer person.
A (possibly genderqueer) person with the attributes of the Sun (see the Sun' keywords).

**Wild Card - Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)**
Something is so profound that it's hard to grasp. Emotions which aren't clear-cut, or which we don't understand (yet). Emotions are the unknown factor which influences the concern we've asked about. To put a question to rest. A question mark influences the quality of our sleep. What our intuition says is often no clear-cut, and open to interpretation. An unknown factor of huge importance. To wonder about someone's emotions. We haven't rested yet (but we should).
A (possibly genderqueer) person with the attributes of the Moon (see the Moon's keywords).

**Wild Card - Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
A solution not reached yet; understanding that we don't yet have; liberation yet to happen; access that is yet being denied to us. To welcome someone's questions; to accept ambivalences, to accept when things aren't clear-cut. To be open for whatever is out there wanting to come in. Inclusiveness (in the social justice sense). The solution lies in something yet unknown to you.
A (possibly genderqueer) person with the attributes of the Key (see the Key's keywords).

**Wild Card - Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
It's not clear whether we would profit from X. The unknown factor that plays a major role for whether we profit or not. To wonder about the value of something. Something has value in a way we haven't realised yet. Profit that hasn't been made yet. To value question marks, to value things which don't fit inside the box. The distinct feeling that you mustn't let something slip through your fingers but you don't know what it is exactly you should be holding on to. Too many question-marks, too difficult to pin down.
A (possibly genderqueer) person with the attributes of the Fish (see the Fish's keywords).

**Wild Card - Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To sink one's teeth into a question mark or into something that isn't clear-cut. To focus on the unknown factor. Foothold that we haven't yet found. A person or issue everything revolves around - like the spider in a web - but you haven't realised it yet. Something is holding you back but it's not clear what this something is.
A (possibly genderqueer) person with the attributes of the Anchor (see the Anchor's keywords).

**Wild Card - Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
To question a dogma, an important principle, an ideology. Question mark regarding one's life task. A quest or calling we haven't followed yet. The strokes of fate we will suffer cannot be predicted. To struggle with one's oddball qualities, or with one's genderqueerness. The hardship genderqueer people face. Not convicted yet. The distinct feeling that we *should* do something but we don't know what.
A (possibly genderqueer) person with the attributes of the Cross (see the Cross's keywords).

**Wild Card - Wild Card[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)**
It just can't be answered right now! Everything is open; the unknown factor is very strong.
