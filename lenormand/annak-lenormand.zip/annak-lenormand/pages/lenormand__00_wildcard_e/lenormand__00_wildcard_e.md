---
title: "lenormand | wild card | keywords"
source: https://www.annak-tarot.at/lenormand/00_wildcard_e.html
---

**WILD CARD**
  -
**click it to flip it!**

*Note:*
Conventional Lenormand decks do *not* contain a Wild Card! If you want to keep your readings traditional, you might want to remove mine from your copy of the deck!

**Keywords**

***Nouns / phrases:***

Wild Card, joker, wildcard character. Also see paragraph [>> "as a person"](https://www.annak-tarot.at/lenormand/00_wildcard_e.html#person)! Something or someone which/who is indeterminable, doesn't fit into readily available categories, can't be pigeonholed or allocated. Question mark, open question, unknown factor. Whatever you feel it means; whatever you *need* it to mean!

 ***Activities:***

To wonder at/about something. To play hard to read; to put on a poker face. Activities for which there exist no categories; activities are going on but we're not sure yet what they are. Activities we *could* perform but haven't yet, or things we do without realising it. To do something with a person who has the attributes described below.

 ***Attributes:***

Genderqueer, transgender, intersex etc. Something yet indeterminate, indefinite, unknown. In combination with another card: the attributes of this other card are "yet un-/in-". Regarding a person with the attributes above.
 **As a person:**  Representative of the querent if they so wish. A person with the above attributes.
Somebody everything hinges upon. Somebody who is important for the querent's concern in a
way the querent isn't aware of yet. Oddball. Someone who is hard to read. Someone whose exact
characteristics, abilities, or motivations, we wonder about.
 **As advice:**
 If the card represents the querent: "It's about you!". Else: "Although
you don't know it yet this person/issue is very relevant for you!" Or: "There is
something you should realise!"

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Unknown or unknowable point of time or time scale. Not quite
yet but it will happen â probably. It could happen anytime. When or if it happens
depends on the issue/person the Wild Card represents.
