---
title: "lenormand | rider | comparisons"
source: https://www.annak-tarot.at/lenormand/01_rider-comp_e.html
---

rider

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Rider, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Change**

|  |  |
| --- | --- |
|  | **Rider**: Change is brought *to* us; changes that happen without our doing. Sudden or enforced changes. |
|  | **Ship**: Changes *we* set in motion. A change of environment. Changes which take some work. |
|  | **Stork**:Change in the form of a transformation. Inner change; e.g. change of heart. Changes dictated by the inner nature of things. Changes which happen gradually. |
|  | **Birds**: Constant change; nothing ever sticks - fickleness. Erratic changes. |
|  | **Anchor**: The opposite of change: stability or stagnation. Everything stays the way it is because we are able to maintain, are holding on to, or are restrained from changing, the status quo. |
|  | **House**: The opposite of change: regularity. Everything stays the way it is because we always act according to tradition or our personal habits, and/or don't allow innovation. |
|  | **Mountain**: The opposite of change: permanence. Everything stays the way it is because we won't budge. |

 **Haste**

|  |  |
| --- | --- |
|  | **Rider**:  Hurry, rush - especially in the sense of pressing someone or pressing for something, or of taking action quickly. |
|  | **Birds**: Bustle, hecticness. Superficial, quick acts which are quickly over. |
|  | **Lily**: The opposite of haste - to take one's time. Slowness. Very intense experiences. |
|  | **Tree**: The opposite of haste: very slow kind of person or way of acting - because of a great deal of physical and mental calm - or an unwillingness or inability to move quickly. |
|  | **Mountain**: The opposite of haste: the refusal to move at all, ever. |

**Suddenness/quickness**

|  |  |
| --- | --- |
|  | **Rider**: Quick in the sense of "hurried"; suddenness which overwhelms us because we were caught by surprise. |
|  | **Scythe**: Quick in the sense of sharp, efficient, "cutting". Suddenness which hurts us because we didn't have time to prepare. |
|  | **Birds**: Quick to react; quick-wittedness. Quick reactions to sudden occurrences. |
