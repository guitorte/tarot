---
title: "lenormand | rider | combinations"
source: https://www.annak-tarot.at/lenormand/01_rider-komb_e.html
---

**COMBINATIONS WITH THE
RIDER**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Rider-Rider[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Very surprising. Unexpected news or visitor; very sudden change. Someone is extremely pushy or intrusive. Someone's flamboyance is importunate. Hurried approach; offensive approach.

**Rider-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Something good happens. A chance, a very happy coincidence we should take advantage of. Something interrupts unburdened ease. Life-changing chance. Unexpected sense of ease; to be surprised by how easy something is. Don't take these news too seriously! Irrelevant change. Jokes that overstep boundaries.

**Rider-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Something or someone causes us to make changes in our life. To be pressed to change. Quick or hurried changes. Someone tries to force change. A foreigner. Someone is exploring in an intrusive way. A new acquaintance who will soon leave again. Someone is in a real rush - rushing in, rushing off. When in uncharted waters beware of unexpected things, or even attacks from unexpected angles. Overwhelmingly foreign; some new experience is overwhelming.

**Rider-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Invasion of privacy, home invasion. Fear of someone or something who/which is unfamiliar. Something or someone new or unfamiliar comes into the family / changes traditions / interrupts the life we are used to. Something which disrupts comfort. Change of rules (is needed). Forced change of plans. Yesterday's news. Someone comes (back) who we know very well. To be used to being pressured. Pushy family member. Pushy family. To be comfortable with change. Changes in the home/family. Change of habit(s).

**Rider-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Physical activities; sports; activities in nature. To push one's body; impositions on the body; forced movement/relocation. Virus; influenza. You need to deal quickly with physical issues! Something "attacks" one's energy levels or one's serenity. Invasion of someone's physical space. Uprooting. Unfamiliar/unexpected bodily process. Sudden demands of the body. Healthy activities.

**Rider-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To feel unprepared for what's happening; to not know what to do about what's going on. Confusing activities; hidden activities. Despair or confusion about a change. Uncertainty about what someone is pushing for, or what you should push for. Take action now against all this confusion! Hidden message; unclear message. A conceited poser; pretender. Someone is putting up a smoke-screen. Guideless/planless action. Act of desperation.

**Rider-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
A rival, rivalry, competition. To deal diplomatically and/or wisely with someone's advances or intrusive behaviour.
To try and make something happen, to will something into existence. Very sudden desire; to want something right now. Need for instant gratification - inability to delay gratification. Something or someone sneaks into querent's life.

**Rider-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
News which cause grief; news about an end, news which cause an ending. A loss which changes something or which changes everything. The pressure to repress something. Someone or something which helps one to let go (of grief). Overwhelming grief; someone else's grief is disrupting one's own happiness. Letting go allows change to happen. To repress one's flamboyant personality. Repression of activity.

**Rider-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Visitor (who's invited themselves?); a welcome change (or news); to invite change; social intrusiveness or presumptuousness. Greatly exaggerated or embellished news. Intrusive design or fragrance, flashy outfit. Overwhelming beauty. Something changes one's beauty standards. Obtrusive compliments or flirting.

**Rider-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Sudden and/or painful news; unexpected changes. Change which happens too quickly so it hurts. Something happens extremely quickly with no chance of prevention. Or: to quickly shut down someone's advances/attempts at meddling. To interrupt a message (an attempt to bring news, or change). To act quickly (before it's too late). Pushy person who cuts other's words off or interrupts/disrupts them constantly in other ways.

**Rider-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Attack, assault, aggression directed at the querent. Someone is a true cynic or who says hurtful things. Destructive change. Someone who brings destruction/violence with them. Soon there'll be consequences and you can do nothing to prevent it. (Possibly unwarranted but not necessarily negative) feedback. Someone who retaliates or tries to make good. Loud demands for justice. Revolts. An argument about someone's pushiness. A pushy way of arguing one's side. Abusive behaviour in the sense of pressuring someone to do something they don't want to do. Someone blames/accuses/shames someone else.

**Rider-Birds![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)**
Worries about news or changes; hurried or reasonably swift preparation to change. Chaotic/messy approach. Invasive thoughts, obtrusive chatting. Overwhelming chaos or hecticness. To react with alarm to someone's advances or a looming change. An intruder/news/change causes alarm or instability. Someone brings instability or chaos with them (e.g. spreading their own messiness all around). To be on constant lookout for attacks.

**Rider-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To overwhelm or press a child or an inexperienced/weak person. To react with curiosity to news or change. Beginning of change. To start an attack. Birth of a child - or of something abstract (like an idea, or plan etc.) An intrusive child. An unexpected pregnancy. Approaching birth (also metaphorically speaking!). Inexperienced attacker. Playful attacks; feint attack. Obtrusive or overwhelming helplessness or weakness. Someone enters one's life who brings a child with them, or a lack of experience, or a lot of curiosity/playfulness.

**Rider-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To distrust news; to be suspicious of a new person / a stranger; to defend oneself against influences from the outside; to defend oneself against being pressed. Something changes one's sense of self, one's identity. To adapt to change. Someone who wants things only for themselves, for their own benefits; who demands things that are useful for themselves only.

**Rider-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Preventative measures - any kind of protection against
any kind of intrusion
(mental, emotional, physical, medical - e.g. "to be on guard", "to set clear boundaries", alarm system, vaccination etc.). Dominant, presumptuous, meddlesome actions. News that make great impact; major change. New boss/teacher. Stepparent. Person who is extremely dominant and pushy, or: a very, very strong and determined leader.

**Rider-Stars [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To trust the news; to trust a stranger. To naively believe in the good of anybody who approaches, of anything new that one encounters. Faith that anything that happens will be good (or at least have a purpose). Spiritual believes are changed by something or someone. Obtrusive spirituality. To harass someone else with one's spiritual ideas. Witnessing. Holistic approach. To tackle something with a lot of faith.

**Rider-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Inner transformation because of pressure from outside. Things that happen(ed have) change(d) you. That which you've been longing for is approaching. Change of a longing. To long for change, for news, for something to happen. To push for relocation. Rushed transition. To tackle a longed for change. To act out of longing - because one's inner nature compels one to. The (possibly futile) attempt to hurry a long process. The (probably futile) attempt to interfere with a natural process. A returning visitor. To push for someone's return. Recurrence of harassment.

**Rider-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Intrusive or nosy friend. To urge or pressure a friend to do something. News about a friend; message from a friend. Friendly message. To follow whatever/whoever appears latest in one's life. Friend or employee is being harassed. To put pressure on someone in order to help them. To push for support. To permit someone to browbeat or push you around. Permission for an action. To step in and help.

**Rider-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To block someone's advances. To put up emotional defence against (bad) news or difficult changes. To not allow interference/meddling. Someone or something breaks through one's isolation/loneliness. To challenge/question someone's authority; attack on authority. Bravado or ostentation (or dazzling personality) doesn't impress.

**Rider-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
News channel, newspaper, anchorperson, journalist. Fast societal changes and developments. Someone is outed, something is made public. Public confrontation. To approach the public. To appear brash, obtrusive, or hurried, to others. To present oneself as speedy, flashy, active. Activities in social networks. To say it out loud when something/someone is overwhelming/too intrusive.

**Rider-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Difficult news. Sudden(unexpected) hurdles. To try and block change or react to someone's advances with stubborn silence. Difficult or challenging changes, bad news.
Blocked movement, something or someone is stuck; tension. To tackle something very actively. Boundaries are pushed. Intrusive presence; someone or something takes too much room.

**Rider-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Something or someone forces a decision. Clash of wills. Change brings choice. Changed options. Overwhelming freedom. Someone tries to interfere with our decision. The choice to act. To pursue an alternative. Obtrusive deliberations or speculations. Someone imposes their choices on others or pushes them to make a choice (even when they aren't ready). A new perspective. To be in two minds about someone who has just entered our life.

**Rider-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Loss of drive. Dwindling ardour. Pressure gets less. To yield to pressure. Burglary. To act in regard to something bad; to tackle something bad/corrupt. To get rid of some kind of infestation. Intrusion of something bad, something or someone brings corruption. Virus. Attack from behind. Someone approaches very sneakily; sneaky or dishonest approach.

**Rider-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Romantic advances. A
new love interest; to be asked out on a date; news about a lover. Someone or something has managed or might manage to soften you. To look at someone or something intrusive with (too much?) compassion or leniency. Someone has pushed their way into your heart. To have a soft spot for rascals. To break the news gently. A soft approach. Someone pushy vs. someone who won't push back. Love changes things.

**Rider-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
A rash promise or commitment; a rushed contract; to make a very sudden connection; to hook up with someone quickly. To act on a promise. Commitment to a certain activity. To be overly zealous; to pursue something with a lot of ardour. To push for commitment. A relationship is changed. News about a connection. A new connection. Predictable change. Association/union activities. The cause for change.

**Rider-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Academic pressure; scientific news; changes in one's education; new fact(s). To be overwhelmed by the truth; the truth seems "too much" to handle.
Intelligent approach. To be knowledgeable of what is to come. Facts with change things. Change of what's true.

**Rider-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Person who delivers a message; brings news; someone comes to you for a conversation. A conversation or information which will change things. News report. To communicate openly about how you feel about news/changes/someone's advances. Surprising information; to be blindsided by an unexpected conversation. To be unprepared for a conversation.

**Rider-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Man who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A man brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a man; to beset or harass a man. Attempts to change a man. A traditionally "male" approach.

**Rider-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Woman who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A woman brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a woman; to beset or harass a woman. Attempts to change a woman. A traditionally "female" approach.

**Rider-Man (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Man who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A man brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a man; to beset or harass a man. Attempts to change a man. A traditionally "male" approach.

**Rider-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Woman who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A woman brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a woman; to beset or harass a woman. Attempts to change a woman. A traditionally "female" approach.

**Rider-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Overpowering, overwhelming sensual input. Conflict between wanting to go slowly and things changing/happening very quickly. Welcome sexual advances; or sexual harassment. Flashy artist. A person who brags a lot about their artistic achievements, sexual expertise, or talents. A seducer/new lover enters querent's life. Sudden, or overwhelming, passion.

**Rider-(Virtuous)Lily[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Something or someone who challenges one's virtuousness. Someone who tries to force their moral standards on others. Something/someone changes that which one considers morally right. A new acquaintance who has good intentions. Annoyingly and/or obtrusively well-meaning/righteous/virtuous. Someone or something which disturbs the peace. Some news, or a change, or a person, who manages to disrupt one's self-discipline/constraint/chasteness.

**Rider-Sun [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Good news; someone or something brings welcome change; to be glad that something is finally happening. To feel pressed to always appear happy. Obtrusive happiness. Someone or something brings joy. Attack of someone's happiness. A joyful, easy approach. Fun activities. A very confident person; confidence.

**Rider-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)**
Emotionally unsettling news or changes. Profound change. Something or someone who brings fear with them; someone whose neediness is very importuning. Intrusive emotions. An emotional approach. Nightly activities. To act on one's emotions. Overwhelming intuition.

**Rider-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
To be wide open for anything that happens; to welcome change. To say yes to someone's offer to make a change. To allow someone to come close to you, or to unwisely let someone intrude too much. To open one's doors to attack. Unguardedness regarding intruders. In order for it to work you need to act swiftly! To be pressured to say yes. To push very hard to open something / get a yes / understand something. An understanding approach. To go where one is welcome. Unexpected relief. It's happening now!

**Rider-Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Changes in one's working life; news that concern one's financial situation. To feel pressed to be more generous. Someone or something is demanding a lot (or too much) of what is valuable. To push too much. Your approach is too intrusive! To grab at something quickly. Profitable news/change. To profit from a change.

**Rider-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
What used to be very stable changes drastically. Challenge or change of the status quo. Something or someone breaks the routine. To be freed from confinement. To wait for things to change. To try and hold on to routine when faced with change. Someone or something who/which brings suffering with them.

**Rider-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Fateful news. News about a stroke of fate or about a duty. Tidings that bring suffering. Terrible pressure or responsibilities are forced on you. Change of fate. Change of religion; challenge or even change of fundamental beliefs. Overwhelming suffering. Religious activities. Obtrusive religiosity.

**Rider - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)**
Something yet to come/happen; "I know something needs to be done but don't know what!"; a change already in the making but not quite palpable yet. To feel overwhelmed by a questionmark (or questionmarks in general); someone tries to force an answer although there is no answer yet; to finally tackle something which hadn't been tackled yet. A (possibly genderqueer) person with the attributes of the Rider (see the Rider's keywords).
