---
title: "lenormand | ship | comparisons"
source: https://www.annak-tarot.at/lenormand/03_ship-comp_e.html
---

ship

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Ship, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **(Not) settling down**

|  |  |
| --- | --- |
|  | **Ship**: Inability to settle down because of itchy feet, adventurousness, or commitment issues. To be "not there yet", to be on the way. |
|  | **House**: To settle *for* something; to be (or at least feel) at home somewhere. |
|  | **Anchor**: To stay put; to put down roots - to settle down. To stick with something or someone. |

 **Commitment**

|  |  |
| --- | --- |
|  | **Ship**: Inability to commit - possibly because we feel that there's so much else to discover yet. |
|  | **Ring**: Commitment. To be tied to someone or something. |

**Change**

|  |  |
| --- | --- |
|  | **Ship**: Changes we set in motion. A change of environment. Changes which take some work. |
|  | **Stork**:Change in the form of a transformation. Inner change; e.g. change of heart. Changes dictated by the inner nature of things. Changes which happen gradually. |
|  | **Rider**: Change is brought to us; changes that happen without our doing. Sudden or enforced changes. |
|  | **Birds**: Constant change; nothing ever sticks - fickleness. Erratic changes. |
|  | **Anchor**: The opposite of change: stability or stagnation. Everything stays the way it is because we are able to maintain, are holding on to, or are restrained from changing, the status quo. |
|  | **House**: The opposite of change: regularity. Everything stays the way it is because we always act according to tradition or our personal habits, and/or don't allow innovation. |
|  | **Mountain**: The opposite of change: permanence. Everything stays the way it is because we won't budge. |

**Departure; "gone"**

|  |  |
| --- | --- |
|  | **Ship**: Someone has literally gone away; departed in the sense of "gone on a journey". Someone is absent but might return; something is missing but might be found. |
|  | **Coffin**:Someone is gone - as in "dead". The experience of a very painful and permanent loss. Something is over for good. |
|  | **Scythe**: Sudden, painful, or "efficient" (wasting neither time nor effort), departures. Someone cuts themselves out of our life; cuts us off. |
|  | **Mice**: Something is gone in the sense that it has been taken away, stolen. "Departure" in the sense of sneaking away, or as a slow process of dwindling away. |

 **Longing**

|  |  |
| --- | --- |
|  | **Ship**: Longing in the sense of wanderlust - the longing to be elsewhere, to discover new places. |
|  | **Stork**:Deep longings in general, but especially the longings which arise from our inner nature. |
|  | **Heart**: Romantic longing. |
|  | **Lily**: Sexual longing; the longing for sensual experiences. |
|  | **Snake**: Longing in the sense of cravings - to want to get or to achieve something. |
