---
title: "lenormand | ship | keywords"
source: https://www.annak-tarot.at/lenormand/03_ship_e.html
---

**SHIP 3**

**Keywords**

***Nouns / phrases:***

Departure, farewell. Absence. Voyage, journey, venture, adventure.
(Long) distance, international. There's a gap between where we are and
where we want to be. We are not there yet. Adventurous, new places (literally
and figuratively speaking). Change of environment. Changes that we set in motion
ourselves. Exploration, experimental probing, research, investigation, a search
for something or someone. Atmosphere of departure, wanderlust. Lack of commitment;
unwillingness (or inability) to stay. For some also: Commerce, business,
moving vehicles.

 ***Activities:***

To depart, say good-bye. To travel, have an adventure, venture. To make a change, set
change in motion. To explore, probe, research, investigate, look for something or someone. To
fidget, to not settle down, to not commit.

 ***Attributes:***

Departed (in the sense of "gone away"), absent, missing, very distant, international.
Travelling, not there yet, on the way. (Ad)venturous. Foreign, new, yet to be explored. Explorative,
investigative, seeking, searching. Full of wanderlust; fidgety, ready to leave. Not committed.
 **As a person:**  Someone with the above qualities. A traveller. Someone who won't stay (long) or
who is often away. Someone with a job to do with travelling.
 **As advice:**
 Just give it a go; explore! Make a change! Leave! Negatively: Isn't it maybe time to
commit? Wouldn't it be good to stay put for a while?

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   It is / you are on the way, but it's not going to happen quite yet.

 **See also** the *annakblogs* article [>> So, is the Ship a positive or negative card?](https://annakblogs.wordpress.com/2017/10/03/light-shadow-ship/)
