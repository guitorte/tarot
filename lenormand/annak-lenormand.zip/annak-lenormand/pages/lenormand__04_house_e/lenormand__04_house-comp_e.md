---
title: "lenormand | house | comparisons"
source: https://www.annak-tarot.at/lenormand/04_house-comp_e.html
---

house

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the House, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Regularity and stability**

|  |  |
| --- | --- |
|  | **House**: Things are stable and regular because tradition isn't questioned, habits are fixed, and rules are kept. |
|  | **Tree**: Stability comes from within oneself:, from a sense of inner strength and energetic balance, from a strong sense of belonging. Stable health. |
|  | **Anchor**: Stability and regularity are present because of an adherence to routines, or because we are stuck in the same place where nothing ever changes. |
|  | **Birds**: The opposite of stability and regularity: instability and chaos. |

 **Exclusion**

|  |  |
| --- | --- |
|  | **House**: The exclusion of anyone and anything that is unfamiliar or different. |
|  | **Tower**: The exclusion of others from one's emotional life and thoughts, or from one's private sphere in general. |
|  | **Book**: The exclusion of some from specific knowledge. |
|  | **Key**: The opposite of exclusion: inclusion, welcome, acceptance. |

**(Anti) innovation**

|  |  |
| --- | --- |
|  | **House**: Opposition to innovation; conservatism. Everything should stay as it has always been. |
|  | **Key**: The prerequisite for innovation: the mental and emotional openness needed for inspiration, ideas, inventions. |
|  | **Child**: Innovation - the introduction of new things. |
