---
title: "lenormand | house | keywords"
source: https://www.annak-tarot.at/lenormand/04_house_e.html
---

**HOUSE 4**

**Keywords**

***Nouns / phrases:***

Home (life), home country. Family (members).Privacy, private
affairs. Establishment, settling down. Familiarity, familiarization, (nonsexual!)
intimacy. Close-mindedness: fear of the new/unfamiliar. Xenophobia. Order,
regularity, simple structures, plans, low risk, safety. Normality, conventionality,
tradition(al views), conservatism. Confirmed habits; matters of habit. Preservation,
conservation. Restrictive traditions; blocking of innovation; inflexibility.

 ***Activities:***

To make oneself a(t) home, start a family. Activities at home or with
the family. To settle for something/someone, to establish oneself (or someone). To keep something private; keep away the public.
To familiarize, be used to, be at home with. To block innovations/changes; fear the unfamiliar,
keep out strangers. To order, regulate, keep it simple, plan, reduce risks. To feel safe. To follow
tradition, conserve, preserve. To act habitually.

 ***Attributes:***

Homey/homelike, native. At home (with). Familial. Long established, settled. Private,
intimate, familiar. Close-minded regarding the unfamiliar; xenophobic. Proper, orderly, normal,
regular, regulated, simple, simply-structured, well-planned, low-risk. Habitual, conventional, traditional,
accustomed. Conservative, conserving. Restrictive, inflexible, anti-innovative.
 **As a person:**  Person with the above attributes, esp.: traditional, conservative; strict - doesn't
bend the rules. Person with very confirmed habits. Family member.
 **As advice:**
 Keep it private! Familiarise yourself with it! Settle down! Preserve that which is good!
Negatively: Don't block innovation; let the unfamiliar in!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Long time spans; always; forever. When it usually happens. Family time.

 **See also** the *annakblogs* article [>> So, is the House a positive or negative card?](https://annakblogs.wordpress.com/2017/10/10/light-shadow-house/)
