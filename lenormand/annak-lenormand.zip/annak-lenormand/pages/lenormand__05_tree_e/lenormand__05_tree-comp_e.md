---
title: "lenormand | tree | comparisons"
source: https://www.annak-tarot.at/lenormand/05_tree-comp_e.html
---

tree

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Tree, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Stability/regularity**

|  |  |
| --- | --- |
|  | **Tree**: Physical stability. Stability caused by a strong sense of belonging; stable health. |
|  | **House**: Things are stable and regular because tradition isn't questioned, habits are fixed, and rules are kept. |
|  | **Anchor**: Stability and regularity are present because of an adherence to routines, or because we are stuck in the same place where nothing ever changes. |
|  | **Birds**: The opposite of stability and regularity: instability and chaos. |

 **Energy**

|  |  |
| --- | --- |
|  | **Tree**: Physical energy. Energy in the sense of vitality. Life-force. To feel energetic in the sense of fit and healthy. |
|  | **Lily**: Sexual energy; sex drive. Sensual passion. |
|  | **Birds**:  Nervous and unstable energy; energy fluctuations. |

**Growth**

|  |  |
| --- | --- |
|  | **Tree**: Something is thriving; slowly but constantly growing. |
|  | **Child**:  The very first stage of (or the initiation of) a growing process. Something is (yet) small and possibly weak. |
|  | **Lily**: Something has matured, is ripe. |
|  | **Scythe**: Disruption of a growing process. Or: to harvest that which is ripe. |
|  | **Mice**: Stunted growth. Possibly even: decline, decay, loss. |
|  | **Coffin**: End of growth - physical or metaphorical death. |

**(Foot)hold**

|  |  |
| --- | --- |
|  | **Tree:** We have foothold in the sense that we feel firmly, securely, rooted - because we have, metaphorically speaking, both feet firmly on the ground, or because we have built on a stable foundation. Definitely positive. |
|  | **Anchor:** We have foothold in the sense that we are able to maintain a certain status, are holding on to something, or even clinging to something, "hooking into something" like an anchor does into the sea bed. Possibly (not necessarily) an unproductive, negative thing to do. |

**Inflexibility**

|  |  |
| --- | --- |
|  | **Tree**... maybe would like to be more flexible but can't. Someone is inflexible because they are so deeply rooted, or because their inner nature is so calm and relaxed that they are unable to move or change quickly. |
|  | **Mountain**...  could bend but won't. Someone is inflexible out of sheer stubbornness or spite. |
