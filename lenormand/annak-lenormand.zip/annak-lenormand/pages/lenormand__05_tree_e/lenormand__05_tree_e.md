---
title: "lenormand | tree | keywords"
source: https://www.annak-tarot.at/lenormand/05_tree_e.html
---

**TREE
5**

**Keywords**

***Nouns / phrases:***

Nature, our relationship with nature. The physical world, materialism,
(laws of) physics, biology. Body(relationship); the body's needs and
functions, physical activities. Life, vitality, slow, but constant growth, thriving,
life-force, strong and very stable energy, energy reserves. Roots, grounding. Belonging,
ancestry. Steadfastness, robustness. Inflexibility: lack of physical manoeuvrability,
occupational immobility, lack of interest in travelling, unwillingness
to move house, inability to rethink. Opposite of spiritualism and intellectualism
â pragmatism. Down-to-earth life style; focus on bodily needs/functions.

 ***Activities:***

To do things in/with nature; to create physical objects. To do something for the body
or with the body (e.g. sports). To live, grow, thrive, mature. To (en)root, ground oneself, belong.
To have both feet firmly on the ground. To be inflexible, e.g. to not move on/away; to not change
one's thinking.

 ***Attributes:***

Natural, physical, physiological, material, biological. Alive, living, vital, growing, thriving.
Bodily. (Deep)rooted, enrooted, grounded, belonging, ancestral. Steadfast, robust, healthy.
Inflexible in the sense of not versatile. Down-to-earth, pragmatic. **As a person:**  Someone with the above qualities. Especially: someone down-to-earth, deeply rooted
or calm, but full of vitality. An ancestor.
 **As advice:**
 Stop overthinking! Stop living in a fantasy world, let go of pseudo-scientific woo! Take
care of the human/bodily basics! Negatively: Don't obsess over your body! Try to be a bit more
versatile.

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Long time spans, traditionally: a year. Slowly, but constantly. All of one's life.

 **See also** the *annakblogs* article [>> So, is the Tree a purely positive card then?](https://annakblogs.wordpress.com/2017/10/17/light-shadow-tree/)
