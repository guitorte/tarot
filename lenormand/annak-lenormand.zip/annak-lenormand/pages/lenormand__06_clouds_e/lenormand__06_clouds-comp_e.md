---
title: "lenormand | clouds | comparisons"
source: https://www.annak-tarot.at/lenormand/06_clouds-comp_e.html
---

clouds

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Clouds, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Mental/emotional problems:**

|  |  |
| --- | --- |
|  | **Clouds**: Problems which arise from a clouded view of reality, e.g. misunderstandings; lack of understanding, disorientation; illusionary thinking, hallucination, or paranoia. Also: Abandonment issues (because of the "lack of guidance" aspect of the card). |
|  | **Moon**: Mental/emotional issues to do with the "dark" part of our soul - fear, sadness, needs. E.g. phobias, depression, PTSD. Also: Sleep disorders. |
|  | **Birds**: Issues to do with extreme stress, worries, difficulties with concentration: e.g. nervousness, anxiety, obsessive compulsive behaviour, ADHD. |

 **Secrets**

|  |  |
| --- | --- |
|  | **Clouds**: Something is being hidden from view, fogged over - not necessarily with bad intentions, possibly just for self-protections or out of shame. |
|  | **Mice**: Harmful and/or malicious secrecy. Something is being done behind someone's back. Sneakiness. |
|  | **Book**: A "secret" in the sense of esoteric knowledge - not everyone has access to some type of knowledge or information. |
|  | **Birds**: To blab a secret. |
|  | **Key**: The opposite of secretiveness: openness, straightforwardness. Or: to find access to a secret. |

**Need for guidance/leadership**

|  |  |
| --- | --- |
|  | **Clouds**: In a situation of disorientation guidance would be needed to get out of confusion and prevent despair. Both Bear and Tower could help a lot here but in the end mightn't help with becoming self-reliant and might thus keep the querent in dependence on their leadership. |
|  | **Child**: When there is a lack of experience leadership in the form of gentle guidance and support is needed to gain experience safely. Bear might be too loud or over-protective; Tower too strict and cold - a good dose of Dog would help while Dog only might be too weak. |
|  | **Bear**: Strong, charismatic, warm-blooded, and personally involved leadership/guidance. |
|  | **Tower**: Cool, impersonal, impartial guidance/leadership. |
|  | **Dog**: A person who can only (emotionally) support and help but isn't able to guide or lead. |
