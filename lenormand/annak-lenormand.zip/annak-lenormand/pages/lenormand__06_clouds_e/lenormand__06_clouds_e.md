---
title: "lenormand | clouds | keywords"
source: https://www.annak-tarot.at/lenormand/06_clouds_e.html
---

**CLOUDS
6**

**Keywords**

***Nouns / phrases:***

Clouds, bad weather. (Figurative) fog; a fogged mind. Coverups,
smoke screens, pretence, hidden things, secrets. Vagueness, disorientation.
No points of reference. Lack of standpoint; unclear position. Lack of guidance or
guidelines. Confusion, no answers. Misunderstanding, self-deception. Insecurity,
uncertainty, doubts, despair, hopelessness. Indifference, disinterest. Numbness,
spiritlesss. Stupor, thick-wittedness. Dullness, boredom, listlessness, aimlessness,
futility.

 ***Activities:***

To cloud, fog, cover something up, veil, hide, pretend. To disorient; feel lost, go astray.
To find no points of reference; not know where we stand; wander around guideless. To not see
reality. To not understand, misunderstand, confuse, deceive oneself. To be or make insecure;
doubt, lose hope, despair. To show indifference. To numb (oneself), bore someone.

 ***Attributes:***

Clouded, fogged (over), pretended, covered up, veiled, hidden, secret. Vague, unclear,
disoriented, disorienting, stray, lost, guideless. Indifferent, disinterested. Numb, spiritless. Bleary,
obtuse. Dull, bored, listless, aimless, futile. Confused, unanswered. Confusing, misleading,
deceptive, self-deceived. Uncertain, doubtful, desperate, hopeless. **As a person:**  Person with the above attributes. A shady character. Someone the querent can't see
/ doesn't see as who they really are. A bore.
 **As advice:**
 As advice: Get rid of self-deception! Admit your ignorance or confusion; ask for information
or guidance! In rare cases, positively: Hide it! Pretend!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   No sense of time. Unclear time spans.

 **See also** the *annakblogs* article [>> So, is the Clouds a purely negative card, then?](https://annakblogs.wordpress.com/2017/10/24/light-shadow-clouds/)
