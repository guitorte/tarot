---
title: "lenormand | snake | comparisons"
source: https://www.annak-tarot.at/lenormand/07_snake-comp_e.html
---

snake

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Snake, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Knowledge**

|  |  |
| --- | --- |
|  | **Snake**: Thirsty for knowledge. "I want to know!" |
|  | **Book**: Knowledgable; educated. "I know this!" |
|  | **Bear**: Capable. "I know how to do this!" |

 **Selfishness**

|  |  |
| --- | --- |
|  | **Snake**:Selfishness in regard to goal-achievement - in order to get what we want we're willing to sell our own grandmother. |
|  | **Fox**: Selfishness in regard to our needs - we look after our own needs to the exclusion of the needs of others. |

 **Intelligence**

|  |  |
| --- | --- |
|  | **Snake**: Diplomatic intelligence, great rhetoric; acumen; ability to direct (even manipulate) others. |
|  | **Fox**: To be street-wise. Cunning; and the intelligence of knowing when to risk something and when not to. |
|  | **Book**: Intelligent in the sense of well-educated, knowledgeable. |

**Sexuality**

|  |  |
| --- | --- |
|  | **Snake**: "I want sex!" Strong sex drive. To use sex as a means to an end. Seduction. |
|  | **Lily**: "I enjoy sex!" Sexual passion, maturity, experience. A purely sexual relationship. |
|  | **Child**: "I haven't had (much) sex (yet)." Sexual immaturity, inexperience, innocence. |
|  | **Lily**: "I don't have sex!" Sexual abstinence. Possibly: frigidity, prudery. |

 **Power**

|  |  |
| --- | --- |
|  | **Snake**: Power-hungry. To direct or manipulate others. |
|  | **Bear**: Powerful, dominant. To command others. |
|  | **Tower**: Authoritative, in a position of authority. To control others. |

 **Longing**

|  |  |
| --- | --- |
|  | **Snake**: Longing in the sense of cravings - to want to get or to achieve something. |
|  | **Ship**: Longing in the sense of wanderlust - the longing to be elsewhere, to discover new places. |
|  | **Stork**: Deep longings in general, but especially the longings which rise from our inner nature. |
|  | **Heart**: Romantic longing. |
|  | **Lily**: Sexual longing; the longing for sensual experiences. |

**Sense of direction**

|  |  |
| --- | --- |
|  | **Snake**: Strong sense of direction; clear goal; singlemindedness. |
|  | **Crossroad**: Hesitation, ambivalence; several alternatives are being considered. |
|  | **Clouds**: Disorientation; to go astray. No points of reference. Indifference. |
