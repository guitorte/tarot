---
title: "lenormand | snake | combinations"
source: https://www.annak-tarot.at/lenormand/07_snake-komb_e.html
---

**COMBINATIONS WITH THE
 SNAKE**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Rider-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html) ![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)**
A rival, rivalry, competition. To deal diplomatically and/or wisely with someone's advances or intrusive behaviour.
To try and make something happen, to will something into existence. Very sudden desire; to want something right now. Need for instant gratification - inability to delay gratification. Something or someone sneaks into querent's life.

**Snake-Clover[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
A desire which isn't that strong/important. To gamble/to take risks because you want something so desperately. To use a playful approach to get what you want. A wonderful chance to get what you want. A strong craving is not taken seriously; an inner calling is not followed as much as it maybe should be. To make light of an addiction, of ruthlessness, or selfishness. Someone's attempts at manipulation are met with light-hearted humour. Or: to be unable to move towards a goal constantly and with concentration; more generally: lack of strength of purpose.

**Snake-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Strong desire to leave, strong desire to discover new territory, to experience new things. Exploration of one's desires. To search for what we truly want. The empowerment to explore.
Travel guide. Sexual exploration. To begin an affair / a sexual relationship with parameters yet unknown. Extremely strong wanderlust. To really want to reach the end of a journey. That which is the goal of a venture. To put everything we have into making a change happen. To search for knowledge. To leave everything behind which is not conducing to reaching our goal. Reckless adventurousness. To not commit out of reckless selfishness.

**Snake-House[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
The person who is pulling the strings in the family. To crave a family, a safe home, and to do everything to get it. To be comfortable ("at home") in situations where diplomacy is needed; to be familiar and comfortable with power and/or sex. To rely on traditional (gender)rules to get what you want. A conflict between something you crave and the family's wishes; or a conflict between your true desires and a traditional lifestyle. To work towards the goal by following a plan.

**Snake-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To destroy one's own (or others') mental/physical health through ambition; a warning to avoid burnout caused by trying to achieve too much. To commit to an in-depth workout-program for the benefit of one's health. The goal: health/fitness. Physical ambitions. To research one's roots (ancestors, family connections, family affairs etc.). Strong physical cravings/needs. To follow the path to one's goal calmly but very steadily. Healthy ambition. Once a goal is set, it's difficult for us to change direction. Addictive behaviour which has to do with our body, e.g. anorexia, bulimia, but also addiction to exercise etc.

**Snake-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To lose our sense of direction; to go astray. Unnecessary detours. Goal is unclear. To slowly make one's way out of confusion by diligence and hard work. To persevere even in times of confusion. Someone's desires or motives are unclear (and maybe they're hiding them on purpose). Someone uses deception to reach their goal. Manipulation. The ambition to become more knowledgeable, to understand better. The use of rhetoric tricks to conceal what is really being said.

**Snake-Snake[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To be highly motivated by sex/power/knowledge. Selfish goals. *Extremely* strong ambition or craving. Someone is 100% willpower; highest level of self-empowerment.

**Snake-Coffin[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To bury your ambition or a desire; to not let your sexuality live. To have to submit to someone or something. A craving ends / to give up a goal. To put an end to something tactfully. An affair ends. To be drawn to death; to be suicidal.

**Snake-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
The use of flattery to  get something, to manipulate somebody. To be happy and proud of your own achievements. To crave (loving) attention, admiration, or a more active social life. To be very adept in social settings. To put a lot of effort into looking nice.

**Snake-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To stop being so ambitious; to discontinue a career. To stop before the goal is reached. To work very hard towards reaching the finish line. Sudden cravings. Binge drinking/eating. A warning: be careful about what you reach for - you might get hurt!

**Snake-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Sneaky or very diplomatic and clever or even wise ways to criticise. The craving to inflict pain on others; sadism - or to crave pain; masochism. To have a habit of seeking out abusive relationships or painful situations. To deal with aggression in a wise way. To seek justice. Judge; mediator; anti-violence counsellor. To feel ashamed for one's desires; to shame others for their desires. Accusations of recklessness or selfishness. Abuse in the form of coercion or manipulation. A very, very skilled debater.

**Snake-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Lobbying. A conflict between really wanting
something and being distracted from it. To want too many different things at once. To not know in which direction one should move, what decision to make.

**Snake-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
First time to feel (sexual) desire; growing desire. Being naive (and maybe easy to deceive) in sexual matters, or in politics etc. Someone easy to trick/manipulate. Inexperience with power or sex; little knowledge. An affair is in its first stages. Taking someone's innocence; cradle robber. Paedophilia. Imbalance between someone inexperienced (and maybe naive) and someone very experienced and skilled (who is possibly but not necessarily manipulative).

**Snake-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To be be guarded or secretive about one's desires. To be very cautious regarding sexual desires or desires in general. (Unspoken) sexual tension. To distrust someone who is attracted to you; or someone you're attracted to you is distrustful of you. To be suspicious about being tricked or manipulated. To react with a strong sense of self, with a healthy dose of self-preservation instinct, to attempts at manipulation. A very, very sneaky, or false, person. A situation where one needs to be cunning and/or adaptable to reach one's goal. Adaptation of goal.

**Snake-Bear[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Conflict between someone who has the power (bear) and someone who wants it (snake). To want power or influence badly. To strive for competence and practical knowledge. Manipulative parent/boss. To move towards the goal with assertiveness (maybe recklessness). To assert what you want.

**Snake-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Spiritual leader; guru. To be drawn to a spiritual idea because it makes you feel powerful (or special); seductive spiritual teachings. To have a strong desire to experience transcendence, and to work hard for it. To very ambitiously do everything to fulfil your heart's desires. To be tricked by faith healers or other spiritual charlatans. To fall prey to a cult(leader).

**Snake-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Very, very strong longing. To be willing and able to exert power by nature. To really, really set one's mind on a transformation / transition. To not let anything distract us from doing what we really need to do. A very strong desire and drive to transform; self-actualisation by whatever means lead to the goal. Someone's transformation or transition seems egotistical, selfish to us - but they are probably doing what they have to do to stay whole. The experience of sexuality, or power, or knowledge, transforms us. To go along with one's desires. Cravings so strong that caving in to them seems inevitable. To fall prey to someone manipulative - again!

**Snake-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Strong desire to always be there for someone specific or for other people in general. To follow someone very determinedly; to always submit to someone else's wishes. Conflict between wanting to follow your own agenda and wanting to be told what to do. Wanting to be friends with someone very badly. A Guru or leader (Snake) and their follower (Dog). Manipulative friend; a friend with their own agenda. Wise counsel.

**Snake-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To be so ambitious or so fixated on something else that no meaningful relationships with other people are possible. To strive towards the top position. A very wise person who could give us good advice but who might be hard to approach because they live a very seclusive life. To yearn for solitude. To calculate very coolly and unemotionally what you need to do to reach your goal. (To allow) no distraction. To not allow oneself to follow a craving. Very strong self-discipline.

**Snake-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Going public with something will have to be handled very
diplomatically. To be open and above board about your desires and/or motives. Politician; diplomat; spin doctor, press officer. To have ambitions to become
famous or at least to be in the public eye. To crave publicity.

**Snake-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To seek challenge. To have reached an impasse in your efforts to get somewhere or something. An obstacle is between you and what you want. Hot desires are met with cold silence. To be unmoved by someone's attempts at seduction.

**Snake-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Self-empowerment; to allow yourself freedom of choice and/or independence. To make decisions based on a strong sense of direction; to go where you really want to go. Or: cravings all over the place. Difficulties making a decision because there are so *many* things you want. Or: to enjoy changing direction whenever the mood strikes - to change direction for the sake of the experience.

**Snake-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Dwindling motivation. The nagging feeling that there's something wrong with the direction you're headed. A formerly passionate affair is going stale. A craving is waning. Loss of power. Corrupted power. A liar; to spread lies. Someone or something is damaging your career. A very corrupt politician/spiritual leader/teacher/lawyer etc. Manipulation, or coercion.

**Snake-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To crave love; to seek reconciliation; to strive for doing compassionate deeds. A charity worker. To have skills in showing love / compassion etc. Conflict between wanting to achieve one's own goals and wanting to care for others. A selfish, ruthless person vs. a person who cares for other people's well-being (too much). To exploit other people's affection to get what we want. To calculate with other people's softness. Manipulation of affection. Motivated by love. To be persistent - in a loving way, or, because we care. To not give up out of love. When our heart is in it we won't give up. Seduction - not in a secret fashion but openly, making the loved one feel loved and wanted.

**Snake-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To pursue a relationship, to seek connections. Connections which serve our purpose; tactical alliances. Commitment to a cause/goal. A shared goal. The intellectual ability to understand cause and effect, to understand how things interrelate, how they are connected, and to be able to use that knowledge to our own advantage. To follow the evidence, to join the dots. Shared ambition, (sexual) passion, desire. Strong cohesion. To aim for marriage. Matchmaker. Shared knowledge.

**Snake-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Academic career. Very strong academic ambitions, to crave knowledge; to do everything to find out what's true. To study diligently. To believe in one's intelligence. A teacher/professor. Pretend intelligence; to feign knowledge. Manipulation of facts.

**Snake-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Communication with a very specific aim; to say out loud what you crave; to communicate your desires. To make demands. Documents concerning your career; e.g. a CV. A very tactful or diplomatic conversation. To manipulate others with rhetorical tricks. To not let go of a certain topic until everything is said.

**Snake-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Man who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality man, lawyer, politician, diplomat. A man goes his own way. An affair with a man. To feel attracted to, seduce, manipulate, or coerce, a man.

**Snake-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Woman who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality woman, lawyer, politician, diplomat. A woman goes her own way. An affair with a woman. To feel attracted to, seduce, manipulate, or coerce, a woman.

**Snake-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Man who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality man, lawyer, politician, diplomat. A man goes his own way. An affair with a man. To feel attracted to, seduce, manipulate, or coerce, a man.

**Snake-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Woman who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality woman, lawyer, politician, diplomat. A woman goes her own way. An affair with a woman. To feel attracted to, seduce, manipulate, or coerce, a woman.

**Snake-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Strong cravings for or even addiction to: sex, food and drink, harmony. Extremely high sex drive; to enjoy seduction. To have a sexual relationship for career reasons or to enhance one's self-esteem. Strong yearning to reconnect with the sensual world; to seek sensual pleasures. To allow oneself to follow one's sexual desires even if others think it's unseemly. Sexual (self)empowerment. The longing to be creative; to create artwork. An ambitious, skilled artist.

**Snake-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
A very wise person. To strive for virtuousness. To be motivated to be a better person. To behave morally only to reach a certain goal. Conflict between craving something and thinking one should have no strong passions (vices). Peacemaker. A nice Koan: to crave freedom from craving. To be honest about one's desires. To desire something or someone but with good intentions. To look for someone who is wise, or righteous, or who has good intentions.

**Snake-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To crave warmth, light, summer. To want to be popular and do everything to achieve
popularity. The talent to be positive about everything, to see the good aspects and focus on them. The (vain) effort to avoid anything that is sad or difficult. A party animal. To try to make things better, or more enjoyable. To crave warmth, light, summer. To want to be popular and do everything to achieve
popularity. The talent to be positive about everything, to see the good aspects and focus on them. The (vain) effort to avoid anything that is sad or difficult. A party animal. To try to make things better, or more enjoyable. Confidently ambitious. Someone carries their selfishness on their sleeve.

**Snake-Moon
 [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To strive for knowledge about
the subconscious. To be drawn to the dark, to prefer nighttime. To be motivated by emotions/fears and needs. To follow one's intuition. To be good at directing other people's emotions; manipulation through playing on fears and needs. Profound cravings; deep wisdom. Conflict between our ambition and our need for rest. To seek out deep emotions.

**Snake-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To seek a way in. To see relief; or liberation. To work towards finding a solution persistently. In order to succeed we need to pursue our goal single-mindedly. To use something or someone as a means for one's own, selfish end. To strive for understanding. To have an important experience, an eye-opener in the area of sexuality, education, or power. Or: to naively open one's door to someone who might be pursuing their own selfish agenda. To coerce someone to say yes.

**Snake-Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To have a very strong desire or motivation to earn a lot of money or to acquire a lot of goods. Extreme greed. To maybe even do immoral things in order to get whatever you want. Or, to be very intelligent about how you start a business or how you earn your living.

**Snake-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
To crave safety or stability; everything revolves around ambition (maybe advancing a career) for you. To focus on gaining knowledge/getting sex/getting power. To have a stable goal to work towards. To be so entangled with something you can't break away anymore.

**Snake-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
Ambition or cravings have become a burden, are causing suffering. Someone who determinedly adheres to a very strict ideological system. To strive for more responsibilities. To very single-mindedly pursue something even if it takes a lot of hard work or the process is painful. To follow one's true calling determinedly. Someone who fulfils their duties wisely. Cult leader, ideological manipulation/indoctrination.

**Snake - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)**
A craving never followed yet. To be unaware - yet! - of what we truly want; to be, yet, directionless. To be motivated by something that can't be clearly expressed (yet). To strive for understanding the yet incomprehensible, for finding an answer to open questions, for directing the yet directionless, for fulfilling yet unfulfilled desires. Question mark regarding someone's desires, goals, motivations. A (possibly genderqueer) person with the attributes of the Snake (see the Snake's keywords).
