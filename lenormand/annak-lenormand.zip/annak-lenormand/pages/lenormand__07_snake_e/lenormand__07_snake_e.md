---
title: "lenormand | snake | keywords"
source: https://www.annak-tarot.at/lenormand/07_snake_e.html
---

**SNAKE 7**

**Keywords**

***Nouns / phrases:***

Craving, demand, desire, attraction - especially to/for knowledge,
power, sex. Sex drive, seduction. Use of power, coercion. Search for
knowledge, espionage. Career, ambition, motivation. Single-mindedness, sense
of direction, determination, perseverance. Ruthlessness, selfishness. Self-will,
tenacity, obstinacy, indomitability, (self)empowerment. Cunning: practical skill,
shrewdness and (traditionally) deception. Diplomacy, tact. Ability to steer people
in a certain direction. Manipulation.

 ***Activities:***

To desire, crave, demand. To seduce. To use one's power, coerce. To strive for knowledge
- possibly illegitimately. To strive or aim for something, follow a career. To motivate
(oneself), persevere. To act ruthlessly. To empower (oneself), strive for something, persist. To use
one's wits and/or diplomacy. To steer others (positively) or manipulate.

 ***Attributes:***

Eager, covetous, avid, attracted to. Power-hungry, thirsty for knowledge, horny. Addicted.
Seductive. Coercive. Ambitious, single-minded, goal-oriented, focused, purposeful, motivated,
driven. Ruthless, calculating, egotistical, inconsiderate. Strong-willed, headstrong, tenacious.
Cunning, shrewd, (traditionally) deceptive. Skilful (smart), diplomatic, manipulative.
 **As a person:**  Person with the above attributes, e.g. ambitious, goal-oriented, headstrong. Politician,
lawyer, diplomat. Tradionally: female - the other woman; deceptive woman. **As advice:**
 Go for it! Pursue your goal persistently! You can do it! Use your wits! Negatively: Don't
disregard the needs/feelings/rights of others!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Only if we persist. Only if we set ourselves at it. Or: someone else is the puppet
master who controls when, or if, it will happen.

 **See also** the *annakblogs* article [>> So, is the Snake a positive or negative card?](https://annakblogs.wordpress.com/2017/10/31/light-shadow-snake/)
