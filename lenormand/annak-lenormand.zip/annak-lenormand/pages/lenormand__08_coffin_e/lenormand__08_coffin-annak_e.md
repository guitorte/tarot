---
title: "lenormand | coffin | interpretation"
source: https://www.annak-tarot.at/lenormand/08_coffin-annak_e.html
---

coffin
 **INTERPRETATION**

*Death, end, loss; grief; to let go; to repress something*

**About the meaning:**
The Coffin maybe is one of the cards with the simplest, least complex meanings. But it is also a very important card. The losses we suffer, and how we deal with them, as well as the things we keep buried deep inside ourselves, are probably among the biggest influences on how we live our lives.

*Death / loss / endings:* Because coffins are used to bury (or cremate) the dead in, the card Coffin most obviously represents death. While this literal interpretation is simple and quick I find it only very rarely useful. Yes, in some cases, a querent's concern will indeed be connected with the death or approaching death of a terminally ill loved one. But it is much more productive to not limit the Coffin to death in a literal sense. To me the Coffin just means that *something* has ended or will soon end, not necessarily and not even very often a human life. In fact, in most cases what is ending is something like a phase of life, a relationship, an emotion, an employment, or a way of thinking. The card stands for *any* loss that we've suffered, even the loss of hope, for example; and it stands for anything which we give up voluntarily because it is time or "natural" to. For example, we might give up a once cherished belief painfully but willingly when we discover it can't be supported by facts.

*Grief / to let go*: Closely connected to losses are feelings of grief. This is why the Coffin also represents mourning, grief, or, in less intense forms, reactions of sadness or emotional numbness. In some cases it is very useful to interpret the Coffin as a hint that something needs to be grieved for properly before one can move on. In these cases, the card can even represent actual, physical grief rituals! Also, the purpose of grief is to enable oneself to eventually let go. So I often (and very successfully) interpret the Coffin as representing something one needs to let go of.

*To bury or suppress something:* One of the interpretations of the Coffin I use most is the Coffin as a representative of something we repress. For a coffin which is buried is (at least in theory) supposed to never be dug up again. Its contents are supposed to stay under the ground for the rest of eternity. So, metaphorically, the card Coffin stands for anything that we bury inside ourselves - or, with a slightly different slant, that we suppress, that we don't allow to live. For example, we maybe bury a dream we have, never allowing ourselves to follow it ever again. Or maybe we suppress certain feelings; or we don't allow parts of our personality to be alive. Sometimes we maybe *need* to do a little bit of suppressing, e.g. when living out our desires would be more harmful than not to, at least at that time. But probably much more often, we bury things needlessly, out of fear, or hesitation, or because we feel they are not "proper". In these cases burying them can be very harmful, hindering us to lead a fulfilled life.

*Negative outlook on life:* I have seen some people interpret the Coffin not just as grief but also as a generally negative outlook on life, as pessimism. I personally don't use this interpretation because I'm not sure whether there is an actual, direct connection between death/loss, and pessimism. But I get why one might argue that there is, so I'm mentioning it for the sake of completeness.

 **See also** the *annakblogs* articles [>> So, is the Coffin a purely negative card, then?](https://annakblogs.wordpress.com/2017/11/07/light-shadow-coffin/) and [>> What's the difference between the Lenormand Coffin and the Tarot Death card?](https://annakblogs.wordpress.com/2018/01/06/qa-whats-the-difference-between-the-lenormand-coffin-and-the-tarot-death-card/)

**About the Image:**
 If you've read what I wrote above, you won't wonder why I drew the coffin the way I did, already in the ground, ready to be buried. This way, death, loss, and grief, are still very obvious meanings of the card. But it also very clearly expresses the "something we bury, or suppress" part of the card's meaning. This is also the reason why I drew red roses lying on top of the lid. Red roses are often used at funerals to express a "love even beyond death". In my card they could stand for the emotional importance which a loss has for the querent. They could mean that the querent hasn't emotionally let go of something although it is over. Or, the roses could mean that the querent *shouldn't* be burying (giving up) something - because it is still very "alive"!
