---
title: "lenormand | coffin | comparisons"
source: https://www.annak-tarot.at/lenormand/08_coffin-comp_e.html
---

coffin

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Coffin, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Endings and loss**

|  |  |
| --- | --- |
|  | **Coffin**: Natural end; death. Something is over for good. The experience of a very painful and permanent loss. The grief we feel over an ending or loss. |
|  | **Scythe**: Sudden, painful, or "efficient" (wasting neither time nor effort), ending - especially in the sense of a termination, disruption. Ending which is premature or unexpected. Someone cuts themselves out of our life; cuts us off. The physical or emotional injury when something is cut (off). |
|  | **Mice**: Loss in the sense that something has been taken away, stolen, or that something which was once plenty is now getting less, dwindling away. |
|  | **Ship**: Loss in the sense of "someone has left" or "something is absent right now" (but they might return). |

 **Sadness**

|  |  |
| --- | --- |
|  | **Coffin**: Grief - the type of "sadness" specific to the experience of a loss. |
|  | **Moon**: Melancholy and depression - sadness which arises from the perception of the whole world as a dark place. |

 **See also** the *annakblogs* article [>> What's the difference between the Lenormand card  *Coffin* and the Tarot card *Death*?](https://annakblogs.wordpress.com/2018/01/06/qa-whats-the-difference-between-the-lenormand-coffin-and-the-tarot-death-card/)
