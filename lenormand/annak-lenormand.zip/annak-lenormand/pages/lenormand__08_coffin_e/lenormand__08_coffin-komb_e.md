---
title: "lenormand | coffin | combinations"
source: https://www.annak-tarot.at/lenormand/08_coffin-komb_e.html
---

**COMBINATIONS WITH THE
 COFFIN**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Coffin-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
News which cause grief; news about an end, news which cause an ending. A loss which changes something or which changes everything. The pressure to repress something. Someone or something which helps one to let go (of grief). Overwhelming grief; someone else's grief is disrupting one's own happiness. Letting go allows change to happen. To repress one's flamboyant personality. Repression of activity.

**Coffin-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
The end of ease; something pleasant ends. To grief the loss of ease, or of a time of unburdened freedom. The end of a lucky streak. An ending, or some grief, is not that deep or won't last long. One's happy-go-lucky nature, one's usually easygoing nature, is buried by something (by grief, if it's the Coffin itself that defines it, or by something else). The chance to end something, finally. A chance that lies in an ending. Gallows humour. During times of grief, looking at the small joys of life might be what helps.

**Coffin-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
A journey is over. No more exploration. To suppress one's urge to leave or one's wanderlust; to suppress one's adventurousness. To not allow oneself to make changes. The loss of someone - because they left, literally speaking. A final farewell. To move on (from a loss). To leave something or someone behind for good. To explore one's grief; to explore that which is buried deep down.

**Coffin-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To feel suffocated in one's own home as if one were living in one's own grave. Loss of a family member (not necessarily through death!). A dead family member. A tradition which is not kept alive anymore. To give up a plan, a tradition, a home. To let go of something to do with an (exaggerated) need for safety. To bury one's wish to build a family / a house. Funeral arrangements (plans).

**Coffin-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Loss of vitality, loss of life, a physical loss we've suffered. Loss of limb. To suppress one's bodily needs; to suppress what's natural. End of growth; loss of health. Exhaustion, burnout. Negative view on one's body, or nature. Ageing processes. Or: A healthy loss. Letting go of something will increase one's vitality/health. A natural ending, natural death. A dead grandfather/grandmother.

**Coffin-Clouds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Uncertain or unclear ending. Something seems to be ending but we can't say for sure what exactly. Suppressed insecurity. To swallow one's despair. Despair so big that life isn't bearable anymore. Grief so big it clouds the mind; depression. The loss of something or someone familiar has led to disorientation. To not know how to go on. To let go of a misunderstanding. End of despair, end of secrecy. No more hiding. To drop all pretence.

**Coffin-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To bury one's ambition or a desire; to not let one's sexuality live. To have to submit to someone or something. A craving ends / to give up a goal. To put an end to something tactfully. An affair ends. To be drawn to death; to be suicidal.

**Coffin-Coffin[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Dead end. To let go of a loved one who is dead or literally gone. Very big grief. To grieve over a loss. The end of grief.

**Coffin-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
End of pleasantries. Loss of comfort, beauty, or social circle. To suppress one's social abilities/needs. To not allow oneself to make oneself more pretty/attractive. To let go of the illusion that everything/everyone is nice.

**Coffin-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
A very sudden or unexpected ending; painful break-up, fatal accident, murder. Premature end. To take stock of one's life in order to decide what one wants to leave behind. A clean break. Cold withdrawal. To put a stop to something with finality. As advice: put an end to [x] right now!

**Coffin-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To let go of an argument. End of a conflict. To grief over having been wounded. To bury feelings of aggression or a conflict. To suppress painful memories or memories of violence. To suppress one's own violent tendencies. Blame for death; blame for the end of something. To be responsible for (and/or feel guilty for causing) an ending.

**Coffin-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
End of chaos. To let go of something which causes stress. Great worries about losing something or someone. Loss of agility/flexibility. To react with sadness/grief very quickly. Chattiness ceases. To repress one's worries. To bury oneself in things to do. Keeping busy as a way to cope with grief.

**Coffin-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
End of a beginning; beginning of an ending. Loss of innocence. Small grief; or beginning of grief. To not let one's inner child live; suppression of playfulness; to repress one's natural curiosity. To give up the hope to conceive. To give up something for a child. To bury one's own dreams or suppress one's own needs for the sake of one's child(ren). Miscarriage. Young person who has died. Grief for a child, or for one's innocence. Inexperience with grief, or with losses, or death. To be unable to handle a loss by oneself.

**Coffin-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
It's time to give up trying so hard. Working too hard / having to survive under harsh conditions has led to exhaustion or disease. A time of hiding has ended (or: it should end). Being too cautious leads to burying one's dreams. What one thought was a vital part of one's identity is now gone. To adapt to a loss. To suppress one's own needs; to not look after oneself well. Ending something is in one's own best interests. To look after oneself in times of grief.

**Coffin-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Loss of a leader, teacher, or parent(al figure). Loss of power. To grief over the fact that one's parental role is no longer needed. To guide others in their time of grief. Or: grief has one firmly in its grip. A loss that has great influence on one's life. To bury your parental instincts. To suppress one's hot-blooded or assertive nature.

**Coffin-Stars[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Loss of purpose/meaning; to bury one's dreams. Loss of hope. To let go of an illusion. The end of a spiritual belief. To seek deeper meaning in the experience of a loss, of grief. Or: To not accept a loss (e.g. "He might come back to me!"). To keep up the hope it things might
still work out even if everything seems to be over and done now. To reach out (to others, to god, for help) in times of grief. To suppress one's spiritual side.

**Coffin-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To accept the inevitability of death. To accept that something will end at some point. The transforming (and exhausting) experience of grief and loss. The transforming power of letting go. A longing for death; to long for an end of something. To not allow oneself to follow one's deepest longings; to bury one's true nature underneath a facade. The (futile or very harmful) attempt to suppress a natural transformation. End of a transition, end of a process, end of an inner journey. Something takes a long time to end. Something is already in the process of ending - there's nothing we can do to stop it, we can only go along and prepare.

**Coffin-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Loss of a friend or follower. End of friendship. Loss of loyalty, loss of support. This is where loyalty ends! To give up a follower-mentality. To bury one's friendly feelings. It's time to stop trying to help. Permission to end something. Support in times of grief. Someone who helps us end something. To worship death.

**Coffin-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Grief which causes isolation. Loneliness after a loss. To stay emotionally distant out of fear of loss. Not allowing feelings, emotions, has made one feel dead inside. To lose or give up a position of power. The end of a retreat; the end of isolation. Loss of pride. To give up ideals.

**Coffin-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Loss of reputation. Public grief.
To withdraw from public life. To bury personal dreams and needs in order to fit in with mainstream society. End of publicity; no more publicity. To make an ending public. To publicly end something. To keep something away of the public eye. Obituary. Funeral service.

**Coffin-Mountain[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Big grief, great loss that feels impossible to overcome. Inability to go through with ending something. It's time to end silence; it's time to start to
move again. All involved know that something is over but no-one wants to admit it. To hide one's grief behind silence or seeming emotional cold.

**Coffin-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To not allow oneself to be free. To suppress the knowledge that we do have a choice. To rule out alternatives. Loss of choice - only one path is left open. The end of a certain path. Road's end. Or: No way out. The choice of ending something. End of tolerance. This is where our freedom ends. Ambiguity concerning an ending; ambivalence concerning a loss. Different ways of grieving. Facets of grief. Multiple losses.

**Coffin-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Nagging suspicion that something is ending. An end which is coming bit by bit (which is either draining, or a chance to say goodbye / to prepare). End of corruption; to put an end to a draining, unhealthy situation. Unhealthy grieving strategies. Inability to live a full life because resources are scarce. To sweep things under the carpet.

**Coffin-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Lovesickness. End of love. The loss of romantic love or loving friendship. The natural end of the romantic part of a loving relationship. (Unhealthy) infatuation has ended - now there is grief over the loss of the ideal. Comfort; to comfort somebody in their grief. To bury one's loving emotions; or to not allow oneself to be soft and caring. Love conquers all. To be emotionally very attached to something or someone ended/gone/dead. To care for someone who is dying; hospice. Or: To feel drawn towards death.

**Coffin-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To release someone from a promise or contract. End/loss of commitment; to lose a connection; a link is broken. Loss of coherence, loss of cohesion. A relationship ends. Divorce. Shared grief; grief unites. To feel tied to death, grief, loss (= depression, suicidal thoughts). A promise to end something or let go of something. To ignore that there is a connection. The cause for an end.

**Coffin-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
End of an education (not necessarily premature!). Grief caused by learning a painful truth. To accept that truth might never be found. Facts about an ending, about a death, a loss. History. To give up one's yearning for better education. One's intellect isn't utilised.

**Coffin-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Farewell letter. To communicate one's wish to end something; e.g. a relationship, a job. Communication has died down. Words left unsaid. A suppressed need to talk about something.
Letter of sympathy. To tell others about one's grief. Suicide note.

**Coffin-Man (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Man who has died. Man who's suffered loss; man who hasn't let go of something (or, a man who is in the process of letting go). Widower. Man who is suppressing a lot or buried his dreams. To let go of a man; grief over the loss of a man. To suppress the man inside ourselves. To not allow a man to live life to the fullest.

**Coffin-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Woman who has died. Woman who's suffered loss; Woman who hasn't let go of something (or, a woman who is in the process of letting go). Widow. Woman who is suppressing a lot or buried her dreams. To let go of a woman; grief over the loss of a woman. To suppress the woman inside ourselves. To not allow a woman to live life to the fullest.

**Coffin-Man (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Man who has died. Man who's suffered loss; man who hasn't let go of something (or, a man who is in the process of letting go). Widower. Man who is suppressing a lot or buried his dreams. To let go of a man; grief over the loss of a man. To suppress the man inside ourselves. To not allow a man to live life to the fullest.

**Coffin-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Woman who has died. Woman who's suffered loss; Woman who hasn't let go of something (or, a woman who is in the process of letting go). Widow. Woman who is suppressing a lot or buried her dreams. To let go of a woman; grief over the loss of a woman. To suppress the woman inside ourselves. To not allow a woman to live life to the fullest.

**Coffin-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To bury one's passion about something/someone; to suppress physical pleasure. No more sex (for whatever reasons). Creative force is being stumped. To end a sexual relationship. A very slow process of letting go. To deal with grief in an artistic, creative way. Intense grief. Maybe: the decline of old age.

**Coffin-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To make one's peace with a specific loss, with the death of a loved one, or with mortality in general. "Memento mori". Virtues which are relevant in times of grief (e.g. compassion, serenity). The end of something actually brings peace of mind with it. To cover one's craving for sensual pleasures with extreme austereness. To suppress something (possibly a forbidden or threatening passion) with extreme self-discipline. To let go of a false pretence of virtuousness, of moral infallibility. Loss of purity; loss of innocence - to grief over having besmirched oneself, over having become guilty of something.

**Coffin-Sun[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
The end of something happy or joyful. The loss of ease (to become serious). Or: a period of grief is over; it's time to let joy into one's life again. An ending which causes joy. A good, positive end. Celebration of an ending. To suppress one's joy. To not allow oneself to be happy. Superficial grief. The positive side of an ending. To let go of pretence.

**Coffin-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To put something to rest. To find rest after something has ended / someone has died. A loss casts a shadow on everything. Profound grief; grief which has turned to depression. To be unconsciously
aware of something ending. The emotional trauma of being witness to
death or sickness. The natural ups and downs one experiences after a loss. End of darkness; no more fears, or: to bury one's needs, to suppress one's fears or one's intuition. Loss of depth. To let go of an emotion.

**Coffin-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To accept that something is over. To allow oneself to grieve. To finally dare to go dig up something one had suppressed - a dream, a fear, hope etc. To be vulnerable to lose something (because we are unguarded). To have such weak boundaries that depression sets in quickly when confronted with other people's suffering. To close the door - to stop saying yes. The ending of something is imminent. To understand why or that someone is grieving, or what has been lost. That which makes it possible to let go.

**Coffin-Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To give up a business idea, or to lose one's business. To lose money. To give up the idea of becoming rich. To lose something or someone that meant a whole lot to us. To leave behind one's materialistic ideas. End of greed. To suppress one's greedy nature. Something valuable can be found in the experience of a loss. A loss/ending which turns into a gain. To suppress something in order to profit somewhere else.

**Coffin-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
To be stuck in a grieving state. Everything in one's life revolves around a loss. To be unable to let go of something which really is long over. Support in times of grief. To lose support; to lose one's grip. Loss of focus. To give up something in order to focus on something else.

**Coffin-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Self-sacrifice; to give up one's dreams in order to fulfil one's duty. Painful ending. The responsibility for an ending. To suffer greatly from a loss. Terrible grief.
To let go of a dogma, or to lose belief in an ideology/religion. The burdensome awareness that everybody will eventually die. Terminal care.

**Coffin - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)**
Something hasn't ended yet but the end is already in the making. Question mark regarding an end, regarding *how* something will end, or *what*. Something is buried deep down but we're not sure what it is. To suppress the knowledge that there's a question mark, that something is not determined yet. Loss of the sense of "open end" - now everything is fixed, defined. A (possibly genderqueer) person with the attributes of the Coffin (see the Coffin's keywords).
