---
title: "lenormand | coffin | keywords"
source: https://www.annak-tarot.at/lenormand/08_coffin_e.html
---

**COFFIN
8**

**Keywords**

***Nouns / phrases:***

Death, dying, funeral, loss. An end(ing). Grief, mourning, mourning
ritual. Sadness or emotional numbness. Something which is gone/buried/
suppressed. Possibly: a negative view of life, pessimism.

 ***Activities:***

To die, to end. To let go, to give (something) up. To lose, to grieve. To
bury, repress, or suppress. To not allow something to live (hopes, feelings).

 ***Attributes:***

Dead. Over, past, gone, ended/ending. Terminal. Grieving/grieved,
sad, weepy, numb. Buried, suppressed, repressed. Negative, pessimistic.
 **As a person:**  A person who is repressing a lot. A person we have lost for good (not necessarily
through death). Someone who is grieving over a loss, e.g. a widow(er). A loved one who has died. **As advice:**
 Don't attempt to hold on to something that is already ending - let go! Allow yourself
to grieve! Negatively: Stop suppressing things! After a mourning period, it is now time to look at
the things that make you happy!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Cessation. No time anymore; it's over. Not anymore, not ever again.

 **See also** the *annakblogs* articles [>> So, is the Coffin a purely negative card, then?](https://annakblogs.wordpress.com/2017/11/07/light-shadow-coffin/) and [>> What's the difference between the Lenormand Coffin and the Tarot Death card?](https://annakblogs.wordpress.com/2018/01/06/qa-whats-the-difference-between-the-lenormand-coffin-and-the-tarot-death-card/)
