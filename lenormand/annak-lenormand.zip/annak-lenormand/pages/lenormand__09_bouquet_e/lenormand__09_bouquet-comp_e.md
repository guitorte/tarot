---
title: "lenormand | bouquet | comparisons"
source: https://www.annak-tarot.at/lenormand/09_bouquet-comp_e.html
---

bouquet

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Bouquet, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Creativity**

|  |  |
| --- | --- |
|  | **Bouquet**: Decoration and design. Pretty, pleasant-sounding, fragrant stuff. |
|  | **Lily**: Art - which *can* look and sound nice but may also be scary and wild and political and might have a nasty smell. |

 **Social life**

|  |  |
| --- | --- |
|  | **Bouquet**: Conviviality; circle of friends. Visits, invitations, social pleasantries. |
|  | **Garden**: The public sphere, the whole of society; large groups, specific social networks. Networking, marketing, lobbying. |
|  | **House**: Private sphere - home life, family. Familiarness, intimacy. |
|  | **Tower**: Total privacy, no company, everyone is kept out. Loneliness |

**Friendship**

|  |  |
| --- | --- |
|  | **Bouquet**: Our circle of friends. Conviviality. To be sociable, to cultivate friendships. |
|  | **Dog**: A friend. Friendship, loyalty. To support, to help. |

**Positive Emotions**

|  |  |
| --- | --- |
|  | **Bouquet**: generosity, thankfulness, appreciation, cordiality. |
|  | **Heart**: All types of love, and also tenderness, compassion, forgiveness. |
|  | **Sun**: Happiness - joy, mirth, ease. |
