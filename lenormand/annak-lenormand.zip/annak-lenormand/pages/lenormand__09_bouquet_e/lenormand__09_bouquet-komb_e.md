---
title: "lenormand | bouquet | combinations"
source: https://www.annak-tarot.at/lenormand/09_bouquet-komb_e.html
---

**COMBINATIONS WITH THE
BOUQUET**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Bouquet-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Visitor (who's invited themselves?); a welcome change (or news); to invite change; social intrusiveness or presumptuousness. Greatly exaggerated or embellished news. Intrusive design or fragrance, flashy outfit. Overwhelming beauty. Something changes one's beauty standards. Obtrusive compliments or flirting.

**Bouquet-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
A chance to visit / be visited / be more sociable. Circle of friends in which nothing serious is ever spoken about. Don't take compliments you are getting too seriously. To have some fun with decorating / a makeover. To dabble in interior or fashion design. Light-hearted flattery or flirts. To not take the cultivation of friendships serious(ly enough). A welcome opportunity.

**Bouquet-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To be welcome(d) were you go. To welcome a foreigner; a stranger. A welcome journey/change. To re-decorate. To be not very committed to one's friends. Change your ways - you need to be more friendly, praise others more! To go visit someone new; to embark on the venture of broadening one's social circle. To explore new social circles. To leave one's social circle. To leave behind the need to look pretty and look for something better. A farewell party; a farewell gift. To give (or receive) praise for making a change. Exaggeration of an adventure. Admiration of adventurousness.

**Bouquet-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Gratitude or admiration for family(members). Interior design; to make one's home nicer. A family member who always tries to be nice to the others. The attempt to make family life more pleasant Family gatherings; to reconnect with family members. Familiar flattery; to be used to compliments or admiration. Elaborate rules or plans; to overdo it with planning. Traditional beauty standards. To plan a visit. Rules which apply when visiting/receiving guests. Home visit. Visit of the family or a family member. To be comfortable socializing. To have very set taste. Rules regarding the showing of gratitude.

**Bouquet-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Compliments about our appearance; flattery about physical characteristics. Attempts at making our body look/smell/feel more beautiful. Exaggerated decoration of one's body. Or: Natural beauty. Natural decorations - e.g. flowers, living plants, the use of natural materials etc. Very stable and strong circle of friends. To find grounding in one's social circle. Gratitude for health; gratitude to one's ancestors. Gifts which are very usable, down-to-earth; pragmatic gifts. To be nice for pragmatic reasons.

**Bouquet-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Fake compliments. Someone is being nice but has a hidden agenda. Confusion about how you should react to niceness / compliments / flattery. Insecurity in social situations. To misunderstand someone's pleasantries. To not know how to express gratitude or admiration. To be conceited in regard to one's attractiveness.

**Bouquet-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
The use of flattery to  get something, to manipulate somebody. To be happy and proud of your own achievements. To crave (loving) attention, admiration, or a more active social life. To be very adept in social settings. To put a lot of effort into looking nice.

**Bouquet-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
End of pleasantries. Loss of comfort, beauty, or social circle. To suppress one's social abilities/needs. To not allow oneself to make oneself more pretty/attractive. To let go of the illusion that everything/everyone is nice.

**Bouquet-Bouquet[\*)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)](https://www.annak-tarot.at/lenormand/star_e.html)**
Very pretty, very pleasant, very elaborate. To flatter someone's looks; compliments regarding someone's good manners. Someone for whom beauty is everything. To bring a gift when visiting. To exaggerate one's social life.

**Bouquet-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Unexpected visitor or invitation. To put an end to flattery. to reap praise for effort / hard work you've put in.
Or: to be nice to people just because you want something from them.

**Bouquet-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To behave in such a friendly and non-confrontational way that others think they can be mean to us. To exploit someone's goodnaturedness. To react with kindness to aggression. To alleviate guilt or shame. Attempts at appeasement. Gestures of reconciliation. To gloss over / sugarcoat / whitewash something which is quite horrible in reality.

**Bouquet-Birds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)**
Chat and gossip
in our social circle. Worries about a visit or an invitation. (Noisy/chaotic) party or gathering. To be full of happy but chaotic thoughts. Someone is so admiring that it annoys the admirer. Attempts to be pretty for or nice to everybody in all kinds of ways. Fluctuating views on what is beautiful. Pretty platitudes.

**Bouquet-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To be nice to or reconnect with a child, young person or childhood friend, maybe give them a present. (Birthday) party for a young person. Pretty child. To welcome a child. To be grateful for a child. To praise a young, inexperienced person. To take the first steps towards improving something. To take the first step towards another person. Naivety when we are just being flattered. Guileless friendliness. To meet friends for games.

**Bouquet-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Flattery and social visits for selfish purposes; to be nice to others for one's own gain. Distrust of compliments; to not trust someone's kindness. Be cautious of being too generous! Friendliness as self-defence. One's identity is dependent on one's looks. To have one's own beauty standards. Commendable caution. Caution in regard to a visit(or); to be cautious of who one welcomes in. To do something nice for oneself; self-praise.

**Bouquet-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Invest in your friendships now so they'll be strong when times are more difficult (or to prevent them from falling apart). Looking nice, making a good impression, is so important to you that it dominates your life. Influential social circle. An interfering visitor. Someone tries to influence who someone else make friends with. To visit or invite a (grand)parent. To flatter, try to win over, or even bribe, someone who is in a position of power. Powerful flattery; to be easily overpowered by flattery.

**Bouquet-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
The longing for fulfilling, friendly contact with other people. To reach out to others with the hope of getting friendliness in return. Wishful thinking we were more attractive, or our situation was nicer, etc. Illusions about our looks. High hopes concerning a social situation. A type of spirituality in which aesthetics play a big role. To aspire to beauty. To trust someone's friendliness.

**Bouquet-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
A slow transformation towards being more sociable, less isolated. Being nice to someone can transform them. The longing for a richer social life. A transition for which we receive praise. A returning visitor; to revisit a place we once visited before. What we consider beautiful is transforming. To transform something (or one's own body) by decorating, embellishing, enhancing it. To exaggerate or glorify a longing. Repetitive compliments. To try again in the hope that maybe this time our gifts / compliments / flirt will get better reception. To feel pulled towards that which is pretty, or towards people who flatter us.

**Bouquet-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Show your appreciation to your friend(s) or employee(s) more! Visit a friend or invite them. Someone really needs to know you love them / are proud of them. Someone dependent on approval. Unconditional admiration. Admiration from a friend. Someone totally adores you (possibly not in an entirely healthy way). To make oneself look pretty to please others.

**Bouquet-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
A conflict between wanting to retreat and wanting to (or feeling one should) be more sociable. A social recluse. Let people in! To get admiration for one's achievements. To turn down an invitation. To refuse entry to someone who would like to come in. To not accept a gift. Praiseworthy leadership. To flatter, kiss the ass of, or even bribe, a person in power.

**Bouquet-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To meet someone in public - to go to a restaurant or cafe etc. together with one or several friends.
To present a friendly face on the outside even when we don't feel friendly. A culture of welcome. Commonly accepted standards of beauty. To want to be pretty to others. To have a very large circle of friends. Facebook type of friendship. Lobbying, marketing, PR, advertising.

**Bouquet-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Social phobia (to freeze in social situations). Difficulties with making or accepting compliments
or with giving or accepting gifts. It's going to take a long time
until you and someone else (or a group of people) will come to
accept/like each other. It's difficult to make friends with a person,
idea or situation. Exaggerated problems. A greatly embellished tale of conquest/victory. Praiseworthy patience. Friendly silence. Tackling social dealings/gatherings.

**Bouquet-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To choose that which is more pleasant. To receive appreciation or praise for a choice we make. To think about the reward of a certain (difficult) decision. Difficulties to choose because all the options are similarly nice.

**Bouquet-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
False compliments, someone is kissing ass. False friendliness.
Something which used to be nice is slowly being corrupted, getting stale, becoming foul. Lack of social life. A conflict between having very little and wanting to be generous. To ruin something nice. To spoil things for others. An unwholesome concern with aesthetics.

**Bouquet-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
A very loving, very affectionate, friendship. The love for one's friends. A kind gesture, a compassionate act. To humbly ask someone's forgiveness, or to generously offer someone forgiveness. To flatter someone, to be nice to someone, in order to win their love or forgiveness. To have one's heart in social life. Infatuation with someone because of their beauty; to give our heart to someone just because they are nice to us. "Love" which is conditional on the other person giving presents (or time, or admiration). Flirtatiousness. To dress up for a lover (or, to attract someone new).

**Bouquet-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Social connections, social ties, social commitment. To be bound together by friendship. A promise to visit someone more often. Shared taste, shared aesthetics. Connections/affiliations which make us look good. Cohesion through being nice to each other. To exaggerate commonalities. Glorified relationship.

**Bouquet-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To share knowledge; to be invited in on a secret. Praise of knowledge, praise of one's study efforts. To study interior design or other trainings which have to do with beauty, design, fashion. Facts or knowledge about beauty/design/fashion. The truth behind the flattery. To categorise something as compliments, pretty, pleasant, flattery etc.

**Bouquet-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Letter of congratulation; to pay compliments; flattery. To invite or to get invited. To let someone know they are welcome. To express gratitude/appreciation. Communication in one's circle of friends - possibly communication on Facebook if it's not public to all. To mince one's words; to say something in a roundabout way; to beat around the bush. To express oneself only in nice ways other people appreciate (whether this fulfils one's own needs or not). Styling which expresses something, which is supposed to deliver some information (e.g. about one's availability, or class).

**Bouquet-Man (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Man who is: invited; on a visit, convivial, sociable; socially active. Man who is affable, well-mannered. Man who is appreciated by the querent, or generally praiseworthy. Man who is flirtatious, or ingratiating. Bootlicker. Handsome man; groomed man. A peacock. Man who tends to exaggerate or whitewash things. A welcome visitor, a host. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a man; to flatter or flirt with a man or men in general. To visit a man; give a present to a man.

**Bouquet-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Woman who is: invited; on a visit, convivial, sociable; socially active. Woman who is affable, well-mannered. Woman who is appreciated by the querent, or generally praiseworthy. Woman who is flirtatious, or ingratiating. Bootlicker. Pretty woman; groomed woman. A peacock. Woman who tends to exaggerate or whitewash things. A welcome visitor, a hostess. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a woman; to flatter or flirt with a woman or women in general. To visit a woman; give a present to a woman.

**Bouquet-Man (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Man who is: invited; on a visit, convivial, sociable; socially active. Man who is affable, well-mannered. Man who is appreciated by the querent, or generally praiseworthy. Man who is flirtatious, or ingratiating. Bootlicker. Handsome man; groomed man. A peacock. Man who tends to exaggerate or whitewash things. A welcome visitor, a host. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a man; to flatter or flirt with a man or men in general. To visit a man; give a present to a man.

**Bouquet-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Woman who is: invited; on a visit, convivial, sociable; socially active. Woman who is affable, well-mannered. Woman who is appreciated by the querent, or generally praiseworthy. Woman who is flirtatious, or ingratiating. Bootlicker. Pretty woman; groomed woman. A peacock. Woman who tends to exaggerate or whitewash things. A welcome visitor, a hostess. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a woman; to flatter or flirt with a woman or women in general. To visit a woman; give a present to a woman.

**Bouquet-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To go to a private view or theatre with others; to make music with others; artist group. Praise for someone's artistic accomplishments. Positive art reviews. Harmonious (interior) design; physical embellishments or verbal niceties with the goal of creating harmony. To give someone a sexy love letter / to get given a love letter. Thankfulness for the comfort and pleasures one can enjoy. Intense thankfulness. A very generous lover.
Invitation to have sex; welcome sexual advances. Swinger party. Honest compliments or (possibly manipulative) flattery regarding sex.

**Bouquet-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Any virtue relevant in order to have friendly, harmonious, close relationships with other people: willingness to compromise, loving kindness, righteousness, compassion, altruism, generosity etc. To treat others well. Honest compliments; honest feedback. Presents with no strings attached; to give gifts not to get something in return but to make the other person happy. To behave virtuously in order to create an atmosphere in which everyone feels happy and safe.

**Bouquet-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Party, celebration, congratulation, joyful gatherings. Superficial friendliness. Celebration of friendship; to find joy in cultivating friendships. Warm compliments, positive feedback. Great praise or appreciation. Pretty only on the surface. To please somebody. Making other people happy makes you happy, too!

**Bouquet-Moon
 [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Profound gratitude; very sincere compliments. Emotional visit; emotional compliments. Recognition causes deep emotions. To visit someone who is sad. Someone visits when all we want is to rest. To rest from social situations. Social phobias. A beautiful night. Exaggerated emotionality; to exaggerate a fear/need.

**Bouquet-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To open one's door to others. To accept compliments and praise. Welcome attention; a welcome visitor. To let beauty into one's life. Means to appear beautiful to others. Exaggerated welcome. Inclusive standards of beauty. The key to a healthy social life. To think that if you want to succeed you have to flatter others. Someone gets what they want by flattery or bribery - or, by being nice to others, in an honest way. An imminent visit or social situation.

**Bouquet-Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
To be very generous, to give away gifts or money. To receive a lot of flattery because people want your money (or other things of worth they feel you could give them). To view friendship as currency; to be friendly out of calculation (to gain something).
Bribes (not necessarily financial in nature).

**Bouquet-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Focus on aesthetics. Stable circle of friends. To find safety in social niceties. To stick with pleasantries. To be confined/restricted by having to be nice. Pleasant status quo. Nice, pleasant stop or break. To welcome a break. To make a stay / residence pleasant.

**Bouquet-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
Social life or some aspect of it (e.g. a visit) feels like a burden. Friendliness, and/or being likeable, is our foremost duty. To be friendly on principle. To see it as our task to make things nice for others. The burden of always having to to please others. Generosity is a duty. Fateful visit. To compliment someone's dutifulness. Gratitude for someone's shouldering a burden / taking responsibility. To make someone's suffering easier for them; to help them forget their pain for a while by doing something nice. To present a pretty facade even when one is suffering inside.

**Bouquet - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)**
The ugly duckling. Something not pleasant or pretty yet; to be uninvited - yet; yet unsociable. A question mark regarding one's social life. It could be flattery or honest compliments - it's not clear yet. Not rewarded yet; not praised yet. To glorify indefiniteness or indetermination; to gloss over question marks. A (possibly genderqueer) person with the attributes of the Bouquet (see the Bouquet's keywords).
