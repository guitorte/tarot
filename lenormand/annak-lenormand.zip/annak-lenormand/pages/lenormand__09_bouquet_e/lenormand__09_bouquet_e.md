---
title: "lenormand | bouquet | keywords"
source: https://www.annak-tarot.at/lenormand/09_bouquet_e.html
---

**BOUQUET 9**

**Keywords**

***Nouns / phrases:***

Visitation, invitation, social life, conviviality, regalement, cultivation
of friendship(s). Gifts, generosity. Affability, pleasantries, cordiality. Etiquette,
good manners, polite platitudes. Appreciation, recognition, thankfulness.
Congratulate, reward. Compliments, admiration, flirt. Flattery, honeyed words,
bootlicking. Decoration, design. Perfume, jewellery, make-up, new hair style.
Prettiness, (conventional) beauty. Embellishment, hyperbole. Window dressing,
euphemism, glorification. Traditionally also: happiness, creativity and art, sex.

 ***Activities:***

To visit, invite, socialise. To cultivate friendship(s). To give a present, regale. To act
courteously. To thank, show appreciation, congratulate, reward. To compliment, admire, flirt. To
flatter, suck up to someone. To decorate, design. To make oneself look/smell nice (to dress up;
style one's hair). To embellish, elaborate, exaggerate. To glorify, sugarcoat.

 ***Attributes:***

Invited; on a visit. Convivial, sociable. Given as a gift, generous. Appreciative, pleased.
Affable, pleasant, cordial. Well-mannered, according to etiquette, courteous. Admirable, commendable.
Flattering, flirtatious, ingratiating. Decorated, conventionally pretty, fragrant, melodious.
Well-dressed, tarted up. Embellished, hyperbolic. Glorified, euphemistic.
 **As a person:**  Person with the above attributes. A welcome visitor, a good hostess or host. Peacock.
Interior designer, hairdresser, stylist, plastic surgeon. Bootlicker. **As advice:**
 Be nice/more sociable! Visit/invite! Watch your manners! Show appreciation! Tend to
your appearance! Negatively: Don't exaggerate / stop sugarcoating! Don't be vain!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When etiquette allows; or when it pleases. When in good company. On a visit.

 **See also** the *annakblogs* article [>> So, is the Bouquet a mainly positive card, then?](https://annakblogs.wordpress.com/2017/12/16/light-shadow-bouquet/)
