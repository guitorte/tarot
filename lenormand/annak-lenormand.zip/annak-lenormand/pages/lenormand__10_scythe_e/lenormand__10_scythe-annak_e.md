---
title: "lenormand | scythe | interpretation"
source: https://www.annak-tarot.at/lenormand/10_scythe-annak_e.html
---

scythe
 **INTERPRETATION**

*Reaping; cleaning; severance; efficiency;
sudden*

**About the meaning:**
All following interpretations are derived from the scythe's usage as a cutting/harvesting tool.

*Harvest / reaping / reckoning*: A
scythe is a tool for harvesting crop.
So metaphorically, the Scythe stands
for experiences in which we reap what we ourselves have sown - either
in a good or in a bad way. It can be the card that says that we deserve what we've gotten; that we ourselves caused what happened to us. The Scythe can be saying "I told
you so!"
But also, the Scythe can stand for a time of reckoning,
a time in which we take stock of what we have achieved so far,
in order to then say good-bye to the past and move on from there
with a clean slate. It can represent things we need to do in order to find closure. In many cases, the Scythe can indicate a certain urgency. It can mean that it's time to see ourselves alright. And the Scythe may also represent more physical or definite acts of closure, like a final exam, or a letter of resignation.

*Cleaning / to tidy up*: Apart from harvesting, scythes are also used for cutting overgrowing grass - for "tidying up" pastures or yards. So the Scythe could represent both tidying up in a literal sense (one's work place, for example, or one's home) but also metaphorically for tidying up messy areas of one's life. Sometimes the Scythe suggests to get rid of accumulated clutter, or to cut down on something there's an unnecessary surplus of. It can also mean that it's time to tie up loose ends.

*Severance / abruption / cut off:* Scythes have very sharp blades; and they are built to cut off grass or corn efficiently and precisely. Thus, the card can mean that it's time to put a quick, unfussed end to something, or that someone or something is being cut off or out of our lives. It can stand for parting ways, for break-ups and divorce, for quitting a job, or for discontinuing something, e.g. a habit or addiction - especially in the sense of a cold withdrawal. The Scythe can indicate interruptions of any kind - a simple example would be that someone's word is being cut off.

*Efficiency*: Well-made, well-maintained scythes are very, very efficient. They enable a person to mow a wide patch of grass with one single, comparatively effortless swipe. Thus, the Scythe can also be the card which addresses issues to do with efficiency. For example, the Scythe can be interpreted as a hint to think very rationally about what are the best means for reaching a specific goal, or that we need to take care to waste as little of our resources as possible, to conserve energy, while *still* doing all that needs to be done, and doing it well. In that sense, also, the break-up the Scythe can stand for, the cut it can represent, will often be one in the sense of a "clean" cut - a very definite, efficient severance.

*Painfully sudden / dangerous / injury*: Because of the sharpness of a scythe's blade, and the quickness of its movement, the Scythe can also stand for anything that happens painfully quickly, is sudden in an unpleasant way, or sharp, "cutting". It can for example stand for suddenly occurring pain, for an unexpected and therefore seemingly abrupt hurt or injury. In a way, the Scythe can mean that we're yet unprepared for something that will happen to us. The Scythe can represent danger - especially the danger of being hurt. It can be interpreted as a warning.

 **See also** the *annakblogs* article [>> So, is the Scythe a positive or negative card?](https://annakblogs.wordpress.com/2017/12/19/light-shadow-scythe/)

**About the Image:**
 There were two reasons why it was important for me to depict a scythe that is being used.
Firstly, so many of the Scythe's meanings imply activity - imply that certain actions are *being taken*. The Scythe is not so much about the result of these actions - except maybe the short term results, like the immediate pain a cut-off causes, but definitely not about long term results. It is much, much more about the acts themselves. It is about the act of tidying up, cutting off, and it describes how these acts are done: quickly, efficiently. Depicting a scythe propped up somewhere in a corner, with cut corn already neatly arranged in bundles, would have made the image about the results instead of the action. So I painted a person wielding a scythe, a scythe in the process of doing the cutting. Short term results like a painful injury are still implied because the blade is obviously dangerously sharp.
Secondly, a Scythe that is lying around didn't seem very dangerous to me; it won't cut you; there is no quick movement involved - except if you overlook it and trip over it.
Furthermore, there are dark clouds in the background - you can either view them as a magnifier for the sense of danger in the card. Or, they could be taken as as a hint that we need to see ourselves alright before it is too late - we need to harvest before the hail comes and destroys the crop.
