---
title: "lenormand | scythe | comparisons"
source: https://www.annak-tarot.at/lenormand/10_scythe-comp_e.html
---

scythe

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Scythe, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Endings**

|  |  |
| --- | --- |
|  | **Scythe**: To end something quickly, efficiently, possibly prematurely or unexpectedly - e.g. a termination, disruption. Someone cuts themselves out of our life; cuts us off. The physical or emotional injury when something is cut (off). |
|  | **Coffin**: Natural end; death. Something is over for good. The grief we feel over an ending. |

 **Injury**

|  |  |
| --- | --- |
|  | **Scythe**: Injury, or pain, are only the by-product of an accident, of a break-up, or severance etc. |
|  | **Whip**: Pain is inflicted, injury is caused, on purpose, e.g. as punishment, or out of aggression. |

**Suddenness/quickness**

|  |  |
| --- | --- |
|  | **Scythe**: Quick in the sense of sharp, efficient, "cutting". Suddenness which hurts us because we weren't prepared. |
|  | **Rider**: Quick in the sense of "hurried"; suddenness which overwhelms us because we were caught by surprise. |
|  | **Birds**: Quick to react; quick-wittedness. Quick reactions to sudden occurrences. |

 **(Dis)connect**

|  |  |
| --- | --- |
|  | **Scythe**: To disconnect, to sever a tie, to break up a relationship. |
|  | **Ring**:To connect, to link, to enter into a relationship. |
