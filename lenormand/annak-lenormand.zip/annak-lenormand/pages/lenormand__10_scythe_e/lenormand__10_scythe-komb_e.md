---
title: "lenormand | scythe | combinations"
source: https://www.annak-tarot.at/lenormand/10_scythe-komb_e.html
---

**COMBINATIONS WITH THE
SCYTHE**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Scythe-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Sudden and/or painful news; unexpected changes. Change which happens too quickly so it hurts. Something happens extremely quickly with no chance of prevention. Or: to quickly shut down someone's advances/attempts at meddling. To interrupt a message (an attempt to bring news, or change). To act quickly (before it's too late). Pushy person who cuts other's words off or interrupts/disrupts them constantly in other ways.

**Scythe-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Grab at it quickly, before it's too late! To take a real risk (negative outcome would be painful!). To count one's blessings. Something totally unexpected but nice. The hurt is not that deep, don't take it too seriously! Well-deserved luck. Well-deserved period of untroubled ease after dealing with something rigorously. To take something urgent not seriously enough.

**Scythe-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To cut off ties with someone and leave them behind (or, someone does this to you). Painful (possibly premature) good-bye. To tidy up loose ends before a departure. A sudden departure; a very sudden decision to change something. Unexpected journey. Sudden (painful, disruptive) end of a search or exploration. To cut off the old; to cut off anything and anyone who holds one back. Disrupted journey. Premature end of something which was still moving, changing. An adventure or exploration which might get you hurt.

**Scythe-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To discontinue a habit. To settle old scores within the family. To sever some or all family ties. To take stock of which tradition/rules one wants to follow because they're good, and which one wants to discard because they are unproductive. To terminate a lease agreement / lease agreement is terminated. Urgent family matters; something urgent concerning home(life). To tidy up one's home. Efficient plan. To be pulled/pushed away from where we feel comfortable and safe.

**Scythe-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Physical wounds or pain; difficult medical treatment or surgery. Amputation. Something one has been doing to one's body is now (or will soon be) taking its toll (or, positively: showing its benefits). To take stock of one's health - medical check-up. Damage to health or energy reserves. Disruption of serenity. To pull the rug out from under someone. To react calmly to sudden/painful experiences.

**Scythe-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To eliminate confusion; to tidy up and put an order into anything that is unclear. Unexpected confusion; sudden disorientation. Because something was ended prematurely there now is confusion. To react to a break-up or sudden ending with despair or disorientation. To interrupt at once when there seems to be the slightest misunderstanding. We've caused the confusion or insecurity ourselves. To yank someone out of their despair. To rip the veil off; to drop all pretence. Someone's secrets could be dangerous for us. And for some reason, for me this combination also seems to suggest headaches or even migraines.

**Scythe-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To stop being so ambitious; to discontinue a career. To stop before the goal is reached. Disrupted career. To work very hard towards reaching the finish line. Sudden cravings. Binge drinking/eating. A warning: be careful about what you reach for - you might get hurt!

**Scythe-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
A very sudden or unexpected ending; painful break-up, fatal accident, murder. Premature end. To take stock of one's life in order to decide what one wants to leave behind. A clean break. Cold withdrawal. To put a stop to something with finality. As advice: put an end to [x] right now!

**Scythe-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Unexpected visitor or invitation. To put an end to flattery; to cut off compliments. to reap praise or other benefits for something one has done.
To be nice in order to get something. Pleasant surprise. To clear something out; to tidy up in order to make things nicer.

**Scythe-Scythe[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Sudden interruption, unexpected end, painful cut. Dangerous disruption. To cut someone off very quickly with no hesitation. To tidy up lose ends in a hurry. Very thorough clean-up. Danger! Deserved hurt.

**Scythe-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Imminent danger, threats. Sudden aggression, painful (possibly unexpected) conflicts; to (finally!) own up to something and take responsibility and pay due retribution. To end an abusive relationship or situation. To handle arguments/conflicts by cutting the other person (or their word) off. To hurt someone on purpose. To self-harm in an attempt to get rid of shame or guilt.

**Scythe-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)**
To react quickly to danger, to warnings, or to anything that happens suddenly - to be on alert, aware of danger. Worries about something that might end, or worries about getting hurt. Act quickly now and see yourself alright! To cut off somebody's word; to prohibit gossip. To put order in the chaos, to get rid of clutter and junk, to shut off the noise.

**Scythe-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Growing danger; growing urgency. Naivety might get you hurt; an injury caused by inexperience. Someone who had to grow up too soon. To break off contact with a child. Hurt child, injured child. Possibly a miscarriage; more fitting: an abortion. Playfulness/curiosity is very suddenly and painfully stopped.

**Scythe-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To weigh the risk(s) carefully. If something is not good for you, cut it off! Inconsideration, ruthlessness. To be careful not to get hurt. To put an sudden, strict end to something in self-defence. To hurt someone else in self-defence / someone defends themselves in a way which hurts you. Self-defence or self-care is cut off (hindered). The benefits of proper self-care / the consequences of selfish behaviour. Self-inflicted pain. To pull oneself together.

**Scythe-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To discontinue a dominant habit. To break away from a dominant parent, teacher, partner, or boss. To radically stop trying to influence something. Parents' divorce.
To harvest (hoard, pile up things, earn and save money) now, as a cushion for hard times. Powerful sense of urgency. To put every ounce of strength into finishing something *now*. To end something in order to protect (yourself or others). To put things in order so as to provide/set direction for the future, e.g. to make a will.

**Scythe-Stars[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To take stock: which of one's dreams have been fulfilled so far, which does one still want to try and fulfil, and which should be given up on? To discontinue wishful thinking.
Painful confrontation with bland reality. Sudden loss of hope. Interruption of daydreams. To cut down on what we believe the ideal is.
To discontinue something old in the hope of gaining something new which is more meaningful. A deeply meaningful cut or break-up. To find deeper meaning in having been emotionally hurt or physically injured.

**Scythe-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Disruption of a transformation process. Ongoing process is cut short. Unexpected, sudden, painful longing. Painful longing to be or do something else. A cut, break-up, or injury, which causes profound transformation within oneself. Even if something has ended prematurely we eventually have to let go and move on in whatever direction now feels right to us. To move on from a painful experience. Recurring injury or hurt. Getting hurt is inevitable. The natural cycle of sowing and harvesting (metaphorically speaking). The attempt to return to something (or someone!) that was cut off. When we are on the threshold to something new it's important to take stock, settle old scores,
settle accounts with our past, before we actually take the step across the threshold.

**Scythe-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To discontinue (or disallow) overly devote behaviour. To stop following someone or something. To cut off a friend, or to be cut off by a friend. Dogged efficiency. To stay "loyal" to breaking a (bad) habit. Deserved loyalty. to reap friendship. Help with cutting something or someone off. Abrupt, harsh treatment of someone who is just trying to be friendly. The wish to stay friends after a break-up.

**Scythe-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To cut off others emotionally. No more contact. A very unemotional, clear, rational act or decision. Highest efficiency. Efficiency through rationality. Rational way of putting an end to something; or, it's rational to discontinue something. Painful loneliness. Painful loss of pride or dignity. Disciplined clean-up. To stop letting something or someone have authority over you. To cut off (to lose) a position of authority. To rise above an injury. To react with dignity to an inflicted hurt.

**Scythe-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To shut out the public; to discontinue involvement in social networks; hurtful experiences with the public, harsh public opinion. Efficiency through networking. Efficient network. To present oneself as efficient. To make a break-up public. Public announcement of a cut/of putting an end to something. Public pain/hurt. Sudden, unexpected publicity. Well-deserved public opinion. No more publicity.

**Scythe-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To break the silence. To
suddenly start moving again. To make a painful decisions unemotionally, coldly. A very difficult act of severance. For a long time nothing happens - but then it will happen extremely quickly. To be surprised by the suddenness of something after a long period of standstill. In order to get things moving again you have to be quick, not hesitate even a bit, and maybe risk pain (a tear off the band-aid quickly situation). To get over something.

**Scythe-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Hurt caused by a choice. Very fast decision making. Unexpected choice; sudden and maybe dangerous freedom. Interruption of decision making process or deliberations in general. To take stock of what one's alternatives are. To eliminate one or several alternatives. Urgency: Don't wait any longer with making a decision! Free will /freedom of choice is taken away.

**Scythe-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To have a good look at what's going wrong. To discontinue unhealthy habits. Self-caused negativity; to reap negativity. Something or someone is taking away from what one is due.
Be careful: theft/corruption/blackmailing is going on! To get rid of corruption/dirt. To clean up, literally. Sudden or painful loss. Something is cut away sneakily, behind one's back. Low efficiency; dwindling efficiency.

**Scythe-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Heartache. Sudden end of a romantic relationship; divorce. To cut oneself off from one's own tender feelings. To take stock of one's feelings for someone - are they appropriate, justified, or should they be discontinued? Act now, or it'll be too late for love / reconciliation! to reap love / tenderness / forgiveness. To come clean about one's loving feelings. To discontinue something in a kind, compassionate way. To react with compassion to hurt / injury. To care for someone who is (physically or emotionally) wounded. Your softness might get you hurt! A dangerous infatuation. Divorcee.

**Scythe-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To break a promise, breach a contract, discontinue a commitment, sever ties. Divorce, break-up. To stipulate a severance contractually. An agreement to end something. to reap as benefit of one's efforts a committed relationship/a formal contract. Commitment to tidying up. To take stock of a relationship: which bits are good/bad, productive/unproductive, worthy of continuing and which not? Sharing the work makes it more efficient.

**Scythe-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Knowledge about danger and risk. Painful truth; to be hurt by the truth. To learn something suddenly or unexpectedly. To take stock of what one knows. Final exam. Education or learning process is interrupted / ends prematurely.

**Scythe-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To stop communicating. To cut someone's word off; to get interrupted. Interrupted communication. A conversation which ends prematurely. Extremely to the point (even harsh, curt) conversation. To not beat about the bush but make things very clear ("tidy"). To wrap up an argument. To sum things up (for someone else); to state clearly what's what. To inform someone about a conclusion one has made / to be informed about a final result. Letter of resignation, final exam, divorce papers, suicide note.

**Scythe-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Man who is: efficient, blunt, does unexpected or hurtful things. Man who has cut you off. A male ex-partner. Divorcee. To cut off or hurt a man. Man reaps what he has sown. To get what you deserve from a man. To tie up lose ends or settle scores with a man. Man cleans up. Man with a sharp tongue /who can hurt you.

**Scythe-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Woman who is: efficient, blunt, does unexpected or hurtful things. Woman who has cut you off. A female ex-partner. Divorcee. To cut off or hurt a woman. Woman reaps what she has sown. To get what you deserve from a woman. To tie up lose ends or settle scores with a woman. Woman cleans up. Woman with a sharp tongue /who can hurt you.

**Scythe-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Man who is: efficient, blunt, does unexpected or hurtful things. Man who has cut you off. A male ex-partner. Divorcee. To cut off or hurt a man. Man reaps what he has sown. To get what you deserve from a man. To tie up lose ends or settle scores with a man. Man cleans up. Man with a sharp tongue /who can hurt you.

**Scythe-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Woman who is: efficient, blunt, does unexpected or hurtful things. Woman who has cut you off. A female ex-partner. Divorcee. To cut off or hurt a woman. Woman reaps what she has sown. To get what you deserve from a woman. To tie up lose ends or settle scores with a woman. Woman cleans up. Woman with a sharp tongue /who can hurt you.

**Scythe-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Dangerous (possibly harm-causing) handling of sensual pleasures; to get hurt in a sexual relationship. Sex injury. to reap pleasure only when you've put in the effort to gain experience first.
To suddenly lose a passion. To stop having sex. To end a sexual relationship. A long process comes to a sudden, maybe premature end. To have to deal with the self-inflicted consequences of gluttony (e.g. ill health) or risky sexual behaviour (e.g. sexually transmitted diseases).

**Scythe-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To radically, strictly, stop doing something for moral reasons. To clean something, to tidy up. A very thorough cleanup in a metaphorical sense. Virtues like orderliness and promptitude. The virtue of justice (because of the "you reap what you sow" aspect of the Scythe). To be so frugal there's hardly anything left; painful abstinence. To forgo something bad, to renounce something which is wrong. It's urgent - you need to do the right thing *now*!

**Scythe-Sun[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
to reap happiness. Joy about a good harvest (metaphorically speaking). The fun is over suddenly. Interrupted enjoyments. It's time to be serious! Killjoy. Cutting away unnecessary things, cleaning up, leads to ease, makes it possible to lighten up. To clear something up. To cut off anything which isn't conducive to one's happiness (or, less productively, to one's ease). Sudden end of confidence.

**Scythe-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)**
To stop moaning. Interrupted sleep/rest/quiet. To wake up suddenly in a figurative sense: to become conscious of something suddenly and painfully. Deep hurt; emotional hurt. to reap neediness/fear. To stop being so needy. To take stock of one's emotional state. To make sleep more efficient (e.g. through proper sleep hygiene). Rest is urgently needed, now! To deserve rest. Something rips right down to the core. A rift which goes deep.

**Scythe-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To leave oneself open to injury. Cleaning up (metaphorically speaking) will lead to the solution, to relief. To accept the consequences. to reap acceptance. To withdraw one's consent. Willing interruptions; to be open for putting an end to something. Efficient problem solving.

**Scythe-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To balance one's accounts; to settle financial affairs; to do one's tax return. To take stock: what do you have, what do you need, what can you spare? To part with money or possessions. Well-deserved profit. To cut away that which is too much.

**Scythe-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To end the status quo; to cut off one's fetters; to abruptly untangle oneself from restraints. To break off a relationship with someone who wants a long-term commitment. Sudden end/change of routine. Unexpected, sudden stop. To take stock of the status quo. Well-deserved or self-caused hold-up/break/residence/boring routine etc.

**Scythe-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
Something that very suddenly and maybe painfully challenges one's strongest beliefs. It's your responsibility to put a stop to X! Sharp, unexpected pain. To cut away a burden. To discontinue something out of a feeling of duty. Self-inflicted suffering. To take stock of one's life - of the good/bad things, of its purpose etc. Burdensome efficiency; pressure to be efficient.

**Scythe - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)**
To put an end to question marks; to cut off something (or someone) that is indeterminable. Question mark concerning what we will reap. Not yet ready to be harvested. A cut that hasn't happened yet. Still attached - yet. Yet untidy or cluttered. Yet inefficient. A question mark that comes up very suddenly and possibly unexpectedly. A (possibly genderqueer) person with the attributes of the Scythe (see the Scythe's keywords).
