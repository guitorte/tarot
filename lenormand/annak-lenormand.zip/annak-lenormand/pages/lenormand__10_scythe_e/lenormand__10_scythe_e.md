---
title: "lenormand | scythe | keywords"
source: https://www.annak-tarot.at/lenormand/10_scythe_e.html
---

**SCYTHE 10**

**Keywords**

***Nouns / phrases:***

Harvest, reaping (metaphorically speaking). Cleaning, tidying
up, a reckoning. Urgency. Severance, abruption, interruption. A cut, rupture, premature
end, abortion. Too sudden ending; cold withdrawal. Divorce, break-up.
Final good-bye. Anything which is sharp, quick, sudden. Efficiency; clean-cut.
(Possibly sudden and/or unexpected) hurt, pain, injury.

 ***Activities:***

To harvest, clean, tidy up. To tie up loose ends. To settle scores. To
reap (what one has sowed), deserve. To see oneself alright. To interrupt, to interrupt
someone speaking. To sever, cut something or someone off, put an end to something,
discontinue. To divorce, break-up. To get the best results while conserving one's resources; to use
the best means for reaching a certain goal.
 ***Attributes:***

Clean, sorted, tidy. (Well-)deserved; self-inflicted/self-caused. Urgent. Efficient. Unpleasantly
abrupt, painfully quick or unexpectedly sudden. Cut-off. Divorced, broken-up. Sharp,
painful, hurt, injured. Dangerous.
 **As a person:**  Someone with the above attributes. Ex-partner, ex-friend, family member who has
been cut off. A person who has (or would be able to) hurt us quite suddenly. Someone who is blunt
or wants to do things too unexpectedly for our liking. **As advice:**
 Stop it, immediately! Watch out! Be careful you don't get cut! Get moving now, or else
it will be too late! Tidy up! Be careful: You reap what you sow!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Suddenly and quickly - possibly too soon. In time (for); just in time.

 **See also** the *annakblogs* article [>> So, is the Scythe a positive or negative card?](https://annakblogs.wordpress.com/2017/12/19/light-shadow-scythe/)
