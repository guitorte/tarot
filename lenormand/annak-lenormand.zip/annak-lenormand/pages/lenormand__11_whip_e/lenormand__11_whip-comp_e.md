---
title: "lenormand | whip | comparisons"
source: https://www.annak-tarot.at/lenormand/11_whip-comp_e.html
---

whip

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Whip, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Pain, injury:**

|  |  |
| --- | --- |
|  | **Whip**: Pain is inflicted, injury is caused, on purpose, e.g. as punishment, or out of aggression. |
|  | **Scythe**: Injury, or pain, are only the by-product of an accident, of a break-up, or severance etc. |

 **Control of others through:**

|  |  |
| --- | --- |
|  | **Whip**: Violence, verbal attacks, threats. |
|  | **Bear**: Dominant personality, charisma. |
|  | **Tower**: Position of authority. |
|  | **Snake**: Diplomacy, or manipulation. |
