---
title: "lenormand | whip | keywords"
source: https://www.annak-tarot.at/lenormand/11_whip_e.html
---

**WHIP 11**

**Keywords**

***Nouns / phrases:***

(Verbal) conflict, arguments, discussions, debate. Scolding,
scathing critique. Confrontation, accusation, objection, opposition. Aggression;
threats, bullying, abuse. Infliction of pain, hurt by the hands of others, wilful
destruction, something which is broken. Unpleasant consequences, punishment.
Vindictiveness, revenge. Cry for justice, amends, compensation. Guilt, remorse.
Shame, self-hatred. Scorn, cynicism. For some readers also: clean-up, clean
sweep.

 ***Activities:***

To argue, discuss, fight. To scold, critique. To take flak. To confront, accuse, object,
contradict. To act aggressively, threaten, bully, abuse. To inflict pain, get hurt, destroy, break. To
punish, take revenge, demand justice. To repent, regret, make amends. To feel guilty/ashamed, or
to blame or shame. To scorn. For some also: To clean up, make a clean sweep.
 ***Attributes:***

Argumentative, conflicted, antagonistic, contradictory, contrary. Confrontational,
accusing. Aggressive, threatening, abusive. Destructive. Broken. Culpable. Punitive, vindictive.
Guilty, remorseful, shameful. Compensatory; just. Cynical, scornful. **As a person:**  Someone with the above attributes, e.g. someone with a sharp tongue; contrarian,
accuser. Someone who is aggressive; abuser. Prosecutors, lawyers, judges, police. - anyone who
deals out punishment or restores justice. Someone who is, or feels, guilty. **As advice:**
 Fight the good fight! Fight back! Challenge or confront it/them! Make amends! Negatively:
Stop beating yourself up! Don't hurt others!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When it hurts; when remorse demands it; when justice calls for it.

 **See also** the *annakblogs* article [>> So, is the Whip a purely negative card?](https://annakblogs.wordpress.com/2017/12/26/light-shadow-whip/)
