---
title: "lenormand | birds | comparisons"
source: https://www.annak-tarot.at/lenormand/12_birds-comp_e.html
---

birds

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Birds, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Stress**

|  |  |
| --- | --- |
|  | **Birds**:  Stressful situations and hectic behaviour. |
|  | **Mice**: The (health or mental) damage stress causes. |

 **Communication**

|  |  |
| --- | --- |
|  | **Birds:** Communication in the form of idle chit-chat, gossip, oversharing. To talk over each other. Quick, short (and possibly unproductive) communication like text messages, or twitter. |
|  | **Letter**: Communication in general, with a clearer description of its quality or content rendered by the surrounding cards. The need to communicate, or express, something (feelings, facts, or arguments). To allow oneself to speak openly about something. |

**Secrets**

|  |  |
| --- | --- |
|  | **Birds**:  To blab a secret. |
|  | **Clouds**: Something is being hidden from view, fogged over - not necessarily with bad intentions, possibly just for self-protections or out of shame. |
|  | **Mice**: Harmful and/or malicious secrecy. Something is being done behind someone's back. Sneakiness. |
|  | **Book**: A "secret" in the sense of esoteric knowledge - not everyone has access to some type of knowledge or information. |
|  | **Key**: The opposite of secretiveness: openness, straightforwardness. Or: to find access to a secret. |

**Change**

|  |  |
| --- | --- |
|  | **Birds**: Constant change; nothing ever sticks - fickleness. Erratic changes. |
|  | **Ship**: Changes *we* set in motion. A change of environment. Changes which take some work. |
|  | **Stork**:Change in the form of a transformation. Inner change; e.g. change of heart. Changes dictated by the inner nature of things. Changes which happen gradually. |
|  | **Rider**: Change is brought to us; changes that happen without our doing. Sudden or enforced changes. |
|  | **Anchor**: The opposite of change: stability or stagnation. Everything stays the way it is because we are able to maintain, are holding on to, or are restrained from changing, the status quo. |
|  | **House**: The opposite of change: regularity. Everything stays the way it is because we always act according to tradition or our personal habits, and/or don't allow innovation. |
|  | **Mountain**: The opposite of change: permanence. Everything stays the way it is because we won't budge. |

**Mental/emotional issues**

|  |  |
| --- | --- |
|  | **Birds**:  Issues to do with extreme stress, worries, difficulties with concentration: e.g. nervousness, anxiety, obsessive compulsive behaviour, ADHD. |
|  | **Moon**: Mental/emotional issues to do with the "dark" part of our soul - fear, sadness, needs. E.g. phobias, depression, PTSD. Also: Sleep disorders. |
|  | **Clouds:** Problems which arise from a clouded view of reality, e.g. misunderstandings; lack of understanding, disorientation; illusionary thinking, hallucination, or paranoia. Also: Abandonment issues (because of the "lack of guidance" aspect of the card). |

**Haste**

|  |  |
| --- | --- |
|  | **Birds**:  Bustle, hecticness. Superficial, quick acts which are quickly over. |
|  | **Rider**: Hurry, rush - especially in the sense of pressing someone or pressing for something, or of taking action quickly. |
|  | **Lily**: The opposite of haste - to take one's time. Slowness. Very intense experiences. |
|  | **Tree**: The opposite of haste: very slow kind of person or way of acting - because of a great deal of physical and mental calm - or an unwillingness or inability to move quickly. |
|  | **Mountain**: The opposite of haste: the refusal to move at all, ever. |

**Quickness/suddenness**

|  |  |
| --- | --- |
|  | **Birds**:  Quick to react; quick-wittedness. Quick reactions to sudden occurrences. |
|  | **Scythe**: Quick in the sense of sharp, efficient, "cutting". Suddenness which hurts us because we weren't prepared. |
|  | **Rider**: Quick in the sense of "hurried"; suddenness which overwhelms us because we were caught by surprise. |
