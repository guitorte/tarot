---
title: "lenormand | birds | combinations"
source: https://www.annak-tarot.at/lenormand/12_birds-komb_e.html
---

**COMBINATIONS WITH THE
BIRDS**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Birds-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Worries about news or changes; hurried or reasonably swift preparation to change. Chaotic/messy approach. Invasive thoughts, obtrusive chatting. Overwhelming chaos or hecticness. To react with alarm to someone's advances or a looming change. An intruder/news/change causes alarm or instability. Someone brings instability or chaos with them (e.g. spreading their own messiness all around). To be on constant lookout for attacks.

**Birds-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Great excitement about a lucky coincidence or about an opportunity.
You need to react quickly - jump at it or you'll miss it! Worries about whether one'll get lucky. Worries which one shouldn't take that seriously. An irresponsibly unstable way of living. Inability to settle because of a constant alertness for new opportunities. Quick witted humour. Worries about a happy-go-lucky person. Opportunity for gossip.

**Birds-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Strong wanderlust; inability to stay put. Nervousness or worries
about a pending journey, venture, or change. Excitement about a journey, venture, or change. An unorganised journey, venture, or change. Chaotic departure. To leave chaos behind. Worries that someone might leave. Someone is busy exploring. The attempt to change everything at once. Constant change of direction. To leave a stressful situation. Someone's constant nagging, talking, or worrying, drives someone else away.

**Birds-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
(Probably unstructured, chaotic, hectic) communication in the family. Messy home. Stressful family life; worries about family/home.
Chaotic family life or living situations.
No peace at home. Flexible family life. Quick reactions in matters concerning family. To feel unsettled
because one is disconnected with one's family, or tradition. Structure and plans help in chaotic/stressful times. Difficulties with settling down. To never be sure that we are safe.

**Birds-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Energy all over the place. To not know what to do with one's physical energy. The physical aspect of stress and/or the toll it takes on the body. An unsettled mind makes it difficult to be grounded. Pragmatic approach to a chaotic situation; to tackle a stressful situation with calm. The advice to find a way to ground oneself in stressful times. Conflict between wanting to put down roots and feeling restless or unable to settle down. The root of one's nervousness. Deeply rooted nervousness.

**Birds-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Distant rumours; secret gossip. Great worries about an unclarity. Unfocused rambling; aimless straying. Not knowing makes us restless. To be so chaotic that every
sense of direction is lost. To blab a secret. Boredom leads to restlessness. To hide one's nervousness. Dulled reflexes; dulled excitement. To be startled out of one's stupor.

**Birds-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Lobbying. A conflict between really wanting
something and being distracted from it. To want too many different things at once. To not know in which direction one should move, what decision to make.

**Birds-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
End of chaos. To let go of something which causes stress. Great worries about losing something or someone. Loss of agility/flexibility. To react with sadness/grief very quickly. Chattiness ceases. To repress one's worries. To bury oneself in things to do. Keeping busy as a way to cope with grief.

**Birds-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Chat and gossip
in our social circle. Worries about a visit or an invitation. (Noisy/chaotic) party or gathering. To be full of happy but chaotic thoughts. Someone is so admiring that it annoys the admirer. Attempts to be pretty for or nice to everybody in all kinds of ways. Fluctuating views on what is beautiful. Pretty platitudes.

**Birds-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
To react quickly to danger, to warnings, or to anything that happens suddenly - to be on alert, aware of danger. Worries about something that might end, or worries about getting hurt. Act quickly now and see yourself alright! To cut off somebody's word; to prohibit gossip. To put order in the chaos, to get rid of clutter and junk, to shut off the noise.

**Birds-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
To be very nervous about feedback/criticism; to be on the alert for threats. Mikroaggressions that in sum become very harmful. To keep brooding about actual or perceived insults, to be unable to let go of them. To expect apologies too soon. Constant nagging; bickering. Anxiety disorder. To be conflicted. Destructive stress. Nervousness caused by the experience of violence. Worries about a conflict. An argument about a messy situation. A messy argument. Guilty conscience never shuts up. Embarrassment. Hurtful gossip.

**Birds-Birds [\*)](https://www.annak-tarot.at/lenormand/star_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Total chaos, an unorganised mess. Unstructured conversations. Worries about gossip. Very, very alert. To try and do everything at once, in a flurry. Multitasking causes stress. Very, very restless. High Anxiety makes it impossible to ever calm down.

**Birds-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Baby talk, childish talk. Young person learns to communicate. Noisy children. Beginning unrest. Worries about something which is beginning, or about a young or inexperienced person. Something new has been unsettling us. Wanting to try everything, and refusing to focus on any one thing, has made it impossible to become experienced at anything. First stages of chaos. Chaotic beginning. Worries about inexperience. Immature worries. A child necessitates multitasking.

**Birds-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Conflict between cautious discretion and wanting to blab. To be overly watchful, alert, and nervous about something or everything. To be jumpy and suspect everything and everyone. Self-centred worries; thoughts which circle constantly about oneself. Unstable sense of self; messy, chaotic identity. Worries about safety. Difficulties with concentrating on that which is vitally important. Worries about something one deems vitally important. Proper self-care in times of stress and chaos.

**Birds-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Overly excited, or very unstructured, communication with parent, boss or teacher. A very nervous, worried, or distracted parent/teacher/boss - or gossip about them. Someone nervous and unsettled needs a strong, protective person to help regain balance. Emotions go high very quickly and subside just as quickly again. Power fluctuations. To be nervous about having to lead. To react protectively quickly (*maybe* too quickly).

**Birds-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Fickle trust, fickle ideals. Erratic faith. To see meaning in chaos. To turn chaos into something meaningful. To find the meaningful bits in the chit-chat. Too many ideas at once; unstructured vision. To get distracted from following one's dream. To envision chaos, to imagine stress before it happens. Overactive imagination causes nervousness.

**Birds-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Someone acts very instinctually - shows knee-jerk reactions constantly. Necessity to completely change our way of communicating. To let others know about a transformation that is going on inside ourselves. Excitement, nervousness, or worries, about a transition. A very chaotic, unsettling time of transition. Worries we have again and again either because worrying is part of our nature or because we never do anything about the root of the problem. Restlessness because what we really want is to go back (return) to where we truly belong. Quick (or knee-jerk) reaction to someone's having changed. Someone changes themselves easily without much thought. Many changes at the same time. One person's transformation (or return) causes chaos for someone else.

**Birds-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Excited, nervous or stressed friend or employee. Gossip about a friend or a friend gossips about you. Loyalties constantly change. To keep forgetting about a friend; forgetful friend. Worries about a friendship or about someone's loyalty. To be very easily distracted.

**Birds-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)**
To refuse to gossip; to not pass something on. To distance oneself from others because they cause stress or are to noisy. Necessary retreat from a stressful situation. Stressful, chaotic, confusing experience of public offices. Chaos rules. Nervous or unstable authority. To distance oneself from one's worries. Loneliness makes restless.

**Birds-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Social situations stress us out. Noisy public (e.g. traffic but also noisy crowds). Very busy and hectic social life.
Worries about something becoming known. Nervousness before coming out. To make a very nervous impression on others. To present as very importantly busy. Chaotic community; unstructured or even messy teamworking. Inability to find one's place in society. To blab a secret to everybody. Gossip on social media. To be very involved and active in social networks. To network busily. To react quickly when our reputation is at stake.

**Birds-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Big worries. Paralysing, numbing stress. Stressing problems. Always present, never quiet circling thoughts. Conflict between noise and silence, nervousness and total, utter calm, between wanting (or having) to move and wanting (or having) to be still.
To be worried about a problem you're facing. To be impatient for something that's not going to happen any time soon. Standstill/having to wait makes you fidgety and restless. To distract yourself from difficulties. Difficulties that are distracting. Challengingly much is going on. To jump from one challenge to the next without ever quite mastering one.

**Birds-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Nervous indecision; to jump back and forward between alternatives. Nervousness about our freedom. Constant worries and unconstructive brooding about a choice. Unstructured, chaotic alternatives. The attempt to walk down too many (possibly conflicting) roads at the same time. Inability to stick with a choice. Excitement about a new possibility. Altogether too much chaotic thinking. Ambiguity stresses us.
The ability to switch perspectives easily.

**Birds-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Nagging doubts. Someone talks behind someone's back. Mean gossip. To think that one is constantly being put at a disadvantage, or that there is always great danger of something being taken away. Paranoia; to constantly suspect that something bad is going on. Worries about scarcity of some kind. Scarcities which lead to worry. To react quickly when something isn't right, or goes bad. To be on alert about bad stuff going on. Unrest is draining. Very quick dwindling. To lose one's agility.

**Birds-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Butterflies in the stomach. Unstable
affection (on/off; or one's affection keeps jumping from one person to the next). To worry about love, or a lover. An unstable, unsettled, or distracted lover (or to be that way oneself, as a lover). Romantic text messages. Someone's romantic attentions are bothering us. Someone expresses their love in annoying ways. Distraction from love. To care for many things at the same time - which is stressful. The attempt to give love and comfort to someone who is very nervous and unstable. Gossip about a romance; to overshare one's feelings of love. The idea of following one's heart's desires makes us nervous.

**Birds-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Fickle commitment; nervousness about commitment. Worries about a relationship. An unstable connection. Unstable group cohesion. Loose coherence. To make connections quickly. To promise things too quickly. Shared worries; to have something stressful in common. Chaotic connection(s) - seeming incoherence? To find the coherence in the chaos. The cause of chaos/stress.

**Birds-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
To be worried about the truth. Disorganised way of studying;
chaotic learning environment. To jump from one fact to the other. Inattention to the facts. To clutter one's head with too much (unnecessary) knowledge. Or: to be a quick study; to learn easily. Short term memory.

**Birds-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Hectic, stressed conversation; to have little time or no patience for proper, in-depth communication. Chit-chat, gossip. To communicate with quick ease; to respond quickly to emails/letters/conversations. To respond quickly when someone expresses something important. Worries about a conversation. To express one's worries. To have several conversations at the same time; to try and express multiple issues at the same time.

**Birds-Man (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Man who is: excited, exhilarated, agitated, (over)stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Man who is talkative, gossipy. Man who is brooding, worried, anxious. Man with obsessive-compulsive disorder. Man who is fidgety, restless, fickle, chaotic, unorganised, distracted. Man who distracts, annoys. Man who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile man.
Man with ADHD, multitasker, blabbermouth. Man difficult to assess or who it would be unwise to rely on because he is so fickle. To bother a man; gossip or worries about a man; to distract or talk over (and not listen to) a man.

**Birds-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Woman who is: excited, agitated, exhilarated, (over) stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Woman who is talkative, gossipy. Woman who is brooding, worried, anxious. Woman with obsessive-compulsive disorder. Woman who is fidgety, restless, fickle, chaotic, unorganised, distracted. Woman who distracts, annoys. Woman who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile woman.
Woman with ADHD, multitasker, blabbermouth. Woman difficult to assess or who it would be unwise to rely on because she is so fickle. To bother a woman; gossip or worries about a woman; to distract or talk over (and not listen to) a woman.

**Birds-Man (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Man who is: excited, exhilarated, agitated, (over)stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Man who is talkative, gossipy. Man who is brooding, worried, anxious. Man with obsessive-compulsive disorder. Man who is fidgety, restless, fickle, chaotic, unorganised, distracted. Man who distracts, annoys. Man who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile man.
Man with ADHD, multitasker, blabbermouth. Man difficult to assess or who it would be unwise to rely on because he is so fickle. To bother a man; gossip or worries about a man; to distract or talk over (and not listen to) a man.

**Birds-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Woman who is: excited, agitated, exhilarated, (over) stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Woman who is talkative, gossipy. Woman who is brooding, worried, anxious. Woman with obsessive-compulsive disorder. Woman who is fidgety, restless, fickle, chaotic, unorganised, distracted. Woman who distracts, annoys. Woman who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile woman.
Woman with ADHD, multitasker, blabbermouth. Woman difficult to assess or who it would be unwise to rely on because she is so fickle. To bother a woman; gossip or worries about a woman; to distract or talk over (and not listen to) a woman.

**Birds-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
(Possibly unstructured, absent-minded or nervous) communication about sexual issues. To communicate (a lot!) or gossip about sexual issues. To not truly enjoy something because one doesn't really pay attention - the mind is already on the next thing. To be stressed out by too much sensual input. Worries about sexual issues. Worries or a chaotic situation threaten harmony and peace. To be constantly distracted by thoughts of sex or by sensual input. To do lots of different artistic things (maybe none of them in depth). To be impatient because something is taking too long for one's taste.

**Birds-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
(Possibly unstructured, absent-minded or nervous) communication about moral issues. To communicate (a lot!) or gossip about moral issues (e.g. about someone's moral lapses). To worry about the morality of something. To be nervous/undecided about a moral issue. A stressful morally relevant situation. Fickle virtuousness. Because of all the many good but unfocused intentions one has there is the inability to act on even *one of them* effectively. Something which diverts from virtue. Conflict between the virtue of discretion and wanting to blab. The virtues of orderliness and self-discipline help in chaotic situations.

**Birds-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Very superficial chit-chat. Joyful, quick movements or dance; jokes and laughter. Circling thoughts and worries destroy happiness. Happy flutter. Erratic/fluctuating/unstable happiness. To be happy with chaos. Unstructured entertainment; to enjoy lots of different things. Glaring disorder. The mess doesn't go down very deep. Awareness of where there is disorder.

**Birds-Moon
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Emotions all over the place; unstable emotions. Emotionally upset. Rest/respite from stress or chaos. Worries, or restlessness, disturb our sleep. Noisy, busy, or restless, night. Emotional reaction; intuitive reaction. Worries which are not conscious. Inability to let an emotion go. Profound anxiety; anxiety disorder.

**Birds-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
To say something openly which used to be (and maybe should still be?) secret. To open up for communication. To say yes to too much so there's too much stress, too many demands on our time and energy. Inability to say no to anything. To be so open-minded that we accept conflicting ideas (inconsistency, or chaos, is the result). Relief from a stressful situation. To understand that which seemed chaotic. Excitement about gaining access. Exciting inspiration. If we open up, things will start to move very quickly.

**Birds-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Too much noise, too many thoughts, too many worries, too busy. To hecticly accumulate anything and everything, no matter whether one really needs it or not. To be worried or undecided about financial matters. To constantly change one's mind about what is important, or what is worth most. To profit from chaos, from a lack of structure. Finances (or material concerns in general) bother us. The bits and pieces of value hidden within idle chit-chat or within a messy situation.

**Birds-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Circling thoughts, worries which persist. To have ants in one's pants. A hold-up causes impatience, restlessness. Stress/chaos makes it difficult to focus. Inability to settle for one idea, or: to finally stop fidgeting and settle down. Chaotic status quo. That which gives foothold in chaos and stress.

**Birds-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Worries about our fate, or our responsibilities . To be rash in taking on responsibilities. Gossip, noise, or instability are very hard for us to bear and exhaust us in the long run. To struggle with a chaotic situation. To not tolerate noise, chaos, or gossip. To be totally convinced of what is only gossip. To shoulder many different tasks.

**Birds - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)**
Open questions cause nervousness or worries. To be exited about something indeterminate. We know we should react quickly - but don't know how. Something important is hidden within the chaos. Someone's fickleness makes them very unpredictable, indefinite, undefinable. A situation which is chaotic makes it seem volatile - everything and nothing at once seems possible. Obsessive and unproductive brooding over open questions to which there just is no answer yet. A (possibly genderqueer) person with the attributes of the Birds (see the Bird's keywords).
