---
title: "lenormand | birds | keywords"
source: https://www.annak-tarot.at/lenormand/12_birds_e.html
---

**BIRDS 12**

**Keywords**

***Nouns / phrases:***

Excitement, liveliness, (over)stimulation, busyness, multi-tasking.
Fuss, nervousness, stress. Chatter, gossip, blabbing of secrets. Short, superficial
conversations, e.g. text messages. Brooding, worries, anxiety. (Small) groups,
meetings. Comings and goings, fickleness, unrest. Chaos, lack of focus, distraction.
Noise, disturbance, nuisance. Reflex actions, quick reactions, presence of mind,
quick-wittedness, repartee. Mobility and agility (also figuratively). Traditionally
also: verbal communication, old(er) couple, siblings (twins), a pair of something.

 ***Activities:***

To excite, animate, (over)stimulate, agitate. To keep busy; multitask. To fuss, alert, startle.
To chat, gossip, blab a secret, ramble. To brood, worry. To dither, fidget, change direction (or
opinion) constantly. To get distracted. To make a noise, clutter, create a mess. To bother, distract.
To react quickly (instinctively).

 ***Attributes:***

Excited, exhilarated, animated, agitated, (over)stimulated. Busy, preoccupied. Fussy,
nervous, stressed. On alert, skittish. Talkative, gossipy. Brooding, worried, anxious. Obsessive, compulsive.
Fidgety, restless, fickle, unreliable. Chaotic, unorganised, unstructured, distracted. Noisy,
cluttered, all over the place. Distracting, annoying, bothersome. Reacting, reactive, quick to react,
knee-jerk. Quick-witted; mobile and agile (also figuratively).
 **As a person:**  Person with the above attributes, e.g. excited, busy, stressed, unfocused, quick. Someone
with ADHD, multitasker, blabbermouth. Someone unreliable because they are so fickle. **As advice:**
 Be watchful! Be quick! Negatively: Take it easy; calm down; focus!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Soon or quickly - but it won't persist. Making it happen now would mean rushing
it. Everything happens at once.

 **See also** the *annakblogs* article [>> So, are the Birds a positive or negative card?](https://annakblogs.wordpress.com/2018/01/11/light-shadow-birds/)
