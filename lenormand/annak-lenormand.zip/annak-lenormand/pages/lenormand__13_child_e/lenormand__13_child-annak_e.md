---
title: "lenormand | child | interpretation"
source: https://www.annak-tarot.at/lenormand/13_child-annak_e.html
---

child
 **INTERPRETATION**

*Child, small size, playfulness, inexperience, beginning*

**About the meaning:**
The Child is a card which is very often interpreted as a representative of a person. The first paragraph is concerned solely with that dimension of meaning. The other paragraphs describe attributes or abstract concepts which can be derived from qualities small children have in common.

*Child / young person:* The first meaning of the card Child is literal. The card can represent a baby, toddler, or child, a grandchild, or even someone's grown up daughter or son. The Child *might* also represent a person who is considerably younger than the querent. And sometimes, the Child doesn't indicate a person who is physically young, but a person whose *behaviour* is childlike, or even childish - a person whose mind seems much younger than their actual years. Additionally, in quite a few cases I have also interpreted the card as the querent's inner child.

*Small size / delicateness / harmlessness:* Because one of the most obvious characteristics of our offspring is that they are of smaller size than us, the Child can mean that something is small/little - either physically, or concerning amount or relevance. Furthermore, the card can say that something is delicate, or weak, or easily damaged. It can mean vulnerability, sensitivity, and defencelessness - and, consequently, harmlessness. Sometimes the Child also indicates belittlement, or that something is being minimized. And related to all the aforegoing, in a way, is cuteness - because we are genetically programmed to perceive a scheme of childlike characteristics "cute".

*Youth / freshness / novelty:* Another characteristic of children is that they are young, that they haven't yet existed for a long time. So not just youth, but also anything which is fresh or new, is another dimension of this card's meanings. In that sense, the card can also represent something which is a novelty to us, or innovations.

*Curiosity / wonder / play:* I mentioned "childlike" mentality/behaviour in the first paragraph. Among these are curiosity, and wonder - a general openness towards everything which is encountered, inquisitiveness, and fondness of experimenting. And the Child can also be interpreted as anything to do with play. It can for example represent actual games, or a playful attitude, as well as - especially in combination with the Clover - the inability to be serious.

*Inexperience / guilelessness / naivety:* The younger a child is, the more inexperienced it is. The Child stands for that, for inexperience, and also for the need of friendly guidance and support. In some cases the card indicates that we aren't yet equipped to take things on by ourselves. Furthermore, because of their lack of experience with the world, most children are also quite guileless. They are innocent, pure in the sense that they (hopefully) don't have any reasons yet to assume anything bad from the world. Thus, naivety is another highly appropriate interpretation of this card, as well as gullibility, and suggestibility.

*Immaturity / development / beginnings:* Childhood is the first phase of our life. It is the time in which our bodies and minds are developing. Hence, the Child represents not just immaturity, but also the earliest stage of any processes or project. The card can say that something is developing already but that it will keep doing so for quite a long while yet. It can mean that we have just started out, that something is (only) beginning. In an even more "condensed" sense, the Child represents beginnings themselves. And sometimes, it can be taken as a suggestion that we should initiate something, that we should take the first step.

 **See also** the *annakblogs* article [>> So, is the Child a positive or negative card?](https://annakblogs.wordpress.com/2018/01/16/light-shadow-child/)

**About the Image:**
 My initial draft of the child and their nursery was far less frilly and bowy. I personally detest frills and bows; I would never put them on myself nor on an actual child; I don't do cutesy. But the illustration didn't feel right; I was emotionally indifferent towards the card until they were there. For a rather large part of the Child's meaning revolves around weakness, and harmlessness, and cuteness. Neither of these seemed prominent enough until the frills were present. I added cuteness and harmlessness by adding actual frills, just as I would belittle or minimize something by putting metaphorical frills on it.
Something else which I think is important to mention is that my child (still a toddler, really) is standing at the edge of their crib in their nursery, pointing towards an open window. This pointing outside aspect was very, very important to me. When I pictured a child who was just busy playing with their toys, I couldn't see "the beginning of a development" or "initiation" in the card. I could only see a snap-shot, an isolated moment, not the first step of a long process. So my Child is taking the first step towards the as yet unfamiliar outside world. They are obviously curious, eager to explore. But they are also facing backwards, as if asking the spectator for guidance, help, or asking if what they are doing is allowed. You on the other hand, as the adult spectator, will maybe feel an impulse to rush in and stop the child's exploration. For in order to reach the window, the child is just about to step on the edge of their crib. Especially with the empty dark space in front of it, there is a suggestion of danger here. The child, in their inexperience and guilelessness, not paying heed to potential accidents, might fall and get hurt!
And lastly, for the dimension of playfulness in the card's meaning, I added a mobile, a rocking horse, and the toy bunny the child is holding firmly in their grip.
