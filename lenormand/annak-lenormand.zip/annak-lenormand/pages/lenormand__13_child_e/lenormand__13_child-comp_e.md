---
title: "lenormand | child | comparisons"
source: https://www.annak-tarot.at/lenormand/13_child-comp_e.html
---

child

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Child, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Beginnings and endings**

|  |  |
| --- | --- |
|  | **Child**: A birth. Something begins, something is new, young. The first step(s). |
|  | **Scythe**: To put an end to something. Interruption; cut. The final step; the final stage in which we reap what we've sowed. |
|  | **Coffin**: Something is over for good. Natural end; death. |

 **Sexuality**

|  |  |
| --- | --- |
|  | **Child**: "I haven't had (much) sex (yet)." Sexual immaturity, inexperience, innocence. |
|  | **Lily**: "I don't have sex!" Sexual abstinence. Possibly: frigidity, prudery. |
|  | **Lily**: "I enjoy sex!" Sexual passion, maturity, experience. A purely sexual relationship. |
|  | **Snake**: "I want sex!" Strong sex drive. To use sex as a means to an end. Seduction. |

**(Need for) guidance**

|  |  |
| --- | --- |
|  | **Child**: Lack of experience - leadership in the form of gentle guidance and support is needed to gain experience safely. Bear might be too loud or over-protective; Tower too strict and cold - a good dose of Dog would help while Dog only might be too weak. |
|  | **Clouds**: Disorientation - guidance would be needed to get out of confusion and prevent despair. Both Bear and Tower could help a lot here but in the end mightn't help with becoming self-reliant and might thus keep the querent in dependence on their leadership. |
|  | **Bear**: Provides strong, charismatic, warm-blooded, and personally involved leadership/guidance. |
|  | **Tower**: Provides cool, impersonal, impartial guidance/leadership. |
|  | **Dog**: A person who can only (emotionally) support and help but isn't able to guide or lead. |
