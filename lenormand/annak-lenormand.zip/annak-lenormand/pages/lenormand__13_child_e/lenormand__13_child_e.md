---
title: "lenormand | child | keywords"
source: https://www.annak-tarot.at/lenormand/13_child_e.html
---

**CHILD 13**

**Keywords**

***Nouns / phrases:***

Baby, toddler, child, generally "young(er) person". Someone's
(grand)child. Son, daughter. Inner child. Small size, delicateness. Cuteness. Fragility,
weakness, sensitivity, vulnerability, harmlessness. Belittlement, minimization.
Youth; freshness, novelty, innovation. Games, play, playfulness, inability to
be serious. Inexperience; the need for guidance and support. Innocence, guilelessness,
naivety. Gullibility, suggestibility. Immaturity. Beginning, start, initiation.
First step(s).

 ***Activities:***

To weaken. To rejuvenate. To minimize, belittle, make little of something. To start
developing. To play, play around. To need guidance. To begin, initiate. To take the first step.
 ***Attributes:***

Childlike, infantile, little, small, delicate. Cute. Fragile, weak, breakable, sensitive, vulnerable,
defenceless, harmless, non-threatening. Young, youthful, new, fresh. Innovative, novel.
Curious, inquisitive, playful. Inexperienced, in need of guidance. Guileless, innocent, naive, suggestible,
gullible. Immature. Beginning, initial.
 **As a person:**  Young(er) person, see above (e.g. baby, child, daughter or son). Inexperienced, naive
person or someone curious, playful. Someone delicate, harmless, or cute. Someone the querent
belittles. **As advice:**
 Take the first step! Approach it playfully; be curious! Negatively: Don't belittle it!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Childhood. In the beginning, initially, early. Short time spans. Spring/morning.

 **See also** the *annakblogs* article [>> So, is the Child a positive or negative card?](https://annakblogs.wordpress.com/2018/01/16/light-shadow-child/)
