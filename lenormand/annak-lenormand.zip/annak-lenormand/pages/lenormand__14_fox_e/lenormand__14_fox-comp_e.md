---
title: "lenormand | fox | comparisons"
source: https://www.annak-tarot.at/lenormand/14_fox-comp_e.html
---

fox

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Fox, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Egotism**

|  |  |
| --- | --- |
|  | **Fox**: Egocentric in regard to our needs - our own needs come first. |
|  | **Snake**: Selfishness in regard to goal-achievement - in order to get what we want we're willing to sell our own grandmother. |

 **Intelligence**

|  |  |
| --- | --- |
|  | **Fox**: Street-wise, cunning; the intelligence of knowing when to risk something and when not to. |
|  | **Snake**: Diplomatic intelligence, great rhetoric, acumen, social intelligence. |
|  | **Book**: Well-educated, book-learned, intellectual. |

**Protection / defence**

|  |  |
| --- | --- |
|  | **Fox**: Self defence. Self-care. To look after oneself first. |
|  | **Bear**: Protector; protection of others, protective behaviour. To make provisions for the future. |
|  | **Tower**: Protection and/or self-defence by putting up (and asserting) boundaries. |
