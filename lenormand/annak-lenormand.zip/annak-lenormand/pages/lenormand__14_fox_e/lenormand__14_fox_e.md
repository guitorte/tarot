---
title: "lenormand | fox | keywords"
source: https://www.annak-tarot.at/lenormand/14_fox_e.html
---

**FOX 14**

**Keywords**

***Nouns / phrases:***

Self-interest; (strong) sense of self; identity. Self-care. Egocentric
standpoint; selfishness; egotism. Independence (especially from the opinion
and judgement of others); integrity. Self-defence. Hard work; survival; necessity.
Adaptation; adaptability. Intelligence, cunning, caution, distrust. Traditionally:
trickster, manipulator, dishonesty, hard work.

 ***Activities:***

To look after oneself well/first. To be true to oneself; to have one's
own standards. To defend (oneself); to do what needs to be done to survive. To
adapt; to learn new ways (out of necessity). To distrust, suspect. Traditionally: to trick and manipulate,
but also to work hard.

 ***Attributes:***

Defensive, self-involved, self-centred, egotistic, selfish. Intelligent, cunning, streetwise;
tricky. Cautious, suspicious, suspect. True to oneself, discrete, independent. Hard-working;
adaptable. Necessary. **As a person:**  Person with the above attributes. An intelligent, streetwise person; defensive (maybe
jealous) person. Someone who looks after themselves well - or only after themselves. A
selfish person. Someone who does things their own way (even if others don't like it). Traditionally:
a trickster, someone dishonest. **As advice:**
 Cautious now; don't trust them/it! Take care of yourself first! Stay true to yourself!
Negatively: Don't deceive others for your own gain!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Not the right time yet; first there needs to be thorough risk-assessment. When it's
necessary. Times when there is less light, so it's easier to hide: night, dusk and dawn.

 **See also** the *annakblogs* article [>> So, is the Fox a positive or negative card?](https://annakblogs.wordpress.com/2018/01/23/light-shadow-fox/)
