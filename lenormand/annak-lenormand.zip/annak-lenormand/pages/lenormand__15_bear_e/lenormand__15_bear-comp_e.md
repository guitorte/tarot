---
title: "lenormand | bear | comparisons"
source: https://www.annak-tarot.at/lenormand/15_bear-comp_e.html
---

bear

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Bear, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Authority / leadership**

|  |  |
| --- | --- |
|  | **Bear**:  A strong, charismatic, warm-blooded, and personally involved leading figure or type of guidance. Natural authority. |
|  | **Tower**: A cold, impersonal, impartial leading figure or type of guidance. "Artificial" authority that comes from the position one has, no matter whether one's personality type is suited to the job or not. |
|  | **Dog**: A person who can (emotionally) support and help but isn't able to guide or lead. |
|  | **Child**: Leadership in the form of gentle guidance and support is needed to gain experience safely. Bear might be too loud or over-protective; Tower too strict and cold - a good dose of Dog would help while Dog only might be too weak. |
|  | **Clouds**: Lack of leadership and guidance - guidance would be needed to get out of confusion or despair. Both Bear and Tower could help a lot here but in the end mightn't help with becoming self-reliant and might thus keep the querent in dependence on their leadership. |

 **Power**

|  |  |
| --- | --- |
|  | **Bear**: Power in the sense of dominance, or natural authority. A powerful personality. |
|  | **Tower**: Power through position - whether one is personally suited to it or not. Control. |
|  | **Snake**: Hunger for power. Direction or manipulation. |

**Protection / defence**

|  |  |
| --- | --- |
|  | **Bear**: Protector; protection of others, protective behaviour. To make provisions for the future. |
|  | **Fox**: Self defence. Self-care. To look after oneself first. |
|  | **Tower**: Protection and/or self-defence by putting up (and asserting) boundaries. |

 **Strength**

|  |  |
| --- | --- |
|  | **Bear**: Dominant character; willing to lead, bossy. |
|  | **Tree**: Strong body; healthy, thriving. |
|  | **Snake**: Self-will; headstrong, empowered. |

 **Wealth**

|  |  |
| --- | --- |
|  | **Bear**: Ownership, property. To accumulate wealth as provision for harder times. To look well after things we already have. |
|  | **Fish**: Money, finances. Accumulation, or profit, for their own sake. To work on getting more money/goods. |

 **Knowledge**

|  |  |
| --- | --- |
|  | **Bear**: Practical knowledge - capable. "I know how to do this!" |
|  | **Book**: Factual knowledge; educated. "I know this!" |
|  | **Snake**: Thirsty for knowledge. "I want to know!" |
