---
title: "lenormand | bear | keywords"
source: https://www.annak-tarot.at/lenormand/15_bear_e.html
---

**BEAR 15**

**Keywords**

***Nouns / phrases:***

Parent, parental figure, leader, teacher, supervisor, coach, boss.
Leadership, guidance. Power, dominance, influence. Physical strength, strength
of character. Warm-bloodedness, choleric or dominant personality, short temper.
Assertiveness, bullying. Competence, capabilities, life experience, practical
knowledge. Protection, provision, possessiveness, jealousy. Personal property,
ownership. Traditionally also: personal finances, e.g. cash flow.

 ***Activities:***

To guide, lead, teach, coach, supervise, boss around. To influence,
dominate, overpower, bully. To assert something or oneself; to stand one's ground; to take charge.
To know how to be competent at something. To (over)protect, provide. To take possession,
to own.

 ***Attributes:***

Parental, guiding, leading, bossy. Powerful, dominant, influential. Strong, (over)assertive,
overbearing, choleric, short-tempered. Competent, capable, experienced. (Over)protective,
provident. Possessive, aggressively jealous. Well-off.
 **As a person:**  Person with the above qualities. Parent(al figure), teacher, boss, coach, supervisor,
leader. The alpha. Bully. **As advice:**
 Be a good parent / teacher / boss! Assert yourself; take charge! Protect and provide!
Negatively: Calm down - don't boss others around!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Someone, or something, other than the querent has a major influence on when it
will happen / can control when, or if, it will happen.

 **See also** the *annakblogs* article [>> So, is the Bear a positive or negative card?](https://annakblogs.wordpress.com/2018/01/30/light-shadow-bear/)
