---
title: "lenormand | stars | comparisons"
source: https://www.annak-tarot.at/lenormand/16_stars-comp_e.html
---

stars

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Stars, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Credulity**

|  |  |
| --- | --- |
|  | **Stars**:  Sceptic thinking skills are not applied to spiritual claims; belief in something simply because "it feels right". Belief in pseudo-scientific woo. |
|  | **Child**: Sceptic thinking skills are not fully developed yet. Credulity because of a lack of experience. |

 **Spirituality / religion**

|  |  |
| --- | --- |
|  | **Stars**: Transcendence, mysticism. To feel one with everything. Spiritual experiences. Meditation. |
|  | **Cross**: Organised religion; dogma. Religious rules, texts. Contemplation. |

**Approach to reality**

|  |  |
| --- | --- |
|  | **Stars**: Idealisation, spirituality; to seek deeper meaning in everything. |
|  | **Tree**: Realism, pragmatism; to constantly check in with what is really, physically there. |
|  | **Lily**: Sensualism; to seek sensual experiences, especially pleasurable ones. |
|  | **Book**: Intellectualism; to seek theoretical/scientific understanding of reality. |
