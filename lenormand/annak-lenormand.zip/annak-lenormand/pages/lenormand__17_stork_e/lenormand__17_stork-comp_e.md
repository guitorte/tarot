---
title: "lenormand | stork | comparisons"
source: https://www.annak-tarot.at/lenormand/17_stork-comp_e.html
---

stork

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Stork, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Change**

|  |  |
| --- | --- |
|  | **Stork**: Change in the form of a transformation. Inner change; e.g. change of heart. Changes dictated by the inner nature of things. Changes which happen gradually. |
|  | **Rider**: Change is brought to us; changes that happen without our doing. Sudden or enforced changes. |
|  | **Ship**: Changes we set in motion. A change of environment. Changes which take some work. |
|  | **Birds**: Constant change; nothing ever sticks - fickleness. Erratic changes. |
|  | **Anchor**: The opposite of change: stability or stagnation. Everything stays the way it is because we are able to maintain, are holding on to, or are restrained from changing, the status quo. |
|  | **House**: The opposite of change: regularity. Everything stays the way it is because we always act according to tradition or our personal habits, and/or don't allow innovation. |
|  | **Mountain**: The opposite of change: permanence. Everything stays the way it is because we won't budge. |

 **Longing**

|  |  |
| --- | --- |
|  | **Stork**: Deep longings in general, but especially the longings which arise from our inner nature. |
|  | **Ship**: Longing in the sense of wanderlust - the longing to be elsewhere, to discover new places. |
|  | **Lily**: The longing for sexual union (or, more generally, for sensual experiences). |
|  | **Snake**: Longing in the sense of cravings - to want to get or to achieve something |
|  | **Heart**: Romantic longing. |

**Acceptance**

|  |  |
| --- | --- |
|  | **Stork**: Acceptance in the sense that we stop fighting what is happening. The recognition that what is happening is inevitable, and so we go with the flow instead of trying to go against it. |
|  | **Key**: Acceptance in the sense that we actively want and allow something to happen. Acceptance in the sense of a welcome. |
