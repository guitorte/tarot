---
title: "lenormand | dog | comparisons"
source: https://www.annak-tarot.at/lenormand/18_dog-comp_e.html
---

dog

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Dog, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Follower / Leader**

|  |  |
| --- | --- |
|  | **Dog**: The born follower. The helper, the supporter. To obey and appease. |
|  | **Bear**: Charismatic, choleric leader; bossy person. To teach, command, and confront. |
|  | **Tower**: Cool, distant leader or authority. To control, to spearhead. |

 **(In)dependence**

|  |  |
| --- | --- |
|  | **Dog**: Dependence - in general, but especially the dependence on the approval and love of others. |
|  | **Anchor**: Dependence in the sense of being stuck with something or someone, of being tied to someone or something by practical necessities. |
|  | **Ring**: Dependence in the sense that we're bound by a promise, or because we can't that easily "undo the ties that bind us". |
|  | **Fox**: Independence from others' judgements (moral, aesthetic, political etc.) - to stick with what we have found to be true no matter what it costs. |
|  | **Tower**: The type of independence arising from a lack of close emotional relationships, or from working or living alone. |
|  | **Snake**: Independence in the sense that we are headstrong and go our own way, even when we have to go alone, and especially when others try to hinder us. |

**Friendship**

|  |  |
| --- | --- |
|  | **Dog**: Represents a friend, loyalty, or supportive and helpful behaviour. |
|  | **Bouquet**: Represents our circle of friends, conviviality, the cultivation of friendships. |
