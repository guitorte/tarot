---
title: "lenormand | dog | combinations"
source: https://www.annak-tarot.at/lenormand/18_dog-komb_e.html
---

**COMBINATIONS WITH THE
DOG**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Dog-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Intrusive or nosy friend. To urge or pressure a friend to do something. News about a friend; message from a friend. Friendly message. To follow whatever/whoever appears latest in one's life. Friend or employee is being harassed. To put pressure on someone in order to help them. To push for support. To permit someone to browbeat or push you around. Permission for an action. To step in and help.

**Dog-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Happy-go-lucky friend; unburdened friend, irresponsible friend or employee who needs a leader. To take a friend(ship) for granted. Opportunity to make a friend. To become friends because it just happens to be convenient. Superficial friendship. Don't reinforce someone's strong loyalty - it's not healthy. Someone seems really devoted and loyal but really it doesn't go very deep. Irresponsibility towards a friend or employee. To not take it too badly that at the moment one is the underdog - it might soon pass.

**Dog-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Travel companion. Someone who follows you wherever you go (literally and figuratively). Help on a journey or support concerning making a change. Ask for permission before you leave / change things! Adventure with a friend. To explore a friendship. To shift one's loyalties elsewhere. To stay loyal to someone who has left; to stay loyal to someone although they won't commit. Long-distance friendship; to feel distant from a friend. Friend who is absent. To leave a friend - to look for a friend. To change something just because we were told to.

**Dog-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Family friend, loyalty to family/home country, support from or for the family. To crave approval from family members. The underdog in the family; compliant family member. To let tradition and rules guide us - possibly but not necessarily uncritically accepting traditional role models. Helpful plan. To obey the rules. A very intimate friend. To be used to getting help. To ask for help. Private matter between us and a friend.

**Dog-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Stable, healthy, strong friendship. To follow the lead of someone who is calm and stable and down-to-earth. Very strong, deeply rooted devotedness to something or someone. Healthy loyalty; loyalty which is unwavering; loyalty which is impossible to shift. That which supports our health. Physical means of support. To lead someone physically (e.g. by taking them by their hand). Naturally helpful; someone is tractable by nature.

**Dog-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
To not know where our loyalty should be. Confusion or secrets concerning a friend or employee. To be unsure whether someone is a friend or not, or whether their friendliness is sincere. Friend who has something to hide. We feel lost and scared because no one tells us what to do. Misunderstanding with a friend. A friendship has become boring.

**Dog-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Strong desire to always be there for someone specific or for other people in general. To follow someone very determinedly; to always submit to someone else's wishes. Conflict between wanting to follow your own agenda and wanting to be told what to do. Wanting to be friends with someone very badly. A Guru or leader (Snake) and their follower (Dog). Manipulative friend; a friend with their own agenda. Wise counsel.

**Dog-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Loss of a friend or follower. End of friendship. Loss of loyalty, loss of support. This is where loyalty ends! To give up a follower-mentality. To bury one's friendly feelings. It's time to stop trying to help. Permission to end something. Support in times of grief. Someone who helps us end something. To worship death.

**Dog-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Show your appreciation to your friend(s) or employee(s) more! Visit a friend or invite them. Someone really needs to know you love them / are proud of them. Someone dependent on approval. Unconditional admiration. Admiration from a friend. Someone totally adores you (possibly not in an entirely healthy way). To make oneself look pretty to please others.

**Dog-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
To discontinue (or disallow) overly devote behaviour. To stop following someone or something. To cut off a friend, or to be cut off by a friend. Dogged efficiency. To stay "loyal" to breaking a (bad) habit. Deserved loyalty. to reap friendship. Help with cutting something or someone off. Abrupt, harsh treatment of someone who is just trying to be friendly. The wish to stay friends after a break-up.

**Dog-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
To blame a friend / be accused by a friend. Argument with a friend. A cynic or abusive or abrasive friend. Trust is damaged by abrasive or abusive words or behaviour. To not stand up to abuse/aggression. To let ourselves be treated like shit (or to treat someone who depends on us like shit...) Someone tractable is bullied. To stand by an abuser out of a sense of loyalty. A helpful discussion. Support during a conflict. Justice for a friend. To meekly confess one's guilt. To knuckle down.

**Dog-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)**
Excited, nervous or stressed friend or employee. Gossip about a friend or a friend gossips about you. Loyalties constantly change. To keep forgetting about a friend; forgetful friend. Worries about a friendship or about someone's loyalty. To be very easily distracted.

**Dog-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Childhood friend, young friend, inexperienced employee. Someone is really in need of guidance here! Beginning of a friendship. A very, very suggestible young or inexperienced person who is easily taken advantage of, easily led, because they are so eager to please. To take the first step towards a friend. A delicate or weak friendship; little loyalty, or loyalty which is easily destroyed. Suggestibility leads to dependency. Definitely ask for permission! A child asks permission, or to ask permission of a child. A young or inexperienced person needs us! To support a weaker person.

**Dog-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
A selfish friend; friend how has their own (hidden) agenda. To distrust someone's loyalty. Self-support. To make friends for selfish reasons. To be cautious about accepting offers of friendship. Distrust makes it difficult to make friends. A vital friendship. Necessary loyalty. Conflict between what oneself thinks is right and demands/expectations/inclination to follow what others say is right. Someone who wants to do everything themselves, vs. someone who wants someone to tell them what to do.

**Dog-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Someone's overly dominant behaviour has turned someone else into a passive follower(and maybe that's not good for either). To make someone obey. Someone submissive and someone dominant. Someone leads, someone follows. Boss vs. employee. Dominant, strong, or protective, friend. To protect a friend. Support for a leader/parent. To be too pliable to a parent's influence. Strong loyalty; powerful friendship. To ask for permission or advice of parent/teacher/boss. Devoted but maybe weak parent(al) figure. To exploit someone.

**Dog-Stars[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
The wish to be told what to do; the hope that we'll be appreciated. The hope to find a friend or support. (Maybe gullible) spiritual disciple. Support concerning one's aspirations. To trust someone's loyalty. To believe in friendship. Deep connection with a friend. To ask for permission reaching for the stars. To find meaning in helping others.

**Dog-Stork[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
A friendship transforms. Transition of a physical relationship into a friendship, or a transition from just knowing someone into a friendship with them. Friend is transforming or transitioning. Becoming friends is a slow process which can't be rushed. Someone who gives support in a time of transition. The longing to be allowed to just follow, to not having to decide so much. A friend's return. To win someone's loyalty back. Someone is supportive by nature - which is easily exploited if they don't take care! To yearn for friendship, to long for unconditional support.

**Dog-Dog[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Very loyal friend. Support from a friend. A friend depends on you. Lots of support. An obedient follower. Someone with a true follower mentality - doesn't think for themselves.

**Dog-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Our hope for appreciation and approval is met with cool aloofness and little emotional warmth. To say no to a friend, follower, employee. To make sure that there's sufficient boundaries between us and an eager and overly dependent friend. An unequal friendship - one of the two thinks they are better (and the other agrees). Friendship in which one party always has to be the one who takes the lead, who keeps a clear head, while the other asks what they should do, and has a merely supportive role. To ask and get a "no" in return. Not allowed. Lonely, rational, or arrogant friend. Loyalty to the person on top. To support the person in authority.

**Dog-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Someone who follows the crowd, who always agrees with the mainstream, who is very dependent in their self-worth on how society thinks about them. Communal support; to help someone out together. To work together for the benefit of each other. Everybody supports everybody else - solidarity. To want to help everybody. Support group; supportive networks. To be (overly) loyal to one's own culture. To present as loyal/helpful/friendly.

**Dog-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Difficult or silent friend. Something is an obstacle to friendship. A friendship that has grown cold. Our follower-mentality or unwillingness to stand up for ourselves hinders our progress. Insurmountable need to please others. To wait for permission in vain. To ask for help with a problem or challenge. A friend in a difficult situation. To be utterly devoted to someone who doesn't show any sign that they return the feeling. A challenge to someone's loyalty. Someone very tractable vs. someone who won't budge an inch.

**Dog-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
"Oh crap: I am supposed to make up my own mind, but I don't want to!" Someone who follows wherever someone else goes. Someone agrees to whatever someone else says. To wait for permission / approval; to ask for other people's opinion before we decide something. Ambivalent loyalty. Support with making a choice. Someone who helps when we hesitate.

**Dog-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Lack of loyalty, lack of friendship. A false friend or corrupt employee. Friendship or loyalty is waning. To want approval from or to be devoted to someone (or something) who is NOT a good influence. Dwindling support. To feel exhausted because one is constantly trying to help others. To take away permission. Dwindling docility / obedience. To be envious of a friend. A begrudging friend. Someone fakes friendship. Betrayal of a friend or a friend betrays us.

**Dog-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
A loving friend; a very affectionate friendship; to receive emotional support from a friend or give it *to* a friend. Reconciliation with a friend; to forgive a friend, or a friend forgives us. To actually be too friendly. Or: to offer too much help and understanding - it's not actually helpful anymore. To be too soft
and thus in danger of being led. Total, utter devotion - inability to see any flaws anymore. To be dependent on the love from (or for) someone. To allow oneself be bossed around in order to get affection. To fall in love with a friend. Friend is in love with us. Someone in a caring profession; someone with helper's syndrome.

**Dog-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Strong friendship. Loyalty is what binds two people together. Wanting to please someone connects us to this person very strongly - do we really want this? Promise to a friend; promise from a friend. An unequal connection (e.g. one is more dependent than the other). Mutual support. Solidarity. Dependable friend; dependable help. Circle of friends. Fellowship, following. Mutual admiration; a mutual friend.

**Dog-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
An educated friend. Facts about a friend. To know everything about a friend or to let a friend know the truth about oneself. To admire education. To follow where the facts lead you.
To uncritically believe everything just because it's written down or presented as factual. Support of a learning process, of someone's education. Something or someone who helps with learning something. Private teaching. A mind which is easily lead. To follow someone's thinking process. To ask for the truth. Loyalty to the truth.

**Dog-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Conversation with a friend. To express friendship, loyalty, or devotion. Non-verbal expressions of dependence. To tell someone what to do / to ask someone what to do. Orders; or to give or receive permission. Unequal conversation. To communicate support; non-verbal expressions of support. To follow a conversation. To always agree with what other people say.

**Dog-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Man who is: a friend, an employee, a follower, helpmate. Man who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for himself. To befriend a man. To ask a man for permission. To do what a man (or men in general) say; to crave the approval of a man or men in general.

**Dog-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Woman who is: a friend, an employee, a follower, helpmate. Woman who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for herself. To befriend a woman. To ask a woman for permission. To do what a woman (or women in general) say; to crave the approval of a woman or women in general.

**Dog-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Man who is: a friend, an employee, a follower, helpmate. Man who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for himself. To befriend a man. To ask a man for permission. To do what a man (or men in general) say; to crave the approval of a man or men in general.

**Dog-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Woman who is: a friend, an employee, a follower, helpmate. Woman who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for herself. To befriend a woman. To ask a woman for permission. To do what a woman (or women in general) say; to crave the approval of a woman or women in general.

**Dog-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
To be sexually interested in a friend - or a friend is sexually attracted to you. Sexual relationship in which one participant is very submissive, or dependent. Artist and their admirer.
To follow/obey someone who is more experienced. Employee/follower who is being seduced. A loyal/supportive lover. To beg for sex. (Possibly crippling) anxiety to please in the bedroom. to ask what someone likes in sex. To be led almost completely by pleasure.

**Dog-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Virtues relevant to friendship, especially loyalty. A friend who is: loyal, impartial, virtuous, has good intentions, is stuck up, too disciplined. To be true to one's moral ideals. To stand by what one thinks is right. Utter devotion. To ask for moral guidance. To ask if it's okay to do something. Someone whose moral ideas are easily influenced.

**Dog-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Happiness in a friendship; an easy friendship.
To share joy with a friend; celebration with/of a friend. Superficial friendship. To admire an idol.
Someone who is loyal and supportive only as long as we're popular. Someone supports someone else's happiness. An extroverted/confident friend. Confidence in a friend. To not question appearances.

**Dog-Moon
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)**
Someone is extremely dependent in a needy sort of way. Sad or fearful or needy friend, follower, or employee. Emotional friend(ship). Emotional issues with a friend. Emotional support. Rest/a good night's sleep would help! A helper needs rest / a respite from helping. Loyalty to one's intuition - to always follow one's intuition. Tractable emotions. To abandon oneself to one's emotions. Profound worship.

**Dog-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Someone wants to be our friend. A friend wants to be closer to us - or the other way around. To welcome a friend, to include a friend. To relief a friend, to free a friend. To give ourselves permission. To allow someone to follow us, be devoted to us - which might be a good thing, or not. To be allowed; to get permission. To use someone's loyalty as a means for an end. Acceptance brings relief. Someone who helps us understand. Support in our efforts to free ourselves. Liberation from dependence.

**Dog-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Money or expensive gifts are viewed as a sign of appreciation or love. Lots of friends - but maybe the quality of these friendships is not that good. To admire people who are rich. Someone looks up to us because of our wealth. To value loyalty. An abundance of loyalty. "Too much" help - inappropriate, unnecessary help. Financial support. Financial dependence. To worship money.

**Dog-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
A friend who sticks with you no matter what. Stable friendship. Great loyalty. To stick with someone or something loyally. Someone who is the foothold for a dependent. Extreme dependence - inability to let go because of dependence. A clingy friend. To cling to a friend. Dependence on routines. To feel restricted by loyalty. To be bound to someone or by someone. Someone holds someone on a tight leash. Something hold all our attention. Devoted focus. To not question the status quo.

**Dog-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
To adhere to an ideology, or to bow to a political, religious or moral authority, without ever challenging it. To never question something we've been led to believe. The dependence on strong (ethical/political) guidelines. To perceive it at an inescapable duty to be loyal. Burdensome loyalty. Responsibility for a dependent. Helper's syndrome. To shoulder something for a friend. A friend shoulders something for us. Support in times of suffering. A dogmatic/religious/suffering friend.

**Dog - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)**
Question mark regarding someone's loyalties. To follow where the question marks lead. Please someone tell me what to do regarding this thing I don't see clearly! A friend who you don't yet know you already have, or, someone who you don't realise could be your friend. Support not yet received. Something or someone that can help with open questions. A (possibly genderqueer) person with the attributes of the Dog (see the Dog's keywords).
