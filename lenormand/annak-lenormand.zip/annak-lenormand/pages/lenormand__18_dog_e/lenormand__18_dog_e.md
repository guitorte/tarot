---
title: "lenormand | dog | keywords"
source: https://www.annak-tarot.at/lenormand/18_dog_e.html
---

**DOG 18**

**Keywords**

***Nouns / phrases:***

Friend, friendly person. Follower, helpmate, sidekick, employee.
Friendship, acts of kindness. (Unquestioning) loyalty. Help, support, helper's syndrome.
Devotion, worship. Full-hearted abandonment to someone or something.
Uncritical admiration; inability to form critical, independent opinions. Dependence,
submission, obedience, tractability, compliance. Anxiety to please; a need
for the approval of others.

 ***Activities:***

To act friendly, make friends. To follow, be a good follower, show
loyalty. To help, support. To devote oneself, worship, abandon oneself to someone or something.
To (uncritically) admire, have no independent opinion, to not question or challenge someone or
something. To depend on someone or something. To obey, comply, let others order us around or
think for us. To try to please, seek approval from others, listen to others, ask permission.
 ***Attributes:***

Friendly, chummy. Loyal, willing to help, supportive. Submissive, devoted, dependent.
Obedient, tractable. Anxious to please. **As a person:**  Someone with the above attributes. Friend, follower, helpmate, sidekick, employee.
Traditionally also: a health professional. **As advice:**
 Ask for permission! Listen to others! Give support! Negatively: don't be so
submissive! Think for yourself!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When we have permission. When others make it happen.

 **See also** the *annakblogs* article [>> So, is the Dog a positive or negative card?](https://annakblogs.wordpress.com/2018/02/20/dog/)
