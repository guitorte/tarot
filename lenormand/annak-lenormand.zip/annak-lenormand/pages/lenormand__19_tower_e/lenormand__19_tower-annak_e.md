---
title: "lenormand | tower | interpretation"
source: https://www.annak-tarot.at/lenormand/19_tower-annak_e.html
---

tower
 **INTERPRETATION**

*Boundaries, retreat, rationality, pride, authority*

**About the meaning:**
Towers used to be important architectural means of home defence, as well as markers of territory for the ruling authorities. All following interpretations are deduced from these functions.

*Walls of defence / boundaries / "No!":* Towers are usually massively built; forbidding; protecting those inside from attackers. Even visually, they very clearly say "Don't come too close" or "No entry"". So the Tower is a wonderful representative of boundaries. The card can stand for walls of defence. Especially in our hectic life today it can be very important to be able to say "no" to the demands of others. But if we constantly barricade ourselves behind a rigid, metaphorical stone wall, even when no one is attacking us, we can become very aloof.

*Retreat / solitude / isolation:* Continuing from the last paragraph, the Tower may stand for times in which we withdraw from others; emotionally, or even physically, avoiding all company. In that sense, the Tower represents retreat, and solitude. This can be a very positive thing - solitude can give us space to calm down, to rest, to recover. But it could also be a negative thing, especially if the solitude is not voluntary. Peaceful solitude then turns into oppressive loneliness, even isolation. The walls built for protection from disturbances have become a prison.

 *Clear-headedness / rationality / (self)discipline:* Towers are by definition tall buildings. From the top, you can see very far. Thus, the tower represents a clear view. If you take this not literally but figuratively, this ituation translates into clear-headedness. You can only see things clearly when your judgement isn't clouded by passions, when you exercise self-discipline. Because of this, the Tower can also represent rationality, as well as emotional distance; or the ability to distance oneself from a situation. Now, being able to distance ourselves is important to make judgements based on facts, and to avoid being influenced by other people's negative emotions. But again, exaggerated it can also be a harmful thing. The Tower then stands for an inability to be emotionally close to others, icy sedateness, overly rigid self-discipline.

*Representation / pride / excellence*: Towers can be seen from afar. They literally tower above all other buildings, shouting "I'm the tallest!". Thus, the Tower may stand for hierarchy, and also for pride. In some cases, it will represent justified pride in one's accomplishments. But in others, it suggests bragging, and especially, arrogance. The Tower could mean that excellence is indeed there, that we're "on the top" of our field. But it can also be a warning that we're thinking we're better than others, that we're lording it over others. Additionally, in some cases, I have interpreted the Tower as the advice to rise above a situation - to not let myself be pulled down into unproductive behaviour or messy situations.

*Authority / control / government:* Another reason why towers were built was to mark the ruling authorities' territory. So the card Tower might represent the government, the government's institutions, or any types of organisations which wield power over people's lives. Additionally, and more applicable for my own readings, the Tower may stand for authority, for positions of authority, positions at the top. In that sense, the Tower can indicate leadership. But I tend to see it as a rather cool, impersonal, maybe overly bureaucratic type of leadership - more control than guidance, really. Along this line I have often interpreted the Tower as a control freak mentality!

 **See also** the *annakblogs* article [>> So, is the Tower a positive or negative card?](https://annakblogs.wordpress.com/2018/02/27/tower/)

**About the Image:**
 I hope that my illustration of the Tower is pretty much self-explanatory. The tower itself is tall but unadorned apart from the golden roof, the golden flag pole, and some gold ornaments around the top windows, rather cold from the outside. We don't know what it looks like from the inside - the solitary chamber at the top might be quite comfy! - but from the outside, to someone who wants to get in, it is definitely not welcoming at all. The door and all windows but the highest ones are shuttered and barred. The shutters as well as the banner show a red field crossed by a blue St Andrew's cross. This is yet another way my Tower is visually saying "no!". Furthermore, the red in the crest is intended to represent passion, and the blue, rationality. Accordingly, the crest is expressing that rationality has to trump passion.
Furthermore, while the base of the Tower is close to the ground (the treetops are visible), its highest part rises far above the clouds even. From the topmost windows, which are open, there is a beautifully clear, serene view.

One last point worth mentioning is that I did design the Tower to be the Key's counterpart, in some respects. For just as the Tower says "no" and "stay out" the Key says "yes" and "welcome".

![](https://www.annak-tarot.at/lenormand/pictures/33-key-extra.jpg)

Maybe you have already noticed that the surroundings of the Tower are the same as the outsides of the door of the Key. Thus, Tower and Key could easily depict two different points of time in the same scenario. While in the Key the tower's inhabitant has opened the door and is standing in the open door frame in the card Tower the door is barred, entry is denied. Another clue that both cards are part of the same environment is that the door leaf in the Key shows part of the same cross which is on the the outside of the Tower's door.
