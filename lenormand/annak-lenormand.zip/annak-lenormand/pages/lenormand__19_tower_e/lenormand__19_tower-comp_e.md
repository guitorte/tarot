---
title: "lenormand | tower | comparisons"
source: https://www.annak-tarot.at/lenormand/19_tower-comp_e.html
---

tower

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Tower, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Authority / Leadership**

|  |  |
| --- | --- |
|  | **Tower**:  A cold, impersonal, impartial leading figure or type of guidance. "Artificial" authority that comes from the position one has, no matter whether one's personality type is suited to the job or not. |
|  | **Bear**: A strong, charismatic, warm-blooded, and personally involved leading figure or type of guidance. Natural authority. |
|  | **Dog**: A person who can (emotionally) support and help but isn't able to guide or lead. |
|  | **Child**: Leadership in the form of gentle guidance and support is needed to gain experience safely. Bear might be too loud or over-protective; Tower too strict and cold - a good dose of Dog would help while Dog only might be too weak. |
|  | **Clouds**: Lack of leadership and guidance - guidance would be needed to get out of confusion or despair. Both Bear and Tower could help a lot here but in the end mightn't help with becoming self-reliant and might thus keep the querent in dependence on their leadership. |

**Power**

|  |  |
| --- | --- |
|  | **Tower**: Power through position. Power in the sense of control. |
|  | **Bear**: Power in the sense of natural authority. Powerful, personality. Power in the sense of dominance. |
|  | **Snake**: Hunger for power. Diplomatic or political power. |

 **Independence**

|  |  |
| --- | --- |
|  | **Tower**: The type of independence arising from a lack of close emotional relationships, or from working or living alone. |
|  | **Fox**: Independence from others' judgements (moral, aesthetic, political etc.) - to stick with what we have found to be true no matter what it costs. |
|  | **Dog**: Dependence - in general, but especially the dependence on the approval and love of others. |
|  | **Anchor**: Dependence in the sense of being stuck with something or someone, of being tied to someone or something by practical necessities. |
|  | **Ring**: Dependence in the sense that we're bound by a promise, or because we can't that easily "undo the ties that bind us". |

**Open vs. Close, Yes vs. No**

|  |  |
| --- | --- |
|  | **Tower**: To shut others out, to distance oneself from others or from some experiences. To say "no" to something. To forbid something. |
|  | **Key**: To let others in, to embrace someone or something, to open oneself up to an experience. To say "yes" to something. To allow something. |

 **Exclusion**

|  |  |
| --- | --- |
|  | **Tower**: To exclude others from one's emotional life and thoughts; to prevent them from coming into one's private sphere. |
|  | **House**: To exclude strangers, non-family members; to not welcome someone into one's family or circle of close friends. To ward off anything that is unfamiliar or different. |
|  | **Book**: To keep others purposefully unaware of or uneducated about something and thus keep them "outside" the esoteric circle. Excluding others in the sense of elitism. |
|  | **Key**: The opposite of exclusion. To open one's door to others - literally and figuratively speaking. To meet others without fear or distrust but with open heart and mind. To welcome strangers. To let others be part of a secret. |

**Defence , protection**

|  |  |
| --- | --- |
|  | **Tower**: Protection and/or self-defence by putting up (and asserting) boundaries. |
|  | **Bear**: Protector; protection of others, protective behaviour. To make provisions for the future. |
|  | **Fox**: Self defence. Self-care. To look after oneself first. |
