---
title: "lenormand | tower | keywords"
source: https://www.annak-tarot.at/lenormand/19_tower_e.html
---

**TOWER 19**

**Keywords**

***Nouns / phrases:***

Walls of defence, boundaries, "No!", prohibition. Retreat, solitude,
loneliness, isolation. Clear view, clear-headedness, self-discipline, rationality,
aloofness. Inability to be close to others. Hierarchy, pride, bragging,
arrogance. Excellence, expert. Government, the government's institutions, organisations
which wield power over people's lives. Authority, position of authority,
top position, leadership.

 ***Activities:***

To put up walls of defence, set boundaries, prohibit. To withdraw. To
distance oneself, remain aloof, isolate. To think about something rationally with a cool head. To
rationalise. To top, excel. To pride oneself, brag, lord it over others. To rise above. Govern, control.
 ***Attributes:***

Denying, forbidding. Solitary, distanced, lonely, isolated, aloof. Closed off, segregated.
Disciplined, clear-headed, differentiated. Independent. On top, leading, best. Proud, snotty, arrogant.
Controlling, authoritarian. Ruling, institutional, state-run. **As a person:**  Someone with the above attributes. Person in a position of authority. Lonely or aloof
person. Strict, cold, or arrogant person. Control freak. Expert.
 **As advice:**
 You can say no! Distance yourself! Be proud! Rise above it! Negatively: Don't be a
snob! Don't isolate yourself!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Either: X is not going to happen. Or: We ourselves control if/when X happens.
Traditionally to some: one year.

 **See also** the *annakblogs* article [>> So, is the Tower a positive or negative card?](https://annakblogs.wordpress.com/2018/02/27/tower/)
