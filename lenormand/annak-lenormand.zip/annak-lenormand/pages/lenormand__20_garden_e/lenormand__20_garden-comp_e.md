---
title: "lenormand | garden | comparisons"
source: https://www.annak-tarot.at/lenormand/20_garden-comp_e.html
---

garden

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Garden, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Privacy vs. publicity; social life**

|  |  |
| --- | --- |
|  | **Garden**: Publicity. Public to *all*. Society, (social) networks, large groups. To be sociable in the sense that you know and communicate often with a great number of people. |
|  | **Bouquet**: Something is "public" within a circle of friends. Circle of friends, in-group. To be sociable in the sense that you communicate often with a certain number of good friends and rather close acquaintances. |
|  | **House**: Privacy. Private sphere - private life - to be quite unsociable outside of the family. |
|  | **Tower**: Total privacy; solitude, loneliness. Everyone is kept out. To be unsociable. |
