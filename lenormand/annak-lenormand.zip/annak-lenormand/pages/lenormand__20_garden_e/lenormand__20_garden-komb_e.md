---
title: "lenormand | garden | combinations"
source: https://www.annak-tarot.at/lenormand/20_garden-komb_e.html
---

**COMBINATIONS WITH THE
GARDEN**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Garden-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
News channel, newspaper, anchorperson, journalist. Fast societal changes and developments. Someone is outed, something is made public. Public confrontation. To approach the public. To appear brash, obtrusive, or hurried, to others. To present oneself as speedy, flashy, active. Activities in social networks. To say it out loud when something/someone is overwhelming/too intrusive.

**Garden-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
A little bit of fame or popularity (don't take it too seriously). Opportunity in the social sphere. To move in social circles with ease; untroubled meetings and social contacts. To act irresponsibly within society. Risky social behaviour. To present as an easygoing person. Public entertainment venues. To dabble in networking/internet/publishing etc. To be totally okay with something being made public. Newspaper ads which offer what one is looking for.

**Garden-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Social (ad)venture; to embark on a social expedition; to rise in society; the attempt to change our social position or reputation. The attempt to change society. To present as adventurous. Foreign culture; to explore a different (sub)culture. To leave one culture behind; to search for the culture/society where we could finally settle. To search for publicity. The public / everybody tries to discover something. To travel together; to explore something together. To change something by collective effort. Publication of one's research. Social experiment. Someone is not committed to their team. An absent team member. Someone important has left the team.

**Garden-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Conflict between private
and public. Someone's privacy is violated. A family in the public eye. Society's traditions, traditional public venues. Public buildings. Social rules. To feel at home in society / large groups of people. Family teamwork. To be used to networking. Family outing. Family member who is out. Family reputation. To (re)present one's family. Disclosure of private matters.

**Garden-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Visibility of the body; exhibitionism. To model, to perform publicly. Mainstream/societal view of the
body, nature, or the physical world in general. Materialistic society. Park, local recreation
area. Communal work in nature; communal health projects. Complex physical structures. Physical teamwork. Community which is healthy, "alive". To feel deeply rooted in a specific culture or group. To present oneself as fit, healthy, natural, calm.

**Garden-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To deceive the public; appearance is deceiving; someone presents a different persona to the public than what they are in private. To be confused and insecure in social settings. To present as insecure. To have the reputation of playing with hidden cards. Poker face. Cultural misunderstandings. Everybody is confused. Unclear network/structure. To admit publicly that we are confused/don't know where to go/what to do.

**Garden-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Going public with something will have to be handled very
diplomatically. To be open and above board about your desires and/or motives. Politician; diplomat; spin doctor, press officer. To have ambitions to become
famous or at least to be in the public eye. To crave publicity.

**Garden-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Loss of reputation. Public grief.
To withdraw from public life. To bury personal dreams and needs in order to fit in with mainstream society. End of publicity; no more publicity. To make an ending public. To publicly end something. To keep something away of the public eye. Obituary. Funeral service.

**Garden-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To meet someone in public - to go to a restaurant or cafe etc. together with one or several friends.
To present a friendly face on the outside even when we don't feel friendly. A culture of welcome. Commonly accepted standards of beauty. To want to be pretty to others. To have a very large circle of friends. Facebook type of friendship. Lobbying, marketing, PR, advertising.

**Garden-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To shut out the public; to discontinue involvement in social networks; hurtful experiences with the public, harsh public opinion. Efficiency through networking. Efficient network. To present oneself as efficient. To make a break-up public. Public announcement of a cut/of putting an end to something. Public pain/hurt. Sudden, unexpected publicity. Well-deserved public opinion. No more publicity.

**Garden-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Public dispute; shitstorm; media frenzy, violation of privacy, online harassment. Public humiliation. Public apology is needed. To confess one's guilt to the world. What we are most ashamed of is made public. Violent society; aggression in groups. Societal conflicts. Destructive parts of culture. Public outcry (for justice).

**Garden-Birds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)**
Social situations stress us out. Noisy public (e.g. traffic but also noisy crowds). Very busy and hectic social life.
Worries about something becoming known. Nervousness before coming out. To make a very nervous impression on others. To present as very importantly busy. Chaotic community; unstructured or even messy teamworking. Inability to find one's place in society. To blab a secret to everybody. Gossip on social media. To be very involved and active in social networks. To network busily. To react quickly when our reputation is at stake.

**Garden-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Inexperience with media, the public, publishing, politics etc. Someone who believes everything society says. New social circles, new networks. To begin to gather experience with social networking. To present as innocent/naive/weak/delicate. Guileless acting in public - authentic public behaviour. Public game events.

**Garden-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To deal with the public/meetings etc. in a cautious or self-centred way. To distrust public opinion. To distrust appearances. To conceal one's true self from the public, or at least: to be very cautious about what one reveals. A strong in-group/out-group sense. To present in a way that serves oneself - maybe in an unauthentic way. To identify strongly with the image one projects to others. Someone wears their selfishness on their sleeve.

**Garden-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Something that has a strong
(emotional) influence on society as a whole - e.g. propaganda, public opinion, the pressure of mainstream. Charismatic public leader. To present strong and dominant (even though one might feel different). To be influenced a lot by the media, public opinion, mainstream ideas, social networks etc. A very strong social network. Powerful public relations.

**Garden-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Dreams about being famous. Society's higher purpose; a spiritual view of society. To put too must trust in public opinion; to be too trusting of social networks. Public spirituality; public worshipping. To be in awe of someone who is in the public eye. To present as spiritual/trusting/idealistic. The ideal society; to idealise one's own other other cultures. Illusions about how society works. To make meaningful connections via social media.

**Garden-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Society changes slowly, over time. A (sub)culture or network transforms from within. To emigrate to a different country. To make one's transition public. To transition together. Mainstream / commonly expected or at least accepted transformations. A transformation towards publicity; a publishing process. The longing to be part of society, to take part in cultural events, to be out. To reorient oneself in society or in a specific group; to redefine one's role in society. It's inevitable that in the end everyone will know.

**Garden-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Someone who follows the crowd, who always agrees with the mainstream, who is very dependent in their self-worth on how society thinks about them. Communal support; to help someone out together. To work together for the benefit of each other. Everybody supports everybody else - solidarity. To want to help everybody. Support group; supportive networks. To be (overly) loyal to one's own culture. To present as loyal/helpful/friendly.

**Garden-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Conflict between seeking solitude and being a person in of public interest. Someone who is not a team-player still has to network. It's all about representation. To present oneself as rational/aloof/best. Public authority. Public organisations/institution. To believe one is better than the crowd. Cultural arrogance. On top of society. To control what becomes public. To not make something public. To shut the public out. To withdraw from the public/from society.

**Garden-Garden[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Public network. Public announcement. To announce something to everybody. Big groups in public places. The attempt to mainstream everything/everybody.

**Garden-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To stubbornly refuse to take part in social gatherings / society. Difficulties with teamworking or networking. It's hard to come out of the closet. Social hurdles. Institutionalised and/or structural discrimination. To tackle something together. Shared problems; problems that concern the whole of society.

**Garden-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Multiculturalism. To move freely within society. Many different paths open up when we network/teamwork
successfully. Sub/counter cultures. Alternative culture. To chose a community. Choice between different communities. Public indecision; to leave the impression on others that we're indecisive, hesitant. To present as tolerant. Ambivalence concerning the society we're part of. Think first before you announce something to everybody!

**Garden-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Society is corrupt; corrupt parts of media or politics. Unwholesome mainstream opinion, unhealthy culture; corrupt networks. Someone's reputation is destroyed. Dishonest representation. To make public that something is wrong. Conflict between wanting to keep something secret and being open about it. To keep something a secret from the public. To slander someone publicly; to lie to the public.

**Garden-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To find love and understanding in social networks. Public display of affection. To announce one's love. Proposal in public. Publicly accepted forms of showing affection. To
organise a charity event, fundraiser etc. to help people in
need. To go out in order to find romance. A culture of love. Loving, compassionate communities. The attempt to show kindness to everybody. To present as caring, compassionate.

**Garden-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Public relations, social networks, social connections. To make a promise in public, or to everybody or at least many people. Public commitment ceremony, e.g. marriage proposal or wedding. A connection which is common knowledge. Something which connects everybody, something which binds the individual members of a community together. Common purpose, collective goal. Social cohesion. Group/community with very strong team spirit. Predictable reaction to an announcement.

**Garden-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Newspapers, news
channels - venues which make facts public. Public knowledge. Public libraries, internet. Knowledge about networking and social structures. Society's intellectual elite. Social/cultural sciences. To present oneself as an intellectual; to broadcast one's knowledgeableness or good education. To proclaim something as public knowledge - as facts everybody should have access to.

**Garden-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Public communication (e.g. in the media);
meetings in public places; to write a letter to the editor; networking. To communicate with an audience. Conversations about societal issues. To say something out loud - so everyone can hear. To make something public. To express something very clearly (visibly/audibly etc.) and without restraint.

**Garden-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
A man is exposed. Man who exposes, reveals something. Man who goes along with the mainstream, with what's commonly accepted. Men's collective, men's union. To show up a men.
Men with no sense of privacy. Men who is in the public eye (e.g. politician); men who networks, men for whom public opinion and/or his reputation is very important. To present as male. To meet a man in public. Men in society. Male-dominated (sub)culture.

**Garden-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
A woman is exposed. Woman who exposes, reveals something. Woman who goes along with the mainstream, with what's commonly accepted. Women's collective, women's union. To show up a woman.
Woman with no sense of privacy. Woman who is in the public eye (e.g. politician); woman who networks, woman for whom public opinion and/or her reputation is very important. To present as female. To meet a woman in public. Women in society. Female-dominated (sub)culture.

**Garden-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
A man is exposed. Man who exposes, reveals something. Man who goes along with the mainstream, with what's commonly accepted. Men's collective, men's union. To show up a men.
Men with no sense of privacy. Men who is in the public eye (e.g. politician); men who networks, men for whom public opinion and/or his reputation is very important. To present as male. To meet a man in public. Men in society. Male-dominated (sub)culture.

**Garden-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
A woman is exposed. Woman who exposes, reveals something. Woman who goes along with the mainstream, with what's commonly accepted. Women's collective, women's union. To show up a woman.
Woman with no sense of privacy. Woman who is in the public eye (e.g. politician); woman who networks, woman for whom public opinion and/or her reputation is very important. To present as female. To meet a woman in public. Women in society. Female-dominated (sub)culture.

**Garden-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/0_garden_e.html)**
Exhibitionism - also in a metaphorical sense, meaning any public display of what is usually considered too intimate for publicity. To be very open and out about one's sexual life. Open air festivals, museums, dance performances, theatre, concert etc. To deeply enjoy public venues like parks or cafÃ©s. Someone who is very experienced with social dynamics. Slow societal or cultural processes.

**Garden-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/0_garden_e.html)**
To present as virtuous/righteous/pure etc. (although maybe one isn't, at least not as much). If one is honest and righteous there's nothing to hide - everything can be made public. Whistle-blowing. Community with strong moral values. Virtues upheld by a whole culture or a network. Virtues relevant to networking in particular / society as a whole. Social justice issues. Righteous politician. Honest representation; honest add campaign. To advertise one's virtues. To "clean up" society.

**Garden-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Fame; public recognition; public celebrations; to share joy with everyone. Something is extremely visible, exposed, to everyone. To enjoy networking / social media. To present as a happy/confident person. To go out during the day; to spend a day at a public venue. Festival. Someone keeps announcing things which are already obvious to everybody. To let the cat out of the bag but everybody already knew.

**Garden-Moon
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)**
A respite from the public. Public places where we can rest. Fear of the public or of crowds or open spaces. Social phobias. A deep emotion that is very visible or should be owned up to publicly.
To openly flaunt deep emotions or needs - to publicly revel in emotions. Mass panic and similar occurrences where the individual's emotion is swallowed by the instinct of the whole crowd. Traumata that concern whole cultures.

**Garden-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To reveal something to the public; coming out. The attempt to become more outgoing. The relief we feel when the cat is out of the bag. A group is released from something or relieved about something. A solution for everybody. A very mainstream solution. Insights into group dynamics or societal structures. To deliver insights to the public. To publish one's findings. To accept something publicly.

**Garden-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Taxes; money which belongs to the whole of society to spend. Public goods. Expensive publication - to make something public at great personal cost. Profitable announcement. To make money by making things public. (Too) much publicity; (too) many people; (too) large group. To value one's reputation. To present as wealthy. A job in public. To profit from teamwork. The mainstream values of a society.

**Garden-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
To centre one's life around public opinion / around presentation. A focus on networking. The focus (or the central person) of a network, team, community. Things which stabilise or restrict a society/community/group. Stable culture/society. To be confined by cultural expectations. To present as firm, safe, stable. A lot of daily life takes place in public places. Routine announcements. To make a break/rest at a cafe/park etc.

**Garden-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Public suffering. Being in the public eye is a burden. Society's duties: public health care, public transport, garbage disposal etc. Mainstream ideology; the pressure society puts on us. Cultural burden - the burdens we carry because we're members of our society. Networks which deal with suffering. A dogmatic approach to publicity, to coming out, to what should or should not be public.

**Garden - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)**
Not public yet; still in the closet. A very different culture or subculture that doesn't fit into what we already know. Social networks we are not part of yet. Teamworking is not yet going on. Public image as the oddball. To present as genderqueer; to come out as genderqueer. The unknown factor that influences or is behind a society, culture, subculture
A (possibly genderqueer) person with the attributes of the Garden (see the Garden's keywords).
