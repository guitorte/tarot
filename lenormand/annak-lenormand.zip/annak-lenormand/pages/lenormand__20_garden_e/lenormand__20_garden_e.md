---
title: "lenormand | garden | keywords"
source: https://www.annak-tarot.at/lenormand/20_garden_e.html
---

**GARDEN 20**

**Keywords**

***Nouns / phrases:***

Publicity, general public, public affairs, public opinion(s), public
spaces, public events. Public media, especially the internet. Society, crowds.
Culture. Mainstream, widespread thought, popular culture; depending on neighbouring
cards also sub- and countercultures. Publication, publishing, disclosure,
announcement, coming-out. Exhibitionism (not necessarily of a sexual kind!).
Network(ing), teamwork, concerted effort. Complexity, complex structures. Presentation,
representation, reputation, image-cultivation.

 ***Activities:***

To do something publicly. To mainstream. To crowd, assemble, meet (in large groups!).
To publish, announce, disclose, come out, let the cat out of the bag, expose. To network, teamwork.
To present, represent, to cultivate one's image.

 ***Attributes:***

Public, societal, cultural. Crowded. Publicly visible, out in the open. Exposing, revealing.
Commonly accepted, widely spread. Collective, concerted. Complexly structured. Presented,
presenting as, representative, presentable.
 **As a person:**  Someone with the above attributes. Representative, person in the public eye. Person
for whom privacy is a non-issue; someone for whom reputation and public image are very
important. Exhibitionist - not necessarily in a sexual sense.
 **As advice:**
 Go out! Make it public! Teamwork more! Cultivate your image! Negatively: Don't
flaunt! You don't always have to follow the mainstream!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When in public; at a public event; only when you can do it together with others.
On national holidays.

 **See also** the *annakblogs* article [>> So, is the Garden a positive or negative card?](https://annakblogs.wordpress.com/2018/03/06/garden/)
