---
title: "lenormand | mountain | interpretation"
source: https://www.annak-tarot.at/lenormand/21_mountain-annak_e.html
---

mountain
 **INTERPRETATION**

*Difficulties / Refusal / Elephant in the Room / Silence /
Blockade*

**About the meaning:**
All the following interpretations of the Mountain spring from the sheer physical size of mountains; their long, long development.

*Difficulties / obstacles / challenge:* First of all, the Mountain stands for difficulties,
obstacles, impairment, challenge, hurdles, for anything that is in your way and/or needs to be
overcome. It can represent problems, and problematic situations or behaviour.
It is important though that difficulties and challenges are not necessarily something bad. We need challenges in order to grow. So the Mountain can be a hint that it is time to look for a challenge, or to face difficulties with grace. And in rare cases, depending on context, I also interpret the Mountain as "conquest" or (especially in combination with Tower) as "victory over x".

*Persistence / patience / endurance*:
Because of the nature of mountains (their shaping - growth or shrinkage - is usually so slow that to our human eyes mountains seem to be eternal) the Mountain is a great symbol for persistence, patience, and stubbornness, and for long times spans - for (en)durance, and permanence. It can represent things that last for years, or that seemingly last forever.

*Weight / physical presence / refusal / unwillingness:*
If you look at the physical attributes of a mountain you will probably come up with "great weight", "great size - hight and width", and maybe "physical inflexibility". Thus, the Mountain can represent
objects with these qualities, but also people who are big, tall,
fat or even obese, and people whose bodies are stiff and inflexible. But it can also mean that something or someone is physically very much there, so much that their physical presence might even feel overwhelming.
Now these characteristics could also be understood in a non-physical way. The Mountain then represents something important that grabs our attention. It stands for inflexible thinking, unwillingness to budge or back down, relentlessness, or, and that's what I have found most helpful for many readings, refusal. It can mean that someone is refusing or unwilling to do something.

*Something obvious / the elephant in the room:* On an even more metaphorical level, a strong (physical) presence translates into "something that can't be overlooked because it is so obvious". So sometimes I interpret the Mountain as representing something the querent should stop trying to pretend they didn't know, or stop trying to act as if it weren't there. Put a bit differently, the Mountain is a wonderful representative for the elephant in the room - for something awkward which is seen by everyone but no-one dares mention it. The Mountain can mean that there's no use trying to avoid a certain issue - we have to deal with it because it won't go away until we do.

*Silence / motionlessness / blockade:* Mountains are majestic; they are so much  *there* that they almost seem like gigantic living beings. But they are very silent and unmoving. Depending on how you look at them, silence and motionlessness have something very relaxing about them, and they may feel like a big relief, even restorative, to you. But especially if you apply them to relationship dynamics, motionlessness and silence might be perceived as (emotionally) cold, as unbearably stubborn, and rigid even. And translated into a situation, a stubborn refusal to move equals blockade, blockage, or deadlock.

 **See also** the *annakblogs* article [>> So, is the Mountain a negative card, then?](https://annakblogs.wordpress.com/2018/03/17/mountain/)

**About the Image:**
 Many Lenormand decks show a Mountain that is reminiscent of the kind of mountain Heidi grew up on: a mountain of the Alps. There were lots of rock and steep slopes but there were also soft grasses and fir trees, and on her hikes the little girl had the company of birds and butterflies, and of course the goats. Having been raised close to the Alps myself, they definitely do not represent problems or deadlock to me. Athletic challenge, yes - but not the forbidding barricade, the rigid obstacle, that I understood the Lenormand Mountain was symbolising. So for my Mountain I chose one that is more like a mountain of the Himalayas - where there's only rock and gravel and ice, where there's utter silence apart from the sound of the wind. Overcoming this icy, silent, and unmoved entity, with no suaveness to distract you from the exertion, would very definitely not just be a gruelling physical challenge. It would take you to your mental and emotional limits.
