---
title: "lenormand | mountain | comparisons"
source: https://www.annak-tarot.at/lenormand/21_mountain-comp_e.html
---

mountain

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Mountain, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Nothing changes because...**

|  |  |
| --- | --- |
|  | **Mountain**: ... there is a blockage, an obstacle. Or because we're stubborn. |
|  | **House**: ... because we're conservative, because we don't allow innovation. |
|  | **Anchor**: ... because we're dependent on the status quo, or can't or won't let go. |

 **Stillness vs. movement**

|  |  |
| --- | --- |
|  | **Mountain**: To be unmoved, heavy, silent, inflexible and stiff. |
|  | **Birds**: To be hectic, light, chatty, flexible and quick. |

**Inflexibility**

|  |  |
| --- | --- |
|  | **Mountain**...  could bend but won't. Someone is inflexible out of sheer stubbornness or spite. |
|  | **Tree**... maybe would like to be more flexible but can't. Someone is inflexible because they are so deeply rooted, or because their inner nature is so calm and relaxed that they are unable to move or change quickly. |
