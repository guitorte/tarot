---
title: "lenormand | mountain | combinations"
source: https://www.annak-tarot.at/lenormand/21_mountain-komb_e.html
---

**COMBINATIONS WITH THE
MOUNTAIN**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Mountain-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Difficult news. Sudden(unexpected) hurdles. To try and block change or react to someone's advances with stubborn silence. Difficult or challenging changes, bad news.
Blocked movement, something or someone is stuck; tension. To tackle something very actively. Boundaries are pushed. Intrusive presence; someone or something takes too much room.

**Mountain-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To not take difficulties
too seriously; to just go ahead and give something a try. Difficulties
with being at ease. To remain untroubled by challenges.
To be unmoved by the small joys of life. No luck, no ease. The elephant in the room is that you or somebody else doesn't actually care that much. To be unwilling to just give something a try. Enduring, lasting good luck.

**Mountain-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To seek out challenges. Challenging change. Difficult journey. Forced pause; developments have come to a stop. Impeded/delayed departure. Something blocks change. The refusal to change anything. To leave behind someone who is just hindering us. It's the elephant in the room that someone will soon leave (or won't commit), or that someone important is not there. Conflict between someone who refuses to move and someone who has itchy feet. That which blocks us from leaving. To not express one's desire to leave. Someone is going to leave; there's nothing which can be done to stop them!

**Mountain-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Familiar challenge; to be used to having to jump hurdles. Comfortable silence. Very quiet or stubborn family (member). Lack of communication in the family. No one in the family talks about the elephant in the room. Difficulties with the home and/or family. Debilitating compliance to tradition/rules. Never leaving the comfort zone creates a rather boring, too quiet, unchanging, life. Strict, unbudging conservatism. To refuse access to our private life.

**Mountain-Tree[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Physical challenges - sport. Inability to get going. To feel unable to move - dislike (and/or lack) of physical activities. To replenish your energies by being silent and still. Vital energy is so slow and overly calm it feels unpleasantly like it's frozen. An actual, physical, real, mountain. Very extreme stubbornness; stubborn persistence. To slowly grow into something you used to feel was unmanageable task. To deal with difficulties pragmatically and calmly.

**Mountain-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To be completely stuck in a problematic, confused situation. To be so tangled in your own confused ideas that you can't move right or left anymore. Confusion and despair are proving hard to overcome. A secret no one talks about. To be not quite aware of how big a challenge will be.

**Mountain-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To seek challenge. To have reached an impasse in your efforts to get somewhere or something. An obstacle is between you and what you want. Hot desires are met with cold silence. To be unmoved by someone's attempts at seduction.

**Mountain-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Big grief, great loss that feels impossible to overcome. Inability to go through with ending something. It's time to end silence; it's time to start to
move again. All involved know that something is over but no-one wants to admit it. To hide one's grief behind silence or seeming emotional cold.

**Mountain-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Social phobia (to freeze in social situations). Difficulties with making or accepting compliments
or with giving or accepting gifts. It's going to take a long time
until you and someone else (or a group of people) will come to
accept/like each other. It's difficult to make friends with a person,
idea or situation. Exaggerated problems. A greatly embellished tale of conquest/victory. Praiseworthy patience. Friendly silence. Tackling social dealings/gatherings.

**Mountain-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To break the silence. To
suddenly start moving again. To make a painful decisions unemotionally, coldly. A very difficult act of severance. For a long time nothing happens - but then it will happen extremely quickly. To be surprised by the suddenness of something after a long period of standstill. In order to get things moving again you have to be quick, not hesitate even a bit, and maybe risk pain (a tear off the band-aid quickly situation). To get over something.

**Mountain-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Threat of a challenge. Abuse/aggression/shame/conflict that we keep quiet about. (Inner) conflict or guilt so strong it makes us freeze up, unable to act. To punish with silence - the silent treatment. To not react to bullying/aggression. To react with stoic calm to attacks; to be unmoved by attacks. To patiently wait out conflicts. Or: someone's unmoved reaction to our criticism drives us mad. To be driven to extremes (attacks, aggression) by a difficult situation we think can't be solved with other means.

**Mountain-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)**
Big worries. Paralysing, numbing stress. Stressing problems. Always present, never quiet circling thoughts. Conflict between noise and silence, nervousness and total, utter calm, between wanting (or having) to move and wanting (or having) to be still.
To be worried about a problem you're facing. To be impatient for something that's not going to happen any time soon. Standstill/having to wait makes you fidgety and restless. To distract yourself from difficulties. Challengingly much is going on. To jump from one challenge to the next without ever quite mastering one.

**Mountain-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Inexperience is hindering your progress. Small problems (or problems that will become bigger if you don't do something now). Growing
silence. Little weight, or slow weight gain. Difficult child. No
communication with a child. Playful approach to challenge. A problem so serious, a challenge so big, that it might break the inexperienced. To challenge child or student. Naive approach to difficulties.

**Mountain-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To be wary of challenge/difficulties. To cautiously keep quiet. To be very absorbed in a challenge/difficult situation. To deal with a problem you need to be very cunning and maybe think of yourself first. Problematic self-absorption. To become silent/unmoved as self-defence. To block what you don't agree with. "No means no." To adapt to a difficult situation.

**Mountain-Bear[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Problem/blockade/elephant in the room that dominates your life. Important challenge. To ensure there is provision for hard times. Someone who helps you overcome difficulties. To be forbidden something very strictly. Parent, teacher or boss who is extremely stubborn, or who you can't talk to. Something or someone that strongly influences you for a very long time (possibly even when they aren't there anymore; e.g. a parent's disappointment in you is still painfully present for you even when the parent is long dead).

**Mountain-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Inability (for fear, or because of doubts?) to reach for the stars, to dare to live your dream. Hope has become doubt. Some faith which used to be strong now suddenly has gone silent. Trust issues. To have the experience of transcendence when in the mountains. The spiritual quality of deep silence (internal and/or external). To feel a disconnect between yourself and something or someone; a general feeling of disconnect.

**Mountain-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)](https://www.annak-tarot.at/lenormand/16_stars_e.html)**
Difficult transition. To tackle a transition. A transformative process has been blocked, come to a standstill. Transformative power of silence. A longing for silence. Someone is an extremely quiet or unemotional person by nature. To not allow oneself to transform. Conflict between the need for change and the wish for things to just stop and stay as they are forever. A very slow but lasting transformation. Difficulties with letting things run their natural course. A challenge / problem that will keep turning up in your life until you have mastered / faced it. Return of one's nemesis. In order to tackle this challenge you need to reorient yourself.

**Mountain-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Difficult or silent friend. Something is an obstacle to friendship. A friendship that has grown cold. Our follower-mentality or unwillingness to stand up for ourselves hinders our progress. Insurmountable need to please others. To wait for permission in vain. To ask for help with a problem or challenge. A friend in a difficult situation. To be utterly devoted to someone who doesn't show any sign that they return the feeling. A challenge to someone's loyalty. Someone very tractable vs. someone who won't budge an inch.

**Mountain-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Extreme/hard to bear loneliness. Silent retreat; to retreat in the mountains. Difficulties with the authorities or with authority in general. To question authority, to challenge the person at the top. Emotional silence; to feel nothing. Clear, fresh air. The need to put up walls of silence. To very stubbornly stick with "no!". Authority through physical size. To come out on top.

**Mountain-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To stubbornly refuse to take part in social gatherings / society. Difficulties with teamworking or networking. It's hard to come out of the closet. Social hurdles. Institutionalised and/or structural discrimination. To tackle something together. Shared problems; problems that concern the whole of society.

**Mountain-Mountain[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Big challenges, unsurmountable difficulties. To be blocked/hindered by your own or someone else's silence. It's hard to break the silence. Being overweight is a huge issue. Blockade or standstill that seems to last forever. Something eternal. Challenges or difficulties or silence etc. are very dominant in the querent's life.

**Mountain-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Problematic choice, difficult decision; inability to choose. Manifold difficulties; multi-faceted problem. A choice as a stumbling block. That which hinders a decision. To tread water for an extremely long time. To feel so overwhelmed by the number of alternatives that are open to us that we can't move anymore at all. Something or someone is between us and freedom. To choose our challenges. To take the challenging road.

**Mountain-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Something is gnawing away at your ability to resist. To be close to giving up. Something big becomes smaller. To keep quiet about an unhealthy secret, or about something dirty or corrupt. The elephant in the room: a sickness, or, that something is bad and unhealthy - but this fact is ignored. Someone sneakily puts obstacles in your way. Unhealthy silence. Unhealthy inactivity. Weight loss. Big loss. Exhaustive/draining challenges.

**Mountain-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
A difficult relationship. Hurdles to jump, obstacles to overcome, before one can find love. A relationship suffers from the silence from one or both partners. A cold heart. Love grown cold. No more tenderness. To refuse compassion. To be unable or unwilling to forgive. Rigid views on love or on how to properly show affection. Person who cannot show affection, who won't soften up. To try to get through to someone with love. To stubbornly love no matter what.

**Mountain-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
A
difficult/problematic connection. A challenging liaison. A commitment to something keeps you back. To persist because you're committed. Enduring commitment. A lasting connection. An obstacle to making a connection. Interrupted connection; refusal to connect or commit. It's hard to connect. Connection that isn't felt. Silence helps to bond or, to bond through silence. The cause for a problem; the effect of a problem. Inability to severe a tie. To stubbornly commit to something against all odds. Unbudging commitment. Predictable difficulties.

**Mountain-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
A fact/truth which is problematic or which challenges you. Education on something is very hard to obtain. To be kept away from education. An obstacle in a learning process. Learning difficulties. To to be left in the dark about something. To keep quiet about something; to refuse to tell the truth or share knowledge. To be unmoved by the facts and stubbornly hold true what you *want* to believe. An obstacle yet to be discovered. Lack of knowledge is an obstacle. Facts about mountains. To classify something as difficult or problematic.

**Mountain-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Difficulties with communicating, or difficult/challenging conversation. Problematic ways or means of communication. An obstacle to communication. Telling silence. Silence that (should) tell you something.
Something you just can't talk about. To finally speak about the elephant in the room. Conflict between wanting to talk about something and feeling you should keep silent about it. To address a problem. To have difficulties addressing something.

**Mountain-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Man who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Male nemesis or contender. Problems with masculinity. Difficulties/challenges specific to men. To challenge a man. To have problems with a man or men in general. To hinder a man. A man gives us the silent treatment (or the other way around).

**Mountain-Woman (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Woman who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Female nemesis or contender. Problems with femininity. Difficulties/challenges specific to women. To challenge a woman. To have problems with a woman or women in general. To hinder a woman. A woman gives us the silent treatment (or the other way around).

**Mountain-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Man who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Male nemesis or contender. Problems with masculinity. Difficulties/challenges specific to men. To challenge a man. To have problems with a man or men in general. To hinder a man. A man gives us the silent treatment (or the other way around).

**Mountain-Woman (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Woman who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Female nemesis or contender. Problems with femininity. Difficulties/challenges specific to women. To challenge a woman. To have problems with a woman or women in general. To hinder a woman. A woman gives us the silent treatment (or the other way around).

**Mountain-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Writer's (or painter's) block. Blocked creativity in general. Maybe: infertility? To be unmoved by the arts or by sensual pleasure - frigidity? Low sex drive. Abstinence, austereness. To deny yourself or someone else sensual/sexual pleasures. Difficulties with appreciating the sensual world. A very, very, VERY slow process - so slow it seems nothing is moving, but it *is*. To deeply enjoy silence. To enjoy idleness. To be extremely lazy. Fattening food.

**Mountain-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Difficult moral considerations. An obstacle to virtue. To challenge someone's ideas of morality or specific moral values. To have difficulties being virtuous or with specific virtues. One's stubborn, cold virtuousness is an obstacle (e.g. to enjoying oneself). Virtuousness which can't be shaken; purity so solid it can't be soiled. The elephant in the room is a moral issue. Problematic austereness or self-chastising. The virtue of discretion; to keep silent about something for moral reasons - maybe even at personal costs. It's challenging to do the right thing. Problematic moral views or something which is morally problematic.

**Mountain-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
An obstacle to happiness. Happiness is curtailed. Difficulties with just being happy. Difficulties with seeing the bright side of things. To be unmoved by other people's happiness; inability to be happy for yourself or for others. Problems which maybe are not that relevant. To not feel like celebrating. A challenge that's fun. A very obvious obstacle. Something *seems* to be an obstacle only on the surface.

**Mountain-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)**
Difficult emotions; something is emotionally challenging. To tackle emotional issues. Inability to connect with deep needs and fears; intuition is blocked. Emotional blockade. Obstacle that lies in the emotional area. Difficulties/problems which go very deep and/or are very relevant. To rest before tackling a challenge. Inability to sleep. Something keeps us from sleeping. Finding time to rest is a challenge. Profound silence. Quietness is weighing on us. To overcome fear. To not give in to someone's neediness.

**Mountain-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Solution to a problem; the key to mastering a challenge. To
break through silence, to start opening up. Attempts to get
someone to open up, to let them in, or to be let in, are met with stubborn, silent resistance. To refuse to open up. To refuse to accept something, or to even entertain a new idea. To try hard but it's not working. To accept a challenge. To accept that things are difficult. To be willing and able to learn from difficulties. An obstacle to learning. Being too open and accepting is problematic.

**Mountain-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
To value challenges. Many problems. Financial concerns; financial issues weigh on
you. Nothing happens financially, no change in work life. Nothing moves in the order situation. challenging job. Hoarding, or being
close-fisted. Overcoming a difficulty will result in great profit in some way. An obstacle to profiting. Wanting to profit is an obstacle.
it.

**Mountain-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Status quo will not change for a long time yet. Status quo is hard to bear. To find it challenging to stay put. An obstacle to settling down. To focus on difficulties. Whole life revolves around a specific problem or difficulties in general. To hold on stubbornly and/or patiently. Persisting silence. Everything revolves around the elephant in the room. No weight loss / continuing weight gain.

**Mountain-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
Something weighs on you terribly; unbearable pressure. Something is very hard to bear, difficult duty or responsibility. Something is blocking you from fulfilling your life-task; obstacle to following your calling. A challenging stroke of fate. Exhausting challenge; difficulties that wear you down. To persist out of a feeling of duty. Problematically dogmatic.

**Mountain - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)**
A very obvious, impossible-to-overlook, question mark. No one talks about the question mark; no one talks about the oddball. It's so outside of everything we are used to that it's impossible to express or talk about. Not permanent yet. It might still be moved. Not clear at all if it can ever be moved. An unknown factor might present an insurmountable hurdle. To silence or put hurdles in the way of genderqueer people. To try and block one's own genderqueerness.
A (possibly genderqueer) person with the attributes of the Mountain (see the Mountain's keywords).
