---
title: "lenormand | mountain | keywords"
source: https://www.annak-tarot.at/lenormand/21_mountain_e.html
---

**MOUNTAIN 21**

**Keywords**

***Nouns / phrases:***

Difficulties, problems, obstacles, impairment, hurdles, challenge.
Problematic situations or behaviour. Things that need to be overcome. In a positive
sense: the experience of overcoming something; conquest. Something that
cannot be overlooked, the elephant in the room. Presence, physical presence.
Weight, obesity, great size, inflexibility. Long time spans, permanence, (en)durance.
Silence, motionlessness, blockade, blockage, deadlock. Relentlessness,
persistence, patience, stubbornness, rigidity. Refusal, unwillingness in general.

 ***Activities:***

To complicate, challenge, hinder, block. To overcome. To insist, persist, endure. To not
budge or back down. To refuse, to not want to. To silence, to keep silent, to keep still.

 ***Attributes:***

Difficult, problematic, obstructive, restrictive, impaired. Tackling. Conspicuous, ostentatious,
glaring. Present, in place, here and now. Big, tall, heavy, overweight. Unmoved, blocked,
rigid, still, quiet, silent. Stubborn, persisting, unwilling, refusing, forbidding. Permanent, enduring,
forever.
 **As a person:**  Person with the above attributes, esp. big or overweight, tall, quiet, stubborn, rigid.
Someone "solid as a rock", or: your nemesis or contender.
 **As advice:**
 You can refuse! Keep silent; hold still! Persist! Tackle the challenge! Negatively: Don't
be so stubborn! Get moving!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Very long time spans (even years). Long-lasting; stagnancy, stalemate. Or: something
may happen, but only if a lot of patient effort is invested.

 **See also** the *annakblogs* article [>> So, is the Mountain a negative card, then?](https://annakblogs.wordpress.com/2018/03/17/mountain/)
