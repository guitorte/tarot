---
title: "lenormand | crossroads | interpretation"
source: https://www.annak-tarot.at/lenormand/22_crossroad-annak_e.html
---

crossroads
 **INTERPRETATION**

*Alternatives, decision, deliberations, ambivalence, hesitation*

**About the meaning:**
The meaning of this card is pretty straightforward. Picture yourself standing in the middle of a crossroads, looking around at all the different paths heading off in different directions. This vision will give you a great starting point for the interpretation of the card - my own interpretations are derived from it, too.
And I have added one idiosyncratic paragraph about the interpretation of the rock in the centre of my own version of the Crossroads. Maybe you'll find this paragraph inspiring, but you're also welcome to just ignore it.

*Different direction(s) / alternatives / diversity:* A crossroads
is a place where two or more roads meet. So, standing at a crossroads, we are presented with different directions we could follow. This is the first dimension of meanings of the Crossroads: different directions. The card represents all different routes we could take at any given time. When we have asked about a relationship the Crossroads can represent diverging paths - not necessarily separations or split-ups, but that the people in the relationship might have different interests, might be drifting apart because they walk too few of their lives' paths together. In general, the Crossroads represents alternatives, options, and also potentials - e.g. currently unrealised abilities, or yet-to-be-pursued goals. When the question asked has nothing to do with different options but concerns one specific issue the Crossroads can point at the different facets of that issue. Sometimes the Crossroads stands for different versions, variations. It represents plurality, and diversity.

*Decision / choice / free will:* When we realise that we are faced with alternatives, with several options, our autopilot shuts off. Now we *have to* make a conscious decision how to proceed. This is probably the most used dimension of meanings of the Crossroads
: decision, and choice. In the most general sense the card just says that we "have a choice" - that there are several alternatives available to us, that something is selectable, or arbitrary. In that sense, the Crossroads
is also the card of free will, the freedom *to*. It can say that we needn't take the first, or the most obvious, or most common route available. The card can be a hint not to forget there's no-one else we should allow to make a decision for us, that we alone are in charge of our lives. But often the Crossroads
doesn't say that we *could* move on in a different direction if we wanted to. Instead, it says that we *must* make a decision. The card sometimes suggests that making a decision is a good thing, even if it isn't easy. But sometimes the card points out that we suffer because we don't feel ready to decide, unable to choose.

*Deliberations / considerations:* Having to choose sets a process of deliberation in motion. We look at all the alternatives, at least at the ones which seem relevant. We compare them against the overall goal, we estimate the likely risks of each, and the probability of their favourable outcomes. This is why I often interpret the Crossroads
as deliberations, or contemplations. It can stand for situations in which we ponder, reflect on, or speculate about something. The card *may* suggest that we're over-thinking. But in many cases it will hint at something *else* we should take into account but haven't considered yet. In other words, the Crossroads
is all about ifs and whens, about whethers or nots, about pros and cons.

*Hesitation / procrastination*: Reaching an actual or metaphorical Crossroads
usually makes us pause, hesitate. Sometimes, the moment of hesitation will be so short that we hardly notice it. Especially when we already have a clear idea where we want to go, and when the options we have are well distinguishable and have easy to estimate outcomes, it won't take us long to make up our minds which road to take. But sometimes we don't have a clear idea yet where we want to go. Sometimes, the options we have are not immediately obvious, or not all that distinguishable. And very often, their outcomes are not definite at all. When this is the case our hesitation will be stronger, and go on for a longer time. We might even get so unwilling to make a decision that we defer it as long as possible, that we tread water in the hope that new information will come along helping us with the decision, or that we'll somehow magically be relieved of having to make it altogether. Because of this, the Crossroads
to me not just represents hesitation but also deferral, and procrastination.

*Ambivalence / ambiguity / different angles:* The hesitation I described in the paragraph above will be especially hard to overcome when we are very ambivalent concerning the alternatives we are facing. Thus, when the Crossroads
turns up in a reading, it might also point out that we are very ambivalent - or "in two minds" - concerning a certain issue. On a more philosophical level, to me the Crossroads is the card of ambiguity, of shades of grey, of relativity. Sometimes it suggests that we shouldn't be so judgemental or dogmatic about something; that a certain level of tolerance would be advisable. The Crossroads
can be understood as a reminder that very often things aren't black and white, that there are many different sides, different perspectives to every issue. It might ask us to try and look at an issue from a different angle.

*How to make use of the rock in a reading about a decision:* Sometimes, when a querent has concerns about a decision I ask them what that rock in the centre of the crossroads of my illustration
looks like to them. Some people immediately say that it clearly represents an obstacle. They say that the rock would hinder a hiker to walk straight ahead, would require them to make the extra effort of walking around or jumping over the rock. In these cases I might inquire more of them what personal obstacle this rock could be representing. To others the rock looks like an invitation to sit down and rest. I might then ask them what they feel they would need but are still lacking to make their decision - maybe they just need some alone time, time to think, or they need more information etc. And some people don't even notice the rock until I point it out. With them, I might let go of the issue altogether. But in many cases I suggest that they make sure that they have considered all the options and their implications.

There's more about how to make use of the rock, including two example readings, [>> here](https://annakblogs.wordpress.com/2018/04/01/technique-how-to-make-use-of-the-rock-in-the-crossroads/) on my blog!

 **See also** the *annakblogs* article [>> So, is the Crossroads a positive or a negative card, then?](https://annakblogs.wordpress.com/2018/04/01/crossroads/)

**About the Image:**
 As with most cards whose symbolism is intuitive, straighforward, my illustration is quite simple: it shows a big Crossroads
right in the foreground. Apart from this main feature there are several more diverging paths in the distance - for of course every choice we make will eventually lead us to another.
There are subtle differences between the paths leading on from the junction. Some seem well-trodden, others are disrupted, apparently rarely used. Some paths lead up, some down. Some lead in the direction of mountains, others seem to lead towards the sea. But with neither you can be absolutely certain of the final destination.
There is a reason why I painted a beautiful but also hot, dry, landscape. Yes, the the sunny junction might be a pleasant place to take a break and a snack. You'd probably enjoy the strawy scent of the dry grass, the rhythmic chirr of the cicada, the creamy white dust of the road under the soles of your feet. But you wouldn't want to stay put at the Crossroads
for too long. The incessant chirring of the cicada would start to grate on your nerves and you'd long for quiet. You'd feel the beginning of sunburn, and yearn for shade. Once you'd run out of water you'd become desperate to leave the hot, dry junction. Hopefully you wouldn't have tarried for too long and have enough stamina left to walk on. And it is the same with decisions. Deferring a decision sometimes truly is the right thing, but more often only the most comfortable thing, to do - for a while. But when we tarry for too long this deadlock situation drains our resources, and dulls our motivation to eventually take action even more.

Lastly, there is the rock sitting in the centre of the junction. It turned up in the image of its own volition, without conscious consideration on my part. Only after I had already painted it I found that my unconscious seemed to have wanted it there as a symbol that being faced with alternatives is always something that makes us pause. Sometimes it makes us pause for a long and painful period of indecision, sometimes for a relaxing rest and a good think, and sometimes just for a short celebration of the fact that we're free to choose.

Something else worth mentioning is that in my book there is a connection between the Crossroads
and the Snake - they are, in some respects, opposites. And so I decided to connect the two cards visually, too. As you can see the Snake's pommegranate tree seems to grow in the same landscape the Crossroads
is set in.

![](https://www.annak-tarot.at/lenormand/pictures/07-snake-extra.jpg)

While the Crossroads
can stand for hestiation, or suggest that we are in two minds, ambivalent, about something, the Snake is about single-mindedness. There is no hesitation at all, for all options except one have been discarded - there is only the one goal straight ahead. This is why I chose blue cornflowers for the Crossroads
- someone is still tarrying, thinking - and red poppy for the Snake - someone is passssionately motivated to act.
