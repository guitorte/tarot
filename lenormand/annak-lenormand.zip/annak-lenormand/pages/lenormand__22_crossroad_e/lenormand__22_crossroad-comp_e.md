---
title: "lenormand | crossroads | comparisons"
source: https://www.annak-tarot.at/lenormand/22_crossroad-comp_e.html
---

crossroads

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Crossroads, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Freedom**

|  |  |
| --- | --- |
|  | **Crossroad**:  Freedom "to" - we're free to choose, to go where we please, to do what we want to do. |
|  | **Clover**: Freedom "from" - we're free from burden, free from responsibilities, free from outside influences. |

 **What is right and wrong?**

|  |  |
| --- | --- |
|  | **Crossroad**: To have no dogma - everything is open to discussion. To allow different opinions; tolerance; to see the good in many different ideas. Moral relativism. |
|  | **Cross**: Dogma. Strong beliefs about what's right and what's wrong. Intolerance, strong adherence to one ideology. Moral absolutism. |

 **Ambivalence / ambiguity**

|  |  |
| --- | --- |
|  | **Crossroads**: Someone has ambivalent feelings about something - for in their view, this something has both good and bad aspects, pleasant and unpleasant aspects, so they can't give a black-and-white judgement on the issue, or find it difficult to make a clear decision for or against it. Something *looks* ambiguous to us. |
|  | **Wild Card**:  Something or someone *is* ambivalent or ambiguous in the sense that they don't fit into one category exclusively - they might fit into one category in some respects, into another in other respects, (etc.), but not fully in either. Something actually *is* ambiguous by nature. |
