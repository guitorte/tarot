---
title: "lenormand | crossroads | keywords"
source: https://www.annak-tarot.at/lenormand/22_crossroad_e.html
---

**CROSSROADS 22**

**Keywords**

***Nouns / phrases:***

Different directions or routes, alternative(s), options, potentials,
facets, diversity, plurality. In relationship readings possibly: different interests,
divergent paths. Decision, free will; the freedom to. Deliberations, considerations,
speculations. All the ifs and whens, whethers or nots, pros and cons. Overthinking.
Hesitation, deferral, procrastination. Ambivalence, ambiguity, shades of
grey, relativity, tolerance. Different angle(s) or perspectives.

 ***Activities:***

To take a certain direction, to go down a different or diverging path.
To diversify, vary. To make a choice. To deliberate, consider, speculate, overthink. To hesitate,
defer, procrastinate, tarry, tread water. To relativise, tolerate. To adopt, or at least examine, a
different perspective.

 ***Attributes:***

Alternative, optional, potential, multi-faceted, versatile, manifold, diverse. Selectable,
elective, arbitrary. Hesitant, indecisive, of two minds, tarrying. Free in the sense of "free to do
what you want to do". Deliberative, contemplative, speculative. Possible; possibly, maybe. Ambivalent,
ambiguous, relative, tolerant.
 **As a person:**  Person with the above attributes, esp.: Someone who is of two minds about something
or indecisive in general, person who is confronted with important decisions. Someone
difficult to assess because they keep changing direction.
 **As advice:**
 Think before you speak/act/decide! Make a choice! Be more tolerant! Negatively:
Don't hesitate; don't procrastinate!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When, or if, it happens depends on how you move on from the present moment.

 **See also** the *annakblogs* article [>> So, is the Crossroads a positive or a negative card, then?](https://annakblogs.wordpress.com/2018/04/01/crossroads/)

**See also** the *annakblogs* article [>> technique: how to make use of the rock in the Crossroads](https://annakblogs.wordpress.com/2018/04/01/technique-how-to-make-use-of-the-rock-in-the-crossroads/)!
