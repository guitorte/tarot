---
title: "lenormand | mice | interpretation"
source: https://www.annak-tarot.at/lenormand/23_mice-annak_e.html
---

mice
 **INTERPRETATION**

*Dwindling, decay, dirt, unwholesome, behind the back*

**About the meaning:**
The meaning of this card, Mice, has little to nothing to do with the archetypical or spiritual meaning of the animal mouse living in the wild. Instead, this Lenormand card's meaning springs from the damage plagues of mice do when they infest human living spaces.

*Dwindling / deficiency / depletion:* When mice infest human living spaces they usually start nibbling away at any food supplies they can find. Each night, more and more provisions are pilfered. Sometimes, the infestation is only noticed when a conspicuous amount of supplies has "vanished". Along these lines, one of the most important interpretations of the Mice is anything which has to do with dwindling. They can mean that something is getting less, is on the wane, or being taken away. The Mice can represent loss, reduction, or atrophy; shortage, scarcities or plights of any kind (e.g. poverty, hunger, emotional neglect), and even the complete lack of something. Sometimes the Mice hint that there is depletion of some kind; for example, that something is draining our energy, exhausting our resources.
 In many cases, the Mice suggest that we aren't yet aware that this is going on! Something destructive is gnawing at us very quietly - hardly noticeable, but persistently.

*Decay / defect / destruction / dirt:* Nibbled foodstuff perishes rather quickly. This is why the Mice can be saying that something is literally decaying; or figuratively speaking rotten, foul. They can represent anything which has gone bad, is degenerated, or unswallowable. Furthermore, because mice don't just nibble at food but also damage objects, like blankets, or even furniture, the Mice may also represent destruction, or, in a less dramatic sense, defects, and flaws. Lastly, mice usually leave their droppings behind, contaminating provisions, soiling clothes and carpets. So I sometimes interpret the Mice as dirt, and filth, too - both in a literal and in a metaphorical sense.

*Infestation and sickness / unwholesome:* Mice in the house can be very bad news indeed, because they (or the parasites they carry) can spread diseases. For this reason the Mice don't just represent infestation, plagues, or pests themselves, but also anything which has to do with diseases, especially infections.
The thing is though: while I found the interpretation of the Mice as disease/infection to be perfectly coherent with the rest of their meanings, I rarely find it applicable. Instead, I oftentimes interpret the Mice as something which is unhealthy, unwholesome, or harmful, in a non-physical way. In this sense, the Mice can also be understood as a hint that "something isn't quite right".

*Secrecy / behind the back / insidiousness:* When mice move into one's home they are mostly active at night time, when the house is quiet. Their presence, and the destruction they cause, often stays hidden until a lot of damage has been done. Because of this, the Mice can very well be interpreted as "secrecy". The card may mean that something is going on behind someone's back, or that someone is sneaky about something. In more general terms, the Mice represent anything insidiuous. For example, they can mean the malicious spreading of rumours, or slander. They can represent dishonesty, lies, corruption, and theft.

 **See also** the *annakblogs* article [>> So, is the Mice a negative card, then?](https://annakblogs.wordpress.com/2018/04/03/mice/)

**About the Image:**
 In my illustration of the Mice, a pantry has been infested with mice. These mice are not just nibbling at the provisions in the pantry (a pumpkin, apples, bread, and cheeses etc.) - they have even started to gnaw away at the card's borders! I think this expresses very well that if we don't stop unwholesome goings-on before it is too late we will eventually have *nothing* left we can depend on or draw strength from. In the background there is a cracked window through which yet another mouse is looking/climbing in. The cracked window can be understood as an indication that theft or infestation usually happen because there is some kind of weak spot somewhere.
