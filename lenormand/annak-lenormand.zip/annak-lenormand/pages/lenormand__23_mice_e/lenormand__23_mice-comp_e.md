---
title: "lenormand | mice | comparisons"
source: https://www.annak-tarot.at/lenormand/23_mice-comp_e.html
---

mice

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Mice, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Secrets**

|  |  |
| --- | --- |
|  | **Mice**: Harmful and/or malicious secrecy. Something is being done behind someone's back. Sneakiness. |
|  | **Clouds**: Something is being hidden from view, fogged over - not necessarily with bad intentions, possibly just for self-protections or out of shame. |
|  | **Book**: A "secret" in the sense of esoteric knowledge - not everyone has access to some type of knowledge or information. |
|  | **Key**: The opposite of secretiveness: openness, straightforwardness. Or: to find access to a secret. |
|  | **Birds**: To blab a secret. |

 **Loss**

|  |  |
| --- | --- |
|  | **Mice**: Loss in the sense that something has been taken away, stolen, or that something which was once plenty is now getting less, dwindling away. |
|  | **Coffin**: The experience of a very painful and permanent loss. Something or someone is gone for good. The grief we feel over an ending or loss. End; death. |
|  | **Ship**: Loss in the sense of "someone has left" or "something is absent right now" (but they might return). |
|  | **Whip**: Sudden, painful loss, especially in the sense that someone or something is cut (off). E.g. loss of job, loss of limb, to lose someone through an accident. |

  **Little/Much**

|  |  |
| --- | --- |
|  | **Mice**: Scarcity; loss. Few, less of. Not enough. |
|  | **Fish**: Abundance, accumulation. Lots, enough of. Too many/much. |
