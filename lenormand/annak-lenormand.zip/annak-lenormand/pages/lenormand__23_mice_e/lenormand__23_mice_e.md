---
title: "lenormand | mice | keywords"
source: https://www.annak-tarot.at/lenormand/23_mice_e.html
---

**MICE
23**

**Keywords**

***Nouns / phrases:***

Dwindling, deficiency, depletion. Loss, reduction, atrophy. Shortage,
a lack of something, plight - e.g. poverty, hunger, emotional neglect. Exhaustion.
Decay, spoilage, ruin. Destruction, defect, flaw. Contamination, filth.
Disease, infestation, pest, plague. Something which is unhealthy or unwholesome.
Harm. "Something isn't quite right!" Corruption. Secrecy. Something is
going on behind someone's back. Sneakiness; insidiousness. Rumours, slander.
Dishonesty, lies, theft.

 ***Activities:***

To wane, dwindle. To take away, reduce, lower, lose. To deplete, drain, waste, exhaust.
To go bad, deteriorate, decay. To gnaw, nibble. To destruct, ruin, spoil something. To infest,
infect, attract a disease. To contaminate, foul, pollute, soil. To do something behind someone's
back. To sneak, pry, eavesdrop. To spread rumours, slander, lie, blackmail, steal.

 ***Attributes:***

Scarce, insufficient, poor. Lost, less of, dwindling. Draining, depletive. Stale, bad, deteriorating.
Degenerated, foul. Secretive, secret. Sneaky. Crooked, disingenuous. Unwholesome,
unhealthy, sick, infested,infected, contaminated, virulent. Corrupt, corrupting, dirty. Behind
someone's back.
 **As a person:**  Someone with the above attributes, e.g. someone sneaky, corrupt, exhausted, poor,
sick. Energy vampire; thief. Someone who makes themselves scarce.
 **As advice:**
 Check if you have enough reserves left! Make sure it's still there! Identify your weak
points/soft spots so you can protect yourself! Keep an eye out for dishonesty/corruption!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   At a bad time. Too little time. Time is running out.

 **See also** the *annakblogs* article [>> So, is the Mice a negative card, then?](https://annakblogs.wordpress.com/2018/04/03/mice/)
