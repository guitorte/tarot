---
title: "lenormand | heart | comparisons"
source: https://www.annak-tarot.at/lenormand/24_heart-comp_e.html
---

heart

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Heart, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Relationship**

|  |  |
| --- | --- |
|  | **Heart**: A *loving* relationship - possibly romantic. |
|  | **Ring**: The commitment part of a relationship - *any* type of relationship; could even be a work relationship. |
|  | **Lily**: By itself a purely *physical*, sexual, relationship - could be respectful *or* exploitive. |

 **Positive Emotions**

|  |  |
| --- | --- |
|  | **Heart**: Any positive emotion that is related to love: all types of love itself, kindness, but also tenderness, compassion, forgiveness etc. |
|  | **Bouquet**: Any positive emotion that is related to positive give-and/or-take situations: cordiality, thankfulness, appreciation etc. Also: admiration. |
|  | **Sun**: Any positive emotion that is related to happiness - joy, mirth, ease, having fun etc. |

**Openness**

|  |  |
| --- | --- |
|  | **Heart**: To be open emotionally - to let others touch you emotionally; to be of a gentle, yielding, soft disposition. |
|  | **Key**: To be open in general - open to having new experiences, to trying new things, open to new ideas etc. |

 **See also** the *annakblogs* article [>> What's the difference between the Lenormand card  *Heart* and the Tarot card *The Lovers*?](https://annakblogs.wordpress.com/2018/04/12/whats-the-difference-between-the-lenormand-heart-and-the-tarot-lovers/)
