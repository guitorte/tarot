---
title: "lenormand | book | comparisons"
source: https://www.annak-tarot.at/lenormand/26_book-comp_e.html
---

book

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Book, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Knowledge**

|  |  |
| --- | --- |
|  | **Book**: Factual knowledge; educated. "I know this!" |
|  | **Bear:** Practical knowledge - capable. "I know how to do this!" |
|  | **Snake:** Thirsty for knowledge. "I want to know!" |

 **Secrets**

|  |  |
| --- | --- |
|  | **Book**: A "secret" in the sense of esoteric knowledge - not everyone has access to some type of knowledge or information. |
|  | **Clouds**: Something is being hidden from view, fogged over - not necessarily with bad intentions, possibly just for self-protections or out of shame. |
|  | **Mice**: Harmful and/or malicious secrecy. Something is being done behind someone's back. Sneakiness. |
|  | **Key**: The opposite of secretiveness: openness, straightforwardness. Or: to find access to a secret. |
|  | **Birds**: To blab a secret. |

**Intelligence**

|  |  |
| --- | --- |
|  | **Book**: Intelligent in the sense of well-educated, knowledgeable. |
|  | **Snake**: Diplomatic intelligence, great rhetoric; acumen; ability to direct (even manipulate) others. |
|  | **Fox**: To be street-wise. Cunning; and the intelligence of knowing when to risk something and when not to. |

**Facts vs. information**

|  |  |
| --- | --- |
|  | **Book**: Facts; the truth. |
|  | **Letter**: Information. Some content is being shared, passed on, expressed - while this content could be factual it doesn't have to be; the information shared could be false, too. |

 **Categorisation**

|  |  |
| --- | --- |
|  | **Book**: To categorise something; something *can* be categorised, intellectually understood. |
|  | **Wild Card**:  Something doesn't fit into the usual categories. Something is impossible to understand intellectually because we can't categorise it (yet). |
