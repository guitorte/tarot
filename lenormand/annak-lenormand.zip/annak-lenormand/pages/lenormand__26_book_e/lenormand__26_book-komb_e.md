---
title: "lenormand | book | combinations"
source: https://www.annak-tarot.at/lenormand/26_book-komb_e.html
---

**COMBINATIONS WITH THE
BOOK**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Book-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Academic pressure; scientific news; changes in one's education; new fact(s). To be overwhelmed by the truth; the truth seems "too much" to handle.
Intelligent approach. To be knowledgeable of what is to come. Facts with change things. Change of what's true.

**Book-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Light fiction; literature of little relevance. "Nice to know, but needn't remember" type of knowledge. To study something just for fun, with little seriousness . To not take education (or studying) very seriously. To gamble at an exam. To be easygoing with telling the truth.

**Book-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Travel book; knowledge/facts about foreign places. New studies. To embark on a scientific venture; scientific research. To explore new areas of
knowledge and wisdom. To make a change in one's education. To look for the truth; to follow the facts; to go where the truth leads.
To be out of one's depth. To leave behind the well-known; exploration of the yet unknown. Something departs from the truth. To leave school.

**Book-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Home schooling. Family in which education is very important. Facts about a family (home); family history. Knowledgeable family member. Knowledge about tradition(s). To know the rules. Something only family members know. Private knowledge. Established facts. Familiar truth. To want to know only the "safe", comfortable facts - facts which do not require us to change.

**Book-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
An actual, physical book. To study nature; medicine study; other health related trainings. Knowledge about health, or about one's body in general. To be very confident about one's intelligence. Solid, down-to-earth education. The truth about one's roots. To study diligently, patiently. Healthy way to study / learn.

**Book-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Hidden facts; unclear facts; veiled truth. To hide the truth. Lies, misunderstandings, mistakes, errors, false teachings. Confusing facts; to not understand what one is being taught. Learning disabilities. Despair during a learning process; to feel unguided during a learning process. No teacher - one has to learn from/by oneself. Boring studies. Disinterest in a subject; indifference towards the truth.

**Book-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Academic career. Very strong academic ambitions, to crave knowledge; to do everything to find out what's true. To study diligently. To believe in one's intelligence. A teacher/professor. Pretend intelligence; to feign knowledge. Manipulation of facts.

**Book-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
End of an education (not necessarily premature!). Grief caused by learning a painful truth. To accept that truth might never be found. Facts about an ending, about a death, a loss. History. To give up one's yearning for better education. One's intellect isn't utilised.

**Book-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To share knowledge; to be invited in on a secret. Praise of knowledge, praise of one's study efforts. To study interior design or other trainings which have to do with beauty, design, fashion. Facts or knowledge about beauty/design/fashion. The truth behind the flattery. To categorise something as compliments, pretty, pleasant, flattery etc.

**Book-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Knowledge about danger and risk. Painful truth; to be hurt by the truth. To learn something suddenly or unexpectedly. To take stock of what one knows. Final exam. Education or learning process is interrupted / ends prematurely.

**Book-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To (mis)use (not necessarily but possibly secret or confidential) knowledge as a weapon to win a discussion or to harm someone. Knowledge about something or someone abusive. Abuse which only few people know about. To learn about something or someone abusive. To keep knowledge of a conflict to oneself. To judge others (harshly) by their level of education. To be ashamed for one's own low education.

**Book-Birds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)**
To be worried about the truth. Disorganised way of studying;
chaotic learning environment. To jump from one fact to the other. Inattention to the facts. To clutter one's head with too much (unnecessary) knowledge. Or: to be a quick study; to learn easily. Short term memory.

**Book-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
(Young) student; lack of knowledge. Very little facts. To know things about child rearing; fact(s) about a child. Curious person; curiosity. Someone who wants to learn. New knowledge; to start an education. To be too easily convinced by an apparent truth.

**Book-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Self-knowledge; self-awareness. To be self-taught; to educate oneself. Facts about oneself; to be true to oneself or about oneself. Knowledge of who somebody really is. A profound factual and scientific
knowledge about identity and integrity. Distrust in education or
science. To stick with an education even when it's hard work. To put something into the category "egoistic" (possibly wrongly). To classify something as "self-care".

**Book-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Teacher, professor. Intellectualism or academic endeavours have dominate querent's life. To combine theoretical and practical
knowledge (or: a conflict between the two!). Powerful knowledge/truth. To protect a secret. To not let others know / someone doesn't let querent know. To boast about one's knowledge/education. To be cowed by someone's education.

**Book-Stars[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Astrology (and the questionable trust in it); astronomy. An (unfulfilled) wish for education or knowledge or truth. To dare tackle difficult, complicated, or esoteric, fields of knowledge. The dry facts behind spiritual ideas. To study spirituality in general or a specific spiritual system. To trust that eventually "the truth will out".

**Book-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)](https://www.annak-tarot.at/lenormand/16_stars_e.html)**
The transformative power of education or of understanding the truth about something. A very long, slow learning process. What is true changes slowly. An inner truth. It's inevitable that the facts will come to light. Knowledge about a transition. The truth about a transition. Hungry for knowledge; to long for better education or intellectual stimulation. Someone is intellectual by nature. You already know that - you had just forgotten that you do! Very slow acceptance of the facts. Really understanding something takes time! The truth sinks in slowly.

**Book-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
An educated friend. Facts about a friend. To know everything about a friend or to let a friend know the truth about oneself. To admire education. To follow where the facts lead you.
To uncritically believe everything just because it's written down or presented as factual. Support of a learning process, of someone's education. Something or someone who helps with learning something. Private teaching. A mind which is easily lead. To follow someone's thinking process. To ask for the truth. Loyalty to the truth.

**Book-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Ivory tower. Educational institutions. A person who has intellectual or academic authority. Standard works which serve as authorities. To withdraw from an academic project; to retreat in order to study. The depth of one's knowledge also makes one lonely. Knowing certain facts makes one feel isolated from the people who are unaware. Pride in one's erudition. Extreme intellectual elitism.

**Book-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Newspapers, news
channels - venues which make facts public. Public knowledge. Public libraries, internet. Knowledge about networking and social structures. Society's intellectual elite. Social/cultural sciences. To present oneself as an intellectual; to broadcast one's knowledgeableness or good education. To proclaim something as public knowledge - as facts everybody should have access to.

**Book-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
A fact/truth which is problematic or which challenges you. Education on something is very hard to obtain. Learning difficulties. To be kept away from education. An obstacle in a learning process. To to be left in the dark about something. To keep quiet about something; to refuse to tell the truth or share knowledge. To be unmoved by the facts and stubbornly hold true what you *want* to believe. An obstacle yet to be discovered. Lack of knowledge is an obstacle. Facts about mountains. To classify something as difficult or problematic.

**Book-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Knowledge and education open up new paths; give us more options. Intellectual potential. To tread water in regard to our education. Knowledge of the facts is necessary for making a good choice. A choice or decision about one's education. To be knowledgeable about many different things. That part of the truth which is relative, subjective. Relativism. Ambiguous facts. To be ambivalent about the truth. A different perspective on the truth; to look at the facts from a different angle. To diverge from the truth.

**Book-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Lack of knowledge; to little knowledge. Little or bad education. Lies, misinformation. Corrupt/manipulative presentation of facts. Facts about illness, or pollution. To study illness, pollution, corruption. It's true that there's corruption. To study so hard that it is draining one's energy. To classify something as bad / unhealthy / dirty / corrupt etc.

**Book-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
A conflict between thinking and feeling. To have (or collect) facts or theoretical information about love, compassion, a loving relationship etc. To keep one's affections/tenderness to oneself.
A good understanding of someone's positive affections. Loving understanding; to accept something/someone because or even when one knows them intimately, including their faults. To know someone (or something) "by heart".

**Book-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Knowledge about cause and effect, or about where and how things link, connect. Facts about a relationship; the truth about commitment. Facts about a contract. To be committed to truth, to science, to learning about something. To commit to education. Academic connections. Sorority, fraternity, peerage. Dependably true; dependable education. Shared knowledge. Shared education.

**Book-Book[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To learn the truth. Something which is very definitely true. To study pedagogics. Facts about learning; facts about the educational system. The truth about one's intellect, about one's intelligence. To classify something as true.

**Book-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To speak the truth. To pass on knowledge; to share information. To communicate only with people who are part of an "esoteric" circle. Academic/scientific conversation; intellectual discussions. Expressions of education/literacy. Information about education; conversation about education. Knowledge about communication. Communication science.

**Book-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Man who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a man; facts about a man. To get to know a man. To tell the truth to a man or about a man. To categorise someone as male / masculine.

**Book-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Woman who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a woman; facts about a woman. To get to know a woman. To tell the truth to a woman or about a woman. To categorise someone as female / feminine.

**Book-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Man who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a man; facts about a man. To get to know a man. To tell the truth to a man or about a man. To categorise someone as male / masculine.

**Book-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Woman who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a woman; facts about a woman. To get to know a woman. To tell the truth to a woman or about a woman. To categorise someone as female / feminine.

**Book-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Passion about a certain subject area; an expert in a certain subject area. Very long, slow learning process or education. Conflict
between enjoying sensual pleasures and processing the experience intellectually. High quality literature. Books about sex or with sex in them. Esoteric sexual practises. Facts about sex; knowledge about sex; to be knowledgeable or in need of education about sex. An overly intellectual approach to sensual pleasures (to be stuck in the head). To (slowly?) get to know a lover; or to get to know *someone* intimately. Intimate knowledge.

**Book-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
(Theoretical) knowledge about virtue. An education in morality. Pure, honest, undisguised facts. The virtue of truthfulness; to share knowledge when it is the right thing to do. To be at peace with the truth. A virtuous teacher. A role-model for virtuousness. To "come clean" about something. A very, very non-physical, non-sensual, intellectual approach.

**Book-Sun[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Positive facts; the truth makes one happy. Feel-good literature. Academic success; popularity as teacher. Charismatic scientist/professor. To broadcast one's knowledge; to seem knowledgable to others. To study during daytime. A celebration to do with one's education. To find great joy in intellectual pursuits. An obvious truth. To prove the truth. To show the truth. Something which seems true on the surface only, at first glance. To categorise something (or someone) as obvious, superficial, bright, happy, charismatic etc.

**Book-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)**
Sad facts. Profound truth. Psychology; to learn about the unconscious. Literature with a lot of depth. To study at night time. Knowledge about fears and needs. Hearing the truth results in emotional upheaval; confrontation with reality triggers fears. Rest from studying. To read books to rest. Reading before sleeping. A conflict between intellect and emotion. In-depth studies.

**Book-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To figure out the truth; to find access to knowledge (or education). Education or understanding something opens up new ways of seeing things. The key to understanding. The solution lies in educating yourself. Open-mindedness helps seeing the truth. To be open to learn. To actually *understand* - not just learn it by heart so you can parrot it. To integrate (new) facts into one's knowledge. Unrestricted facts. Learning aid.

**Book-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Wealth of knowledge; lots of facts (but maybe not that important); to desperately want to have the facts. Education in the financial field. To seek education for financial gain. Expensive education - maybe: gaining this knowledge will cost you. To categorise something as valuable.

**Book-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To find great safety in knowing the truth. To hold on to what's true even if it costs. To be bound to someone who one shares a certain knowledge with. To focus on one's studies. To focus on the truth. Education brings stability/safety. Everything revolves around the intellect, about intellectual pursuits. To categorise something as safe / stable.

**Book-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
Religious or ideological writings. The actual facts behind the religious dogma. Knowledge which burdens. The truth is hard to bear. To study religion. Studying is burdensome or exhausting. It's one's duty to be knowledgeable. To categorise something as dogmatic, fateful, burdensome, painful etc.

**Book - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)**
To wonder about the truth; to question the facts. Question mark regarding our education. To (vainly) try and categorise something which just cannot be put into a specific category. To learn about what the unknown factors regarding our concern are. Conflict between thinking outside the box (Wild Card) and thinking inside the box (Book). Only some people have the knowledge that there are open questions still.
A (possibly genderqueer) person with the attributes of the Book (see the Book's keywords).
