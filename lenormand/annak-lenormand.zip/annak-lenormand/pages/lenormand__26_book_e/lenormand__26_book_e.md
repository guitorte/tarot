---
title: "lenormand | book | keywords"
source: https://www.annak-tarot.at/lenormand/26_book_e.html
---

**BOOK 26**

**Keywords**

***Nouns / phrases:***

Facts, truth. Knowledge, learning, study. Education, advanced
training, educational institutions - school, college, university, academics, science.
Intelligence in the sense of knowledge, book learning, erudition. Intellect,
intellectualism. Category, class. Categorisation, filing. Stereotyped thinking,
pigeonholing, inability to think outside the box. Something known. Something
unknown, but waiting to be known. Esoteric teachings/knowledge. Traditionally
also: secret.

 ***Activities:***

To know. To tell the truth. To learn, study, educate (oneself), teach. To categorise,
class(ify), pigeonhole. To think inside the box, to think in a stereotyped way, to pigeonhole.

 ***Attributes:***

Factual, true. Intelligent, knowledgeable, educated. Academic, scientific. In the know;
known. Intellectual. Classified in the sense of filed (away) into a category; categorical - in the
sense of stereotypical, pigeonholed. Esoteric, as-yet-unknown, yet-to-be-learned/understood.
 **As a person:**  Well-educated, intellectual person; person who is inclined to pigeonhole, think inside
the box. Depending on the question asked and on surrounding cards: teacher, professor, student.
 **As advice:**
 Study! Educate yourself! Find out the truth, accept the facts! Negatively: Don't forget
about your physical/emotional needs! Don't be a know-it-all! Think outside the box!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When we have learned the relevant facts. You('ll) know when!

 **See also** the *annakblogs* article [>> So, is the Book a positive or a negative card?](https://annakblogs.wordpress.com/2018/04/24/book/)
