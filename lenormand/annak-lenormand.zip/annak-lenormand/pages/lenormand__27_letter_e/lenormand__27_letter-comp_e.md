---
title: "lenormand | letter | comparisons"
source: https://www.annak-tarot.at/lenormand/27_letter-comp_e.html
---

letter

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Letter, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Type of communication**

|  |  |
| --- | --- |
|  | **Letter**:  Communication in any form, and its manifold manifestations. Communication with quite a bit of depth and/or content. |
|  | **Birds**: Communication in the form of idle chit-chat, gossip, or oversharing. Quick, short, (and often unnecessary,) communication like text messages, or twitter. |

 **Communication vs. no communication**

|  |  |
| --- | --- |
|  | **Letter**: To communicate; to express things; shared information. |
|  | **Mountain**: To be silent; things unspoken; the elephant in the room. |

**Information / facts**

|  |  |
| --- | --- |
|  | **Letter**: Information. Some content is being shared, passed on, expressed - while this content could be factual it doesn't have to be; the information shared could be false, too. |
|  | **Book**: Facts; the truth. |
