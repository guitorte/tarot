---
title: "lenormand | letter | combinations"
source: https://www.annak-tarot.at/lenormand/27_letter-komb_e.html
---

**COMBINATIONS WITH THE
LETTER**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Letter-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Person who delivers a message; brings news; someone comes to you for a conversation. A conversation or information which will change things. News report. To communicate openly about how you feel about news/changes/someone's advances. Surprising information; to be blindsided by an unexpected conversation. To be unprepared for a conversation.

**Letter-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Some light, untroubled, and/or unimportant conversation. The opportunity to talk about something. To take a risk with a certain communication. Communicating more will open up opportunities. To communicate about an opportunity. To communicate one's wish to have fewer responsibilities. To take communication (in a relationship?) not seriously enough. A communication that is short-lived.

**Letter-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
To make inquiries; to go looking for information. Long distance communication. Communication about a change one would like to make; or, communication would cause change! Communication with someone who is absent. To express one's wanderlust. To inform someone about one's inability or unwillingness to settle down. Someone expresses (possibly not verbally, though!) their inability to settle down. Communicating/expressing ourselves is new to us, and scary.
Travel documents; to book a journey.

**Letter-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversations about family matters; things that should be expressed concerning family. Family where there's a lot of communication; or: family who needs to communicate more. A letter home; to have conversations with one's parents or siblings.
Documents concerning a house / one's home. (To set up) rules for communication. To meticulously plan a conversation. Familiar conversations; conversations you've had forever but nothing new ever comes from them. Conversation about familiar topics - boring conversations?

**Letter-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversations about nature or about one's body. Information about health; health report. Bodily forms of communication - to communicate through gestures, through touch. communication which is long-lasting, full of content, very "alive". Calm, unstressed conversations; Mediator. To talk about one's ancestors, one's roots (or: to share or receive/ask for information about them).

**Letter-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Unclear or confused communication; lies - especially: to lie by omission. Unclear statements. Misunderstandings in general; to misunderstand a specific bit of information; to misunderstand what someone is trying to say. To not know what to say. Conversation with lack of focus; conversation with no clear purpose; conversation without guidelines. Boring conversation. Disinterest in the information we are given. To express one's hopelessness, or confusion. To not follow a conversation.

**Letter-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication with a very specific aim; to say out loud what you crave; to communicate your desires. To make demands. Documents concerning your career; e.g. a CV. A very tactful or diplomatic conversation. To manipulate others with rhetorical tricks. To not let go of a certain topic until everything is said.

**Letter-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Farewell letter. To communicate one's wish to end something; e.g. a relationship, a job. Communication has died down. Words left unsaid. A suppressed need to talk about something.
Letter of sympathy. To tell others about one's grief. Suicide note.

**Letter-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Letter of congratulation; to pay compliments; flattery. To invite or to get invited. To let someone know they are welcome. To express gratitude/appreciation. Communication in one's circle of friends - possibly communication on Facebook if it's not public to all. To mince one's words; to say something in a roundabout way; to beat around the bush. To express oneself only in nice ways other people appreciate (whether this fulfils one's own needs or not). Styling which expresses something, which is supposed to deliver some information (e.g. about one's availability, or class).

**Letter-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
To stop communicating. To cut someone's word off; to get interrupted. Interrupted communication. A conversation which ends prematurely. Extremely to the point (even harsh, curt) conversation. To not beat about the bush but make things very clear ("tidy"). To wrap up an argument. To sum things up (for someone else); to state clearly what's what. To inform someone about a conclusion one has made / to be informed about a final result. Letter of resignation, final exam, divorce papers, suicide note.

**Letter-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication about a conflict. Debates, discussions, verbal conflicts. Conflicting information. To let someone know when they have displeased you or when you feel that you're being mistreated. Aggressive communication; to say sarcastic or cynic things to others. Insults. Verbal or non-verbal expressions of shame/guilt. To say sorry; to ask how one can make amends.

**Letter-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)**
Hectic, stressed conversation; to have little time or no patience for proper, in-depth communication. Chit-chat, gossip. To communicate with quick ease; to respond quickly to emails/letters/conversations. To respond quickly when someone expresses something important. Worries about a conversation. To express one's worries. To have several conversations at the same time; to try and express multiple issues at the same time.

**Letter-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Tentative communication; to inch one's way forward with a certain topic of conversation. Inexperience with communication. To start a conversation; communication grows. An "innocent" (naive?) conversation - maybe one is unaware that picking up a certain topic might open a can of worms. To be curious about the other person's view. Documents concerning a child; communication with a child. To express one's childish side; or to express one's vulnerability. To let someone know that one is inexperienced (and in need of guidance?).

**Letter-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication/conversation which is in one's self-interest. To be wary of a certain information or conversation. To proceed cautiously in a communication process. An email or document one doesn't trust. Expressions of distrust/suspicion; expressions of egotism. Cunning ways of communicating (in order to get what one needs). Someone communicates in a manipulative way. To communicate what one needs.

**Letter-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication with or about teacher, parent, or boss; or about power dynamics, or provision. Someone dominates the conversation; the topic that dominates the conversation. Documents concerning insurance, (last) will, living testament. Information about teacher/parent/boss. Powerful information; information that gives power to those who have it. To express one's power/authority; expression of anger.

**Letter-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation about dreams and hopes. Email/letter/conversation one is yearning to receive/write/have. To wish one could communicate better, or that someone else would. To feel in touch with the transcendental. To communicate with the transcendental. Prayer. To communicate full of hope for a good outcome; to let others know something, hoping for a certain reaction. Expressions of hope/faith.

**Letter-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)](https://www.annak-tarot.at/lenormand/16_stars_e.html)**
Conversations you have again and again. To come back to a conversation you had earlier. Inevitable conversation. Transformative communication. Communication is
transforming. Slow change of conversation topic. Conversation about our longings. To long for meaningful conversations. To communicate that we have had a change of mind. Ways to express an inner transformation. Documents that confirm/allow a transition or relocation, e.g.
visa, plane ticket, wedding certificate, birth certificate etc.

**Letter-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation with a friend. To express friendship, loyalty, or devotion. Non-verbal expressions of dependence. To tell someone what to do / to ask someone what to do. Orders; or to give or receive permission. Unequal conversation. To communicate support; non-verbal expressions of support. To follow a conversation. To always agree with what other people say.

**Letter-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Cool, unemotional, clear communication. Philosophical, academic conversations; scientific or official documents. To let others know that one feels lonely - or is in need of solitude. Communication helps out of isolation. To monologize. To communicate in ways that are difficult for others to understand. Communication about issues of independence/authority.
To communicate clearly that one doesn't want something; to make clear what the boundaries are. Expressions of pride; expressions of arrogance.

**Letter-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Public communication (e.g. in the media);
meetings in public places; to write a letter to the editor; networking. To communicate with an audience. Conversations about societal issues. To say something out loud - so everyone can hear. To make something public. To express something very clearly (visibly/audibly etc.) and without restraint.

**Letter-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Difficulties with communicating, or difficult/challenging conversation. Problematic ways or means of communication. An obstacle to communication. Telling silence. Silence that (should) tell you something.
Something you just can't talk about. To finally speak about the elephant in the room. Conflict between wanting to talk about something and feeling you should keep silent about it. To address a problem. To have difficulties addressing something.

**Letter-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication about a choice; to inform others of a decision / to be informed about a decision or a choice. To decide to communicate about something / to express something. "It's your choice what you share with others." The choice whether to communicate something or not - or a choice about *what* to communicate. Expressions of freedom. Expressions of indecision.

**Letter-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation behind someone's back; blackmailing, blackmail. Communication which is damaging. Lies; misinformation; false testimony. Nagging;
complaints. Exhausting conversations. Lack of communication. To communicate dislike. Expressions of disgust. To inform others about corruption / things that go wrong. To tell on someone. Whistle-blowing. Conversations about what is missing.

**Letter-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Love letter; affectionate communication in general. To communicate with empathy and understanding, to communicate with the aim of making the other person feel accepted or even loved. Expressions of love or compassion. To communicate with a loved one. To let someone know one loves them (or the other way around).

**Letter-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Contract. To promise someone something, formal commitment ritual (e.g. wedding ceremony).
Communication about a relationship, conversation about a connection. It's time to talk about commitment! To express commitment. Communication is the basis for a relationship. To talk and talk and talk about something but never actually do anything. Shared information. To talk about commonalities. People who communicate form a cohesive group (e.g. but not necessarily a formal alliance). To actively reach out in order to make connections.

**Letter-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
To speak the truth. To pass on knowledge; to share information. To communicate only with people who are part of an "esoteric" circle. Academic/scientific conversation; intellectual discussions. Expressions of education/literacy. Information about education; conversation about education. Knowledge about communication. Communication science.

**Letter-Letter[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication is very important now - not necessarily about a specific issue but it's important to keep communicating. To have a conversation about communication. Conversation about information. To express oneself eloquently. Expressive communication. To use every means of communication available to get something across.

**Letter-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Man who is: communicative, likes to share what he thinks/feels/knows. Man with expressive gestures or facial expressions.
Communication with a man; conversation with a man or about a man. Expressions of manhood.
Postman, host of radio show, mediator,
speaker, pen pal.

**Letter-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Woman who is: communicative, likes to share what she
thinks/feels/knows. Woman with expressive gestures or facial expressions.
Communication with a woman; conversation with a woman or about a woman. Expressions of womanhood.
Postwoman, host of radio show, mediator, speaker, pen pal.

**Letter-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)**
Man who is: communicative, likes to share what he thinks/feels/knows. Man with expressive gestures or facial expressions.
Communication with a man; conversation with a man or about a man. Expressions of manhood.
Postman, host of radio show, mediator,
speaker, pen pal.

**Letter-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Woman who is: communicative, likes to share what she
thinks/feels/knows. Woman with expressive gestures or facial expressions.
Communication with a woman; conversation with a woman or about a woman. Expressions of womanhood.
Postwoman, host of radio show, mediator, speaker, pen pal.

**Letter-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Passionate conversation; high quality communication. Slow communication process; to take time for a conversation. Communication through visual stimulation, smell, touch, sound etc. Communication about sexual issues. To be so passionate about something that one needs to talk about it a lot. To communicate through artistic means. Conversation about the arts.

**Letter-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Virtues important for communication: e.g. the willingness to listen, honesty. An honest conversation. Communication with the intent of making things better (for everyone concerned). Peace talks. To communicate peacefully, without aggression, no hateful remarks. Non-violent communication. To communicate one's honest, true intention. "Clean" communication - no false pretences or manipulation in one's communication.

**Letter-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation about positive issues. Optimism concerning a conversation. To share joy; report of a positive event. Information about a celebration. Expressions of joy. Conversations which lack depth. To communicate what makes one happy. Communication makes things better. Joyful, warm ways of communicating. Conversations during daytime. Communication works better when one is wide awake. To communicate something very clearly. A very obvious expression of something.

**Letter-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)**
Emotional conversation. A fear of expressing something. Need to talk. To express what we feel. Expressions of fear or sadness. Communication with our subconscious. Unconscious signals; to communicate intuitively. Conversations with a lot of depth. Obscure information. To let other's know we are tired. Nightly conversations. Dreams are telling us something. Lull in conversation. A respite from a conversation.

**Letter-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Communication is the key. To open
up conversation. An open conversation. To not hold anything back. To allow yourself to say something out loud. To share information; or someone lets you in on a secret. The solution can be found through discussing things openly. Brainstorming with others. Information about a solution. To receive a "yes" from someone or to tell someone "yes". To agree to have a conversation. Open-minded communication. Willingness to accept what others say. To understand what someone is trying to say - or to be understood.

**Letter-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation through which one wants to gain something. To profit greatly from (good) communication. To value communication. Financial/business documents; bills. Lots of conversation but the quality maybe isn't that great. Jobs for which communication skills are important. To work on one's communication skills. Too much information. To overshare. Expressions of greed.

**Letter-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Steady flow of communication. Communication is the focus in one's life. Everything revolves around a certain information or conversation. A conversation has reached its conclusion and now there is nothing new to say (time to move on / time to act?). Conversation about the status quo. Conversation about what is most important. Restricted conversation; communication is stalled. Expressions of feeling safe / of feeling trapped.

**Letter-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Indoctrination. To communicate because one thinks it's a duty. Hard conversations; conversation about a painful issue. The responsibility to inform others about relevant issues. Communication is very hard; to feel the pressure to talk about something although you don't want to. Communication about ideology, dogmata, responsibilities, duties, pressure, or suffering. To communicate when things become too much to handle. Expressions of suffering and pain.

**Letter - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)**
Conversation about an open question. The express oneself clearly when there are still questions open. Someone expresses themselves in a way that is unusual, or hard to understand. Communication which is not clear-cut. Something hasn't been communicated yet. Communication about something that is hard to express. To try and communicate with someone who puts on a poker face. Communication about genderqueerness. Non-verbal expressions of genderqueerness.
A (possibly genderqueer) person with the attributes of the Letter (see the Letter's keywords).
