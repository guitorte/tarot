---
title: "lenormand | letter | keywords"
source: https://www.annak-tarot.at/lenormand/27_letter_e.html
---

**LETTER 27**

**Keywords**

***Nouns / phrases:***

Communication in general, in all its forms: face-to-face or
through a medium; written, verbal, non-verbal. Document, letter, email, a speech;
facial expressions and gestures. Conversations, especially ones that take time
and effort. Information. Expression. Something is, or should be, expressed. Traditionally,
written communication (letters, documents etc.) or at least not face-toface
communication only!

 ***Activities:***

To communicate. To write, talk, gesture, converse. To inform, to share
information, to report. To relate or express something.

 ***Attributes:***

Written, spoken, communicated. Communicative, talkative, expressive, eloquent, telling,
informative.
 **As a person:**  Someone who is communicative or who you communicate with a lot. Pen pal. Someone
whose profession contains a lot of communication, such as the host of a radio show, a
mediator, a speaker. Informant, whistle-blower.
 **As advice:**
 Don't keep it to yourself! Communicate about it! Inform others!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   You'll be informed when. When you get the relevant information.

 **See also** the *annakblogs* article [>> So, is the Letter a positive or a negative card?](https://annakblogs.wordpress.com/2018/05/01/letter/)
