---
title: "lenormand | man (b) | combinations"
source: https://www.annak-tarot.at/lenormand/28_man2-komb_e.html
---

**COMBINATIONS WITH THE
MAN *(b)***

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Man-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A man brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a man; to beset or harass a man. Attempts to change a man. A traditionally "male" approach.

**Man-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: a lucky devil; happy-go-lucky, easygoing, not-serious; joking, humorous, playful, unimportant, irrelevant. Irresponsible, unburdened, has no responsibilities, doesn't do his bit; a gambler or risk-taker. To chance something regarding a man; to take a man (or men in general) not seriously. To toy with a man / man who toys with us. To joke/fool around with a man. To keep it light with a man.

**Man-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is absent, missing, gone away, very distant, travelling, not there yet, on the way, (ad)venturous, yet to be learned to know, exploring, seeking, searching, full of wanderlust; fidgety, ready to leave, not committed.
To leave a man; to look for a man; to explore a man (or manhood).
A man makes changes. An explorer, a traveller, a foreigner.

**Man-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: native, at home, at home with something, a family member, well-established, settled, private, familiar, used to or intimate with you; close-minded regarding anything which is new/unfamiliar, xenophobic, orderly, normal, regular, simple, planning ahead, low-risk, safe, conservative, inflexible, anti-innovative.
Male family member; a creature of habit, stay-at-home dad.
Man moves in, starts a family, settles with something, keeps something private, wants things to stay as they are. Patriot. Family man. A man's privacy. (Traditional) rules or roles which apply to men specifically.

**Man-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: natural, physical, alive, thriving, deeply rooted, grounded, belonging, steadfast, robust, inflexible in the sense of not versatile, down-to-earth, pragmatic.
A male ancestor. To grow into manhood. Healer. Male body, or traditionally "masculine" physique. Male-specific health issues. Man does something in nature; man who is close to nature, does something physical.

**Man-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: confused, insecure, desperate, lost. A shady character, man who is hiding something, putting up a smoke-screen. Deceiver. Man in need of guidance. Man who lacks interest (or who lacks interesting characteristics), is listless. Deadhead. A man the querent can't see / doesn't see as who he really is.

**Man-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality man, lawyer, politician, diplomat. A man goes his own way. An affair with a man. To feel attracted to, seduce, manipulate, or coerce, a man.

**Man-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who has died. Man who's suffered loss; man who hasn't let go of something (or, a man who is in the process of letting go). Widower. Man who is suppressing a lot or buried his dreams. To let go of a man; grief over the loss of a man. To suppress the man inside ourselves. To not allow a man to live life to the fullest.

**Man-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: invited; on a visit, convivial, sociable; socially active. Man who is affable, well-mannered. Man who is appreciated by the querent, or generally praiseworthy. Man who is flirtatious, or ingratiating. Bootlicker. Handsome man; groomed man. A peacock. Man who tends to exaggerate or whitewash things. A welcome visitor, a host. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a man; to flatter or flirt with a man or men in general. To visit a man; give a present to a man.

**Man-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: efficient, blunt, does unexpected or hurtful things. Man who has cut you off. A male ex-partner. Divorcee. To cut off or hurt a man. Man reaps what he has sown. To get what you deserve from a man. To tie up lose ends or settle scores with a man. Man cleans up. Man with a sharp tongue /who can hurt you.

**Man-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: a cynic, snarky, judgemental - or ashamed; guilty. Prosecutor, lawyer, judge, police officer. To criticise, insult, shame, or abuse, a man. Man who beats himself up about something. Aggressive man, abuser. Misandry. To feel ashamed for being a man. Argument with a man. Man is guilty; man makes amends.

**Man-Birds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: excited, exhilarated, agitated, (over)stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Man who is talkative, gossipy. Man who is brooding, worried, anxious. Man with obsessive-compulsive disorder. Man who is fidgety, restless, fickle, chaotic, unorganised, distracted. Man who distracts, annoys. Man who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile man.
Man with ADHD, multitasker, blabbermouth. Man difficult to assess or who it would be unwise to rely on because he is so fickle. To bother a man; gossip or worries about a man; to distract or talk over (and not listen to) a man.

**Man-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Boy, (grand)son. Father of a child. A man who wants a child. Man who is: Childlike, infantile, delicate, cute, weak, sensitive, vulnerable, defenceless, non-threatening young (at heart), new, innovative, inquisitive, playful, inexperienced, in need of guidance, guileless, innocent, naive, gullible, immature. To belittle a man or men in general. Man takes the first step. To want the man to initiate. It's a baby boy!

**Man-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is cautious, streetwise, maybe overly suspicious or defensive. Man who looks after himself well, or is selfish or follows his own agenda. Man with a lot of integrity. Man whose character is difficult to assess since he seems to change constantly, depending on his surroundings. Trickster. To identify with the male gender.

**Man-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)**
Father or father figure. Male boss, leader, teacher, protector. Man who is: strong, dominant, protective, choleric, bossy, possessive, competent, wealthy. Possibly: To protect a male person; to make a big show of one's masculinity; appearing masculine (or male) dominates life. Depending on context: to protect oneself or someone else against a man.

**Man-Stars[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: hopeful, trusting, spiritual; or has a lot of unfulfilled wishes. Man who aspires to something, who dares to reach for the stars. Daydreamer / daydreams about a man. Man in the querent's future. To idealise a man or men in general. To have faith in a man without good reason, or to have trust in a man (with good reason).
Man we feel deeply connected with.

**Man-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: a migrant, relocating, transitioning, transforming, returning, full of longing. Man who acts instinctively, follows his inner nature. A man by (inner) nature. To long for or reconnect with a man. Something inevitable concerning a man.

**Man-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: a friend, an employee, a follower, helpmate. Man who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for himself. To befriend a man. To ask a man for permission. To do what a man (or men in general) say; to crave the approval of a man or men in general.

**Man-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man in a top position, e.g. boss. Man who is denying, forbidding, solitary, emotionally distant, lonely, isolated, aloof, disciplined, clear-headed, independent, on top, leading, the best, proud, snotty, arrogant, controlling, authoritarian, in power. Segregation of men. Male authority. Single parent, widower. Authority over a man; to lord it over men. Man who has authority over the querent. A male expert. Organisations run by or for men. Patriarchy. To think about a man rationally. Man who rises above.

**Man-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
A man is exposed. Man who exposes, reveals something. Man who goes along with the mainstream, with what's commonly accepted. Men's collective, men's union. To show up a men.
Men with no sense of privacy. Men who is in the public eye (e.g. politician); men who networks, men for whom public opinion and/or his reputation is very important. To present as male. To meet a man in public. Men in society. Male-dominated (sub)culture.

**Man-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Male nemesis or contender. Problems with masculinity. Difficulties/challenges specific to men. To challenge a man. To have problems with a man or men in general. To hinder a man. A man gives us the silent treatment (or the other way around).

**Man-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: one of two or more potential partners / male friends / fathers etc. Man who is confronted with an important decision. Man who is hesitant, indecisive, in two minds, tarrying, ambivalent about something, tolerant. To deliberate or speculate about a man. Decision about a man. Man who is difficult to assess because he keeps changing directions. Man with many faces.

**Man-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: poor, lost, losing weight, bad, deteriorating, degenerated, secretive, covert, sneaky, crooked, unfrank, disingenuous, unwholesome, unhealthy, sick, infected, corrupt, corrupting, dirty, doing things behind someone's back. Man who is faced with theft, corruption, or exploitation - or one who's the perpetrator. Thief. Man who is exhausted or getting weaker. Man who isn't good for us. To badmouth a man or men in general. To spy on a man; to do something behind a man's back. Energy vampire; man who sucks you dry.

**Man-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: a romantic, in love, infatuated. Man who is loving, affectionate, tender, gentle, sweet-tempered, soft-hearted. Man who mollycoddles others. Man who is good at heart, compassionate, caring, altruistic, charitable, magnanimous, merciful, selfless. Man who is forgiving. Man who is involved with all his heart. Male lover. Man who the querent is in love with. To love a man; to care for a man, to give solace to a man. To forgive a man. To mollycoddle a man.

**Man-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: committed, well-connected, bound by something or who the querent is bound to. Man the querent is in some sort of relationship with, e.g. lover, spouse, business partner. Man we have something in common with. Male bonding. Promise from a man, or to a man. Man who is dependable, or (annoyingly) predictable.

**Man-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a man; facts about a man. To get to know a man. To tell the truth to a man or about a man. To categorise someone as male / masculine.

**Man-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: communicative, likes to share what he thinks/feels/knows. Man with expressive gestures or facial expressions.
Communication with a man; conversation with a man or about a man. Expressions of manhood.
Postman, host of radio show, mediator,
speaker, pen pal.

**Man(b)-Man(a)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
A male person is very relevant to the male querent's concern! Two men do something together. There's a very close relationship between two men. A man and his friend, boyfriend, or husband. In this case: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. If you wish you can view the fact that they are looking away from each other as a sign they will soon drift apart (if they don't find things to share). Possibly: The male querent's ideas about what men are (or should be) like influence his situation (e.g. his decisions, or how he views himself) tremendously. A traditionally masculine man; a man does traditionally "male" things.

**Man(b)-Woman(a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
A man and a woman do something together. There's a close relationship between a man and a woman. A man and his friend, girlfriend, or wife. In this case: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. Also: a man shows characteristics viewed as "feminine" by the querent (or society). A man does traditionally "female" things.

**Man(b)-Man(b): [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Everything hinges on the person the Man represents. A male person is very relevant to the querent's concern! Possibly: The male querent's ideas about what men are (or should be) like influence his situation (e.g. his decisions, or how he views himself) tremendously / the female querent's ideas about what men are (or should be) like influence her situation (e.g. her relationship with her spouse, or how she treats men in general).

**Man(b)-Woman(b)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
A man and a woman do something together. Husband and wife, boyfriend and girlfriend. There's a close relationship between a man and a woman. Possibly: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. If you wish you can view the fact that they are looking away from each other as a sign they will soon drift apart (if they don't find things to share). Also: a man shows characteristics viewed as "feminine" by the querent (or society). A man does traditionally "female" things.

**Man-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: sensual, sexually active, passionate, enticing, attractive, artistic, talented, creative, intense, contented, comfortable, peaceful, mature, , self-indulgent, lazy, gluttonous, drunk, high, excessive. Man who enjoys the arts; artist (poet, dancer, musician, painter...); man only interested in sensual/sexual pleasure. Man who takes his time. Or: a lover (real or prospective or dreamed of). To go slowly with, caress, or pleasure, a man. Poetry or music or paintings by or about a man or men in general.

**Man-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: virtuous (in general, or specifically e.g. prudent, just, frugal, etc.), holier-than-thou, moralistic, self-righteous, pure, clean, well-intended, honest and upfront, righteous, innocent, blameless, wise, unassuming, impartial, humble, meek, peaceful (undisturbed, unagitated), content (modest), restrained, moderate, modest, sober, abstinent, chaste, austere, self-chastising, uptight, frigid. Goody-two-shoes. Moraliser. Man who is celibate - possibly a monk. Virgin. To do the morally right thing regarding a man. To make peace with a man. Man makes peace with something or someone.

**Man-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: sunny, warm, brilliant, glowing, clearly visible, superficial, awake, aware, conscious, easy-going, happy, joyful, merry, celebratory, charismatic, popular, famous, successful, confident, extroverted, optimistic. Obviously a man. Man who is the querent's sunshine. Man who broadcasts something very strongly. Strong male vibes. To make a man happy. To warm (up), brighten the mood of, a man. To show a man clearly that X; to proof to a man that X. To spend a day with a man. To wake a man up. To be aware or make aware of a man; to enjoy, have fun with, celebrate, a man or men in general. Possibly: to go on a vacation with a man. Man who doesn't hide his light under a bushel. Man keeps up appearances / to keep up appearances for a man.

**Man-Moon
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who has a lot of depth. Man who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A man at night/in the evening. Man of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a man. Traumatised by a man. To spend a night with a man. To rest in the company of a man.

**Man-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: Open-minded, open-hearted, unguarded, prying (not respecting your boundaries), accessible, accepting, welcoming, liberated, relieved, inspired, inspiring, inventive, understanding, insightful. A man who is our key to success, or who we view as a means to an end. To welcome or say yes to a man. To free or relieve a man; to understand a man or men in general. That which gives us access (to the heart or mind) of a man.

**Man-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted; valued; cherished, esteemed. Man who is self-employed, working hard. Male business partner. To value men(s opinion, presence etc.). A man values something, cherishes something, is looking for profit.
Capitalist, man with a job to do with money. Man who views love or happiness etc. as something he can buy. To "buy" a man. To profit from a man. Too many men; too much of one man. That which the querent values in a male partner, or in men in general. Traditionally "male" values. To profit from male gender roles or stereotypes.

**Man-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is abiding, has halted, stopped. Long-term male resident. Man is being held up or held back, caught, stuck, confined, restrained. Man who is stable, firm, secure, safe, "solid as rock", focused. Man with very set daily routines, mundane interests. Man we view as normal, ordinary, bland, boring.
Man who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a man; to confine or restrain or hold back a man. The man everything revolves around / everything revolves around men. To focus on a man. Man we share our daily life with. To hold on to, or find security in, traditionally male gender roles. Confining views about masculinity.

**Man-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is: ideological, religious, convinced of something, principled, dogmatic, absolutist, intolerant, uncritical, doesn't question. Man who is dutiful, responsible. Man who is burdened, or burdensome, exhausted or exhausting, who is in pain, suffering. Minister, monk. Man who is a burden to us; man who we feel destined to know/be in a relationship with. Responsibility for a man; duties to a man. Traditionally male duties; specifically male sufferings. Absolutist convictions of what is "male", or of how men should behave.

**Man - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)**
Man who is androgynous. Possibly: transgender or intersex man. A man does something with a genderqueer person. The oddball. A man wonders; to wonder about a man. A question mark regarding a man. A man is the unknown factor in the equation. Masculine in some ways but not in others. A man is important but we don't know which man.
