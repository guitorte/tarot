---
title: "lenormand | man (b) | keywords"
source: https://www.annak-tarot.at/lenormand/28_man2_e.html
---

**MAN 28 *(version b)***

*Note:* The following keywords apply both to Man *(b)* and to Man *(a)*. If you want to see Man *(a)* you can do that [>> here](https://www.annak-tarot.at/lenormand/28_man_e.html).

**Keywords**

***Nouns / phrases:***

Usually represents a man or boy - see paragraph *As a person*.
Possibly also: "maleness" or "masculinity"; the influence male gender roles and
stereotypes have on the querent. Situations or places where there's usually a
majority of men (e.g. building site; military; football stadium).
ations or places were there's usually a majority of men (e.g. building site; military; football stadium etc.).

 ***Activities:***

To do something with a male person. Possibly: activities the querent
considers "masculine".

 ***Attributes:***

Male; possibly: "masculine" (whatever that means to the querent).
Concerning a male person.
 **As a person:**  Represents the querent if the querent is male. If the querent is female,
the Man represents either always the querent's spouse, steady boyfriend, or, if
she is single, a love interest, or always the male person most relevant to the question asked - e.g.
the querent's spouse, or an affair, friend, work colleague, male relative.
 **As advice:**
 If the Man represents the querent: "This is about you!". If the Man represents someone
the querent knows: "This male person is very relevant to your concern!". Possibly: "Have a
close look at how your ideas about what men are (or should be) like influence your situation!"

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When/if it happens depends on the Man.

 **See also** the *annakblogs* article [>> So, is the Man a positive or a negative card?](https://annakblogs.wordpress.com/2018/05/08/man-woman/)
