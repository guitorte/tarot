---
title: "lenormand | woman (b) | combinations"
source: https://www.annak-tarot.at/lenormand/29_woman2-komb_e.html
---

**COMBINATIONS WITH THE
WOMAN *(b)***

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Woman-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is:
New - in the sense of unfamiliar, changed; able to change *you*, in a hurry, quick, surprising, active, energetic, flamboyant, pushy, cocky, intrusive, importunate, shrill, harsh. A woman brings something (e.g. e message), approaches, acts, causes change, charges, attacks, harasses, intrudes, meddles, intervenes, pushes for something, grandstands.
To approach a woman; to beset or harass a woman. Attempts to change a woman. A traditionally "female" approach.

**Woman-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: a lucky devil; happy-go-lucky, easygoing, not-serious; joking, humorous, playful, unimportant, irrelevant. Irresponsible, unburdened, has no responsibilities, doesn't do her bit; a gambler or risk-taker. To chance something regarding a woman; to take a woman (or women in general) not seriously. To toy with a woman / woman who toys with us. To joke/fool around with a woman. To keep it light with a woman.

**Woman-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is absent, missing, gone away, very distant, travelling, not there yet, on the way, (ad)venturous, yet to be learned to know, exploring, seeking, searching, full of wanderlust; fidgety, ready to leave, not committed.
To leave a woman; to look for a woman; to explore a woman (or womanhood).
A woman makes changes. An explorer, a traveller, a foreigner.

**Woman-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: native, at home, at home with something, a family member, well-established, settled, private, familiar, used to or intimate with you; close-minded regarding anything which is new/unfamiliar, xenophobic, orderly, normal, regular, simple, planning ahead, low-risk, safe, conservative, inflexible, anti-innovative.
Female family member; a creature of habit, stay-at-home mom.
Woman moves in, starts a family, settles with something, keeps something private, wants things to stay as they are. Patriot. Family woman. A woman's privacy. (Traditional) rules or roles which apply to women specifically.

**Woman-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: natural, physical, alive, thriving, deeply rooted, grounded, belonging, steadfast, robust, inflexible in the sense of not versatile, down-to-earth, pragmatic.
A female ancestor. To grow into womanhood. Healer. Female body, or traditionally "feminine" physique. Female-specific health issues. Woman does something in nature; woman who is close to nature, does something physical.

**Woman-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: confused, insecure, desperate, lost. A shady character, woman who is hiding something, putting up a smoke-screen. Deceiver. Woman in need of guidance. Woman who lacks interest (or who lacks interesting characteristics), is listless. Deadhead. A woman the querent can't see / doesn't see as who she really is. Deadhead.

**Woman-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: eager, covetous, avid, attracted to someone or something, power-hungry, thirsty for knowledge (inquisitive), horny, addicted, seductive, ambitious, single-minded, goal-oriented, focused, motivated, driven, ruthless, calculating, egotistical, inconsiderate, strong-willed, headstrong, tenacious, shrewd, skilful, (smart), diplomatic, manipulative.
Type A personality woman, lawyer, politician, diplomat. A woman goes her own way. An affair with a woman. To feel attracted to, seduce, manipulate, or coerce, a woman.

**Woman-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**.
Woman who has died. Woman who's suffered loss; Woman who hasn't let go of something (or, a woman who is in the process of letting go). Widow. Woman who is suppressing a lot or buried her dreams. To let go of a woman; grief over the loss of a woman. To suppress the woman inside ourselves. To not allow a woman to live life to the fullest.

**Woman-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: invited; on a visit, convivial, sociable; socially active. Woman who is affable, well-mannered. Woman who is appreciated by the querent, or generally praiseworthy. Woman who is flirtatious, or ingratiating. Bootlicker. Pretty woman; groomed woman. A peacock. Woman who tends to exaggerate or whitewash things. A welcome visitor, a hostess. Interior designer, hairdresser, stylist, plastic surgeon etc. To show appreciation to a woman; to flatter or flirt with a woman or women in general. To visit a woman; give a present to a woman.

**Woman-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: efficient, blunt, does unexpected or hurtful things. Woman who has cut you off. A female ex-partner. Divorcee. To cut off or hurt a woman. Woman reaps what she has sown. To get what you deserve from a woman. To tie up lose ends or settle scores with a woman. Woman cleans up. Woman with a sharp tongue /who can hurt you.

**Woman-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: a cynic, snarky, judgemental - or ashamed; guilty. Prosecutor, lawyer, judge, police officer. To criticise, insult, shame, or abuse, a woman. Woman who beats herself up about something. Aggressive woman, abuser. Misogyny. To feel ashamed for being a woman. Argument with a woman. Woman is guilty; woman makes amends.

**Woman-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: excited, agitated, exhilarated, (over) stimulated, busy, preoccupied, fussy, nervous, stressed, on alert, not relaxed, skittish. Woman who is talkative, gossipy. Woman who is brooding, worried, anxious. Woman with obsessive-compulsive disorder. Woman who is fidgety, restless, fickle, chaotic, unorganised, distracted. Woman who distracts, annoys. Woman who is quick to react, or prone to knee-jerk reactions. Quick-witted, mobile, agile woman.
Woman with ADHD, multitasker, blabbermouth. Woman difficult to assess or who it would be unwise to rely on because she is so fickle. To bother a woman; gossip or worries about a woman; to distract or talk over (and not listen to) a woman.

**Woman-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Girl, (grand)daughter. Mother of a child. A woman who wants a child. Woman who is: Childlike, infantile, delicate, cute, weak, sensitive, vulnerable, defenceless, non-threatening young (at heart), new, innovative, inquisitive, playful, inexperienced, in need of guidance, guileless, innocent, naive, gullible, immature. To belittle a woman or women in general. Woman takes the first step. To want the woman to initiate. It's a baby girl!

**Woman-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is cautious, streetwise, maybe overly suspicious or defensive. Woman who looks after herself well, or is selfish or follows her own agenda. Woman with a lot of integrity. Woman whose character is difficult to assess since she seems to change constantly, depending on her surroundings. Trickster. To identify with the female gender.

**Woman-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Mother or mother figure. Female boss, leader, teacher, protector. Woman who is: strong, dominant, protective, choleric, bossy, possessive, competent, wealthy. Possibly: To protect a female person; to make a big show of one's femininity; appearing feminine (or female) dominates life. Depending on context: to protect oneself or someone else against a woman.

**Woman-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: hopeful, trusting, spiritual; or has a lot of unfulfilled wishes. Woman who aspires to something, who dares to reach for the stars. Daydreamer / daydreams about a woman. Woman in the querent's future. To idealise a woman or women in general. To have faith in a woman without good reason, or to have trust in a woman (with good reason). Woman we feel deeply connected with.

**Woman-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: a migrant, relocating, transitioning, transforming, returning, full of longing. Woman who acts instinctively, follows her inner nature. A woman by (inner) nature. To long for or reconnect with a woman. Something inevitable concerning a woman.

**Woman-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: a friend, an employee, a follower, helpmate. Woman who is devoted, loyal, supportive, wants to be led, needs approval or praise, doesn't think for herself. To befriend a woman. To ask a woman for permission. To do what a woman (or women in general) say; to crave the approval of a woman or women in general.

**Woman-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman in a top position, e.g. boss. Woman who is denying, forbidding, solitary, emotionally distant, lonely, isolated, aloof, disciplined, clear-headed, independent, on top, leading, the best, proud, snotty, arrogant, controlling, authoritarian, in power. Segregation of women. Female authority. Single parent, widow. Authority over a woman; to lord it over women. Woman who has authority over the querent. A female expert. Organisations run by or for women. Matriarchy. To think about a woman rationally. Woman who rises above.

**Woman-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
A woman is exposed. Woman who exposes, reveals something. Woman who goes along with the mainstream, with what's commonly accepted. Women's collective, women's union. To show up a woman.
Woman with no sense of privacy. Woman who is in the public eye (e.g. politician); woman who networks, woman for whom public opinion and/or her reputation is very important. To present as female. To meet a woman in public. Women in society. Female-dominated (sub)culture.

**Woman-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: difficult, problematic, restrictive, impaired, challenging, conspicuous, present, big, tall, heavy, overweight, unmoved, blocked, rigid, quiet, silent, stubborn, persisting, unwilling or refusing to do something. Female nemesis or contender. Problems with femininity. Difficulties/challenges specific to women. To challenge a woman. To have problems with a woman or women in general. To hinder a woman. A woman gives us the silent treatment (or the other way around).

**Woman-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: one of two or more potential partners / female friends / mothers etc. Woman who is confronted with an important decision. Woman who is hesitant, indecisive, in two minds, tarrying, ambivalent about something, tolerant. To deliberate or speculate about a woman. Decision about a woman. Woman who is difficult to assess because she keeps changing directions. Woman with many faces.

**Woman-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: poor, lost, losing weight, bad, deteriorating, degenerated, secretive, covert, sneaky, crooked, unfrank, disingenuous, unwholesome, unhealthy, sick, infected, corrupt, corrupting, dirty, doing things behind someone's back. Woman who is faced with theft, corruption, or exploitation - or one who's the perpetrator. Thief. Woman who is exhausted or getting weaker. Woman who isn't good for us. To badmouth a woman or women in general. To spy on a woman; to do something behind a woman's back. Energy vampire; woman who sucks you dry.

**Woman-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: a romantic, in love, infatuated. Woman who is loving, affectionate, tender, gentle, sweet-tempered, soft-hearted. Woman who mollycoddles others. Woman who is good at heart, compassionate, caring, altruistic, charitable, magnanimous, merciful, selfless. Woman who is forgiving. Woman who is involved with all her heart. Female lover. Woman who the querent is in love with. To love a woman; to care for a woman, to give solace to a woman. To forgive a woman. To mollycoddle a woman.

**Woman-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: committed, well-connected, bound by something or who the querent is bound to. Woman the querent is in some sort of relationship with, e.g. lover, spouse, business partner. Woman we have something in common with. Female bonding. Promise from a woman, or to a woman. Woman who is dependable, or (annoyingly) predictable.

**Woman-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: well-educated, intelligent, intellectual, knowledgeable, in the know, known. An academic, a scientist, teacher or professor - possibly a student, depending on the question. Truth about a woman; facts about a woman. To get to know a woman. To tell the truth to a woman or about a woman. To categorise someone as female / feminine.

**Woman-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: communicative, likes to share what she
thinks/feels/knows. Woman with expressive gestures or facial expressions.
Communication with a woman; conversation with a woman or about a woman. Expressions of womanhood.
Postwoman, host of radio show, mediator, speaker, pen pal.

**Woman (b)
- Man (a)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
A woman and a man do something together. There's a close relationship between a man and a woman. A woman and her friend, boyfriend, or husband. In this case: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. Also: a woman shows characteristics viewed as "masculine" by the querent (or society). A woman does traditionally "male" things.

**Woman (b)
- Woman (a)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
A female person is very relevant to the female querent's concern! Two women do something together. There's a very close relationship between two women. A woman and her friend, girlfriend, or wife. In this case: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. If you wish you can view the fact that they are facing each other as a sign they still very much want to keep up the relationship, but maybe should still look for more things to share so they will not start to drift apart eventually. Possibly: The female querent's ideas about what women are (or should be) like influence her situation (e.g. her decisions, or how she views herself) tremendously. A traditionally feminine woman; a woman does traditionally "female" things.

**Woman (b)
- Man (b)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)**
A woman and a man do something together. Wife and husband, girlfriend and boyfriend. There's a close relationship between a man and a woman. Possibly: because there are no cards between them which define what holds them together maybe they don't share much - which could be a danger to the relationship eventually. If you wish you can view the fact that they are facing each other as a sign they still very much want to keep up the relationship, but maybe should still look for more things to share so they will not start to drift apart eventually. Also: a woman shows characteristics viewed as "masculine" by the querent (or society). A woman does traditionally "male" things.

**Woman (b)
- Woman (b)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)**
Everything hinges on the person the Woman represents. A female person is very relevant to the querent's concern! Possibly: The female querent's ideas about what women are (or should be) like influence her situation (e.g. her decisions, or how she views herself) tremendously / the male querent's ideas about what women are (or should be) like influence his situation (e.g. his relationship with his spouse, or how he treats women in general).

**Woman-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: sensual, sexually active, passionate, enticing, attractive, artistic, talented, creative, intense, contented, comfortable, peaceful, mature, , self-indulgent, lazy, gluttonous, drunk, high, excessive. Woman who enjoys the arts; artist (poet, dancer, musician, painter...); woman only interested in sensual/sexual pleasure. Woman who takes her time. Or: a lover (real or prospective or dreamed of). To go slowly with, caress, or pleasure, a woman. Poetry or music or paintings by or about a woman or women in general.

**Woman-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: virtuous (in general, or specifically e.g. prudent, just, frugal, etc.), holier-than-thou, moralistic, self-righteous, pure, clean, well-intended, honest and upfront, righteous, innocent, blameless, wise, unassuming, impartial, humble, meek, peaceful (undisturbed, unagitated), content (modest), restrained, moderate, modest, sober, abstinent, chaste, austere, self-chastising, uptight, frigid. Goody-two-shoes. Moraliser. Woman who is celibate - possibly a nun. Virgin. To do the morally right thing regarding a woman. To make peace with a woman. Woman makes peace with something or someone.

**Woman-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: sunny, warm, brilliant, glowing, clearly visible, superficial, awake, aware, conscious, easy-going, happy, joyful, merry, celebratory, charismatic, popular, famous, successful, confident, extroverted, optimistic. Obviously a woman. Woman who is the querent's sunshine. Woman who broadcasts something very strongly. Strong female vibes. To make a woman happy. To warm (up), brighten the mood of, a woman. To show a woman clearly that X; to proof to a woman that X. To spend a day with a woman. To wake a woman up. To be aware or make aware of a woman; to enjoy, have fun with, celebrate, a woman or women in general. Possibly: to go on a vacation with a woman. Woman who doesn't hide her light under a bushel. Woman keeps up appearances / to keep up appearances for a woman.

**Woman-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)**
Woman who has a lot of depth. Woman who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A woman at night/in the evening. Woman of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a woman. Traumatised by a woman. To spend a night with a woman. To rest in the company of a woman.

**Woman-Key[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)**
Woman who is: Open-minded, open-hearted, unguarded, prying (not respecting your boundaries), accessible, accepting, welcoming, liberated, relieved, inspired, inspiring, inventive, understanding, insightful. A woman who is our key to success, or who we view as a means to an end. To welcome or say yes to a woman. To free or relieve a woman; to understand a woman or women in general. That which gives us access (to the heart or mind) of a woman.

**Woman-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted. Valued; cherished, esteemed. Woman who is self-employed, working hard. Female business partner. To value women(s opinion, presence etc.). A woman values something, cherishes something, is looking for profit.
Capitalist, woman with a job to do with money. Woman who views love or happiness etc. as something she can buy. To "buy" a woman. To profit from a woman. Too many women; too much of one woman. That which the querent values in a female partner, or in women in general. Traditionally "female" values. To profit from female gender roles or stereotypes.

**Woman-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is abiding, has halted, stopped. Long-term female resident. Woman is being held up or held back, caught, stuck, confined, restrained. Woman who is stable, firm, secure, safe, "solid as rock", focused. Woman with very set daily routines, mundane interests. Woman we view as normal, ordinary, bland, boring.
Woman who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a woman; to confine or restrain or hold back a woman. The woman everything revolves around / everything revolves around women. To focus on a woman. Woman we share our daily life with. To hold on to, or find security in, traditionally female gender roles. Confining views about femininity.

**Woman-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)**
Woman who is: ideological, religious, convinced of something, principled, dogmatic, absolutist, intolerant, uncritical, doesn't question. Woman who is dutiful, responsible. Woman who is burdened, or burdensome, exhausted or exhausting, who is in pain, suffering. Minister, nun. Woman who is a burden to us; woman who we feel destined to know/be in a relationship with. Responsibility for a woman; duties to a woman. Traditionally female duties; specifically female sufferings. Absolutist convictions of what is "female", or of how women should behave.

**Woman - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)**
Woman who is androgynous. Possibly: transgender or intersex woman. A woman does something with a genderqueer person. The oddball. A woman wonders; to wonder about a woman. A question mark regarding a woman. A woman is the unknown factor in the equation. Feminine in some ways but not in others. A woman is important but we don't know which woman.
