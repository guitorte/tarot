---
title: "lenormand | woman (b) | keywords"
source: https://www.annak-tarot.at/lenormand/29_woman2_e.html
---

**WOMAN 29 *(b)***

***Note:*** The following keywords apply both to Woman *(b)* and to Woman *(a)*. If you want to see Woman *(a)* you can do that [>> here](https://www.annak-tarot.at/lenormand/29_woman_e.html).

**Keywords**

***Nouns / phrases:***

Usually represents a woman or girl - see paragraph *As a person*.
Possibly also: "femaleness" or "femininity"; the influence female gender roles and
stereotypes have on the querent. Situations or places where there's usually a majority
of women (e.g. women's association; midwifery; yoga class).

 ***Activities:***

To do something with a female person. Possibly: activities the querent
considers "feminine".

 ***Attributes:***

Female. Possibly: "feminine" (whatever that means to the querent).
Concerning a female person.
 **As a person:**  Represents the querent if the querent is female. If the querent is male
the Woman represents either always the querent's spouse, steady girlfriend, or, if he
is single, a love interest, or always the female person most relevant to the concern - e.g. the
querent's spouse, or an affair, friend, work colleague, female relative.
 **As advice:**
 If the Woman represents the querent: "This is about you!". If she represents someone the
querent knows: "This female person is very relevant to your concern!". Possibly: "Have a close look at
how your ideas about what women are (or should be) influence your situation."

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When/if it happens depends on the Woman.

 **See also** the *annakblogs* article [>> So, is the Woman a positive or a negative card?](https://annakblogs.wordpress.com/2018/05/08/man-woman/)
