---
title: "lenormand | woman (a) | comparisons"
source: https://www.annak-tarot.at/lenormand/29_woman-comp_e.html
---

woman *(a)*

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Woman *(a)*, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Female/male**

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)

**Woman *(a&b)***:The female querent; woman or girl, female - other characteristics are usually left open, with the possible exception of "feminine". To do something with a woman. Possibly: Female dominated places or activities.

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)

**Man (a&b)**: The male querent; man or boy, male - other characteristics are usually left open, with the possible exception of "masculine". To do something with a man. Possibly: Male dominated places or activities.

 **Woman and Man (a) vs. Woman and Man (b)**

On the interpretation pages for the Women and Men I write at length about how and why they don't represent any specific characteristics other than that they represent female and male people, and I explain that I tried to leave any other characteristics as open as possible by not showing their faces and dressing them in rather loose garments. But even though I did my best, I didn't quite succeed. I had to place them in specific environments, I had to dress them in *some* way, and their garments had to have certain colours. So they are *not* neutral. Depending what you personally associate with the type of environment they're placed in, with the time of year shown in the images, with the colours they are wearing and with what they are doing, you might find yourself hard put not to to assign them a few more attributes, especially in comparison with each other. One way to deal with this would be to try and ignore the specific characteristics as much as possible. Another would be to use them to enrich your interpretation. For me, it's the following attributes that come up frequently:

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)

**Woman and Man*(a)***: more equal relationship; less traditional gender roles; not conventionally feminine and masculine. More mature, not quite as well off, sportive, physical, doers, nature lovers.

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)

[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)

**Woman and Man (b)**: more traditional relationship and/or gender roles; conventionally feminine and masculine. Younger, rather well off, prefer comfort and/or to stay indoors, creative.
