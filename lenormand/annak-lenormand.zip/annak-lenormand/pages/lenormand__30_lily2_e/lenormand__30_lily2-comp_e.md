---
title: "lenormand | (virtuous) lily | comparisons"
source: https://www.annak-tarot.at/lenormand/30_lily2-comp_e.html
---

(virtuous) lily

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the (Virtuous) Lily
*(for the (Sensual) Lily click [>> here](https://www.annak-tarot.at/lenormand/30_lily_e.html)!)*, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Virtuous Lily vs. Sensual Lily**

|  |  |
| --- | --- |
|  | **Virtuous Lily**: Virtue, wisdom, humility. Contentedness caused by an absence of cravings, an absence of inner disturbance. Modesty, frugality, frigid austereness. |
|  | **Sensual Lily**: Sexuality and sensuality, high quality pleasures. Contentedness caused by harmony and plenty of pleasure. Gluttony, laziness, excess. |

 **Innocence/purity**

|  |  |
| --- | --- |
|  | **Lily**: Innocence especially in the sense of "being without guilt" - the innocence and "purity" of someone blameless, honest and pure of thought. Actual, physical stainlessness, cleanliness. |
|  | **Child**: Innocence and purity especially in the sense of "hasn't had contact yet with the harsh, dirty parts of life". Sexually innocent in the sense of "inexperienced". |

**Sexuality**

|  |  |
| --- | --- |
|  | **Virtuous Lily**:  "I don't have sex!" Sexual abstinence. Possibly: frigidity, prudery. |
|  | **Child**: Sexual immaturity, innocence. "I haven't had (much) sex (yet)." Sexual immaturity, inexperience, innocence. |
|  | **Lily**: "I enjoy sex!" Sexual passion, maturity, experience. A purely sexual relationship. |
|  | **Snake**: "I want sex!" Strong sex drive. To use sex as a means to an end. Seduction. |
