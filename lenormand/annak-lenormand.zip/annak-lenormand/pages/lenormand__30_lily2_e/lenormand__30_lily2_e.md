---
title: "lenormand | (virtuous) lily | keywords"
source: https://www.annak-tarot.at/lenormand/30_lily2_e.html
---

**(VIRTUOUS) LILY 30**

*Note:* This version of my Lily represents virtuousness. For the other version which represents sensuality click [>> here](https://www.annak-tarot.at/lenormand/30_lily_e.html)!

**Keywords**

***Nouns / phrases:***

Morality and virtuousness in general; any specific virtue (e.g.:
temperance, prudence, discipline, frugality, dutifulness. Self-awareness and wisdom.
Moralistic self-approval, moralising. Purity; pureness of heart and mind. No
hateful thoughts, good intentions, righteousness. Innocence, clear conscience.
Cleanliness. Impartiality, humility, meekness. Peacefulness, contentedness. Restraint,
modesty, moderation, fasting, sobriety, abstinence. Chasteness, austereness,
self-chastisement, frigidity, cold.

 ***Activities:***

To do good things (e.g. help others, give to the poor), do the morally correct thing (e.g.
speak the truth, do one's duty). To moralise. To have good intentions. To clean, purify. To pacify,
make peace with someone or something. To contain oneself, moderate. To fast, abstain. To cool.

 ***Attributes:***

Moral(ly). Virtuous (in general, or specifically, e.g. prudent, just, frugal). Holier-thanthou,
moralistic, self-righteous. Pure, clean, clear, free of dirt. Well-intended, honest and upfront,
righteous. Innocent, blameless. Wise, unassuming, impartial, humble, meek. Peaceful (undisturbed,
unagitated), content. Restrained, moderate, modest, sober, abstinent, chaste, austere, selfchastising,
uptight, frigid.
 **As a person:**  Person with the above attributes, esp.: very virtuous. Goody two-shoes, moraliser.
Someone who lives frugally. Someone who is celibate.
 **As advice:**
 Do the right thing! Abstain! Negatively: Don't be uptight! Don't moralise!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When it's morally correct or wise / when it's peaceful or creates peace. Traditionally:
winter.

 **See also** the *annakblogs* article [>> So, is the (virtuous) Lily a positive or a negative card?](https://annakblogs.wordpress.com/2018/07/22/virtuous-lily/)
