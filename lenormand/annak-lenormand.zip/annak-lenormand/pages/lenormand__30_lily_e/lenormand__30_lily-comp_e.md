---
title: "lenormand | (sensual) lily | comparisons"
source: https://www.annak-tarot.at/lenormand/30_lily-comp_e.html
---

(sensual) lily

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the (Sensual) Lily
*(for the (Virtuous) Lily click [>> here](https://www.annak-tarot.at/lenormand/30_lily2_e.html)!)*, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Sensual Lily vs. Virtuous Lily**

|  |  |
| --- | --- |
|  | **Sensual Lily**:Sexuality and sensuality, high quality pleasures. Contentedness caused by harmony and plenty of pleasure. Gluttony, laziness, excess. |
|  | **Virtuous Lily**: Virtue, wisdom, humility. Contentedness caused by an absence of cravings, an absence of inner disturbance. Modesty, frugality, frigid austereness. |

 **Sexuality**

|  |  |
| --- | --- |
|  | **Lily**: "I enjoy sex!" Sexual passion, maturity, experience. A purely sexual relationship. |
|  | **Snake**: "I want sex!" Strong sex drive. To use sex as a means to an end. Seduction. |
|  | **Child**: Sexual immaturity, innocence. "I haven't had (much) sex (yet)." Sexual immaturity, inexperience, innocence. |
|  | **Virtuous Lily**: "I don't have sex!" Sexual abstinence. Possibly: frigidity, prudery. |

**Intensity and slowness**

|  |  |
| --- | --- |
|  | **Lily**: Very intense experience, to take your time. |
|  | **Birds**: Superficial, quick experience; to hurry. |
|  | **Mountain**: Here the "slowness" has turned into a total cessation of movement, into a complete standstill. The only thing "intense" now is the sense of blocked movement, of actual or metaphorical silence. |

**Energy**

|  |  |
| --- | --- |
|  | **Lily**: Sexual energy; sex drive. Sensual passion. |
|  | **Tree**:  Physical energy. Energy in the sense of vitality. Life-force. To feel energetic in the sense of fit and healthy. |
|  | **Birds**:  Nervous and unstable energy; energy fluctuations |

 **Longing**

|  |  |
| --- | --- |
|  | **Lily**: Sexual longing; the longing for sensual experiences. |
|  | **Ship**: Longing in the sense of wanderlust - the longing to be elsewhere, to discover new places. |
|  | **Stork**: Deep longings in general, but especially the longings which arise from our inner nature. |
|  | **Heart**: Romantic longing. |
|  | **Snake**: Longing in the sense of cravings - to want to get or to achieve something. |

**Relationships**

|  |  |
| --- | --- |
|  | **Lily**: By itself a purely *physical*, sexual, relationship - could be respectful *or* exploitive. |
|  | **Heart**: A *loving* relationship - possibly romantic. |
|  | **Ring**: The commitment part of a relationship - *any* type of relationship; could even be a work relationship. |
