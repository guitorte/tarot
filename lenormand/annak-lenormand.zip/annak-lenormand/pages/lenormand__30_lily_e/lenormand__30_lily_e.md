---
title: "lenormand | (sensual) lily | keywords"
source: https://www.annak-tarot.at/lenormand/30_lily_e.html
---

**(SENSUAL) LILY 30**

*Note:* This version of my Lily represents sensuality. For the other version which represents virtuousness click [>> here](https://www.annak-tarot.at/lenormand/30_lily2_e.html)!

**Keywords**

***Nouns / phrases:***

Sensuality; hearing, smelling, touching, tasting, seeing. Sensual
pleasures, regalement. Caress, (good) sex, sex drive, sexual passion, sexual
relationship. The arts, creativity; visual and performance arts, music, dance, poetry.
Slowness. Intensity, poignancy. Maturity, experience, (old) age. High-quality.
Talent. Contentedness, peacefulness, harmony. Overindulgence, laziness, lack of
intellectual depth and emotional shallowness, debauchery, gluttony, excess.

 ***Activities:***

To sensually experience; hear, smell, touch, see, taste. To eat and/
or drink. To pleasure; enjoy, regale, relish, savour. To caress, massage, have sex. To create (art);
make music, paint, dance, write poetry. To express one's passions through artwork. To take one's
time; to go slowly, slow down. To intensify. To satisfy. To overindulge, laze around.

 ***Attributes:***

Sensual, sexual, passionate, enticing. Pleasurable, luxurious, saturated, yummy. Artistic,
talented, creative. Musical, poetic. Slow, intense. Contented, comfortable, peaceful (especially
in the sense of harmonious). Mature, ripe, high-quality, top-grade, excellent, exquisite.
Self-indulgent, lazy, gluttonous, drunk, high, excessive.
 **As a person:**  Person with the above attributes. (Potential or actual) lover, probably experienced
and skilled. An artist. Mature person. Experienced or gifted person; sensual person; slow person.
Someone who lets themselves go, eats/drinks too much - sluggard, couch potato.
 **As advice:**
 Enjoy it! Take it slowly! Negatively: Don't overindulge!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Something is taking time. When it's harmonious. The infinite present moment.
Traditionally: Winter.

 **See also** the *annakblogs* article [>> So, is the (sensual) Lily a positive or a negative card?](https://annakblogs.wordpress.com/2018/05/15/sensual-lily/)
