---
title: "lenormand | sun | comparisons"
source: https://www.annak-tarot.at/lenormand/31_sun-comp_e.html
---

sun

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Sun, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Sun vs. Moon**

|  |  |
| --- | --- |
|  | **Sun**: Light, day, spring and summer. Happiness, awareness, obviousness, possibly: superficiality. |
|  | **Moon**: Darkness, night, winter and autumn. Sadness, that of which we are only half- or even *un*aware; profoundness. |

 **Ease**

|  |  |
| --- | --- |
|  | **Sun**: Ease in the sense of "the situation is bright and joyful", or because we ignore anything dark. |
|  | **Clover**: Ease in the sense that we take nothing seriously, or ease because we refuse to take on any responsibilities. |

**Positive Emotions**

|  |  |
| --- | --- |
|  | **Sun**: Happiness - joy, mirth, ease. |
|  | **Bouquet**: generosity, thankfulness, appreciation, admiration; cordiality. |
|  | **Heart**: All types of love, kindness, but also tenderness, compassion, forgiveness etc. |
