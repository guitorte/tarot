---
title: "lenormand | sun | keywords"
source: https://www.annak-tarot.at/lenormand/31_sun_e.html
---

**SUN 31**

**Keywords**

***Nouns / phrases:***

Sun, summer. Warmth, heat. Light, shine, glow. Brightness. The
visible, clear, and obvious. Lack of depth; shallowness. Appearance. Day and
daylight, waking state. Awareness, consciousness. Happiness, joy, celebration,
vacation. Emission, transmission, a strong broadcaster, charisma. Popularity,
fame, success. Extroversion, enterprising spirit, confidence. Also: the Sun might
lessen the depth/significance of neighbouring "negative" cards.

 ***Activities:***

To heat, warm (up). To shine, glow. To light/brighten (up). To throw
light on X. To spend a day with something/someone. To wake (up). To be aware or make aware, to
be conscious of. To enjoy, have fun, celebrate. Possibly: to go on a vacation. To emanate, radiate,
broadcast. To succeed, to be confident about X. To not hide one's light under a bushel. To keep
up appearances.

 ***Attributes:***

Sunny, summery. Warm, hot. Bright, light, brilliant. Shiny, glowing. Visible, clear, obvious,
superficial, apparent. Awake, aware, conscious. Easy, happy, joyful, merry, celebratory.
Charismatic, popular, famous, successful. Confident, extroverted.
 **As a person:**  Person with the above attributes, especially: a happy person. Person who is your
sunshine. Sunny person. Someone who broadcasts something very strongly.
 **As advice:**
 Be happy (about it)! Always look on the bright side of life! Don't hide your light under
a bushel! Take a day off! Negatively: Don't ignore the dark sides of life! Look below the surface!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When it's obvious. Day(time), and more specifically noon. Summer.

 **See also** the *annakblogs* article [>> So, is the Sun a positive card?](https://annakblogs.wordpress.com/2018/08/01/sun/)
