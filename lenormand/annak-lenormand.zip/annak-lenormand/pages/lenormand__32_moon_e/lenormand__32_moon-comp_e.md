---
title: "lenormand | moon | comparisons"
source: https://www.annak-tarot.at/lenormand/32_moon-comp_e.html
---

moon

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Moon, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Mental
Issues**

|  |  |
| --- | --- |
|  | **Moon**: Mental/emotional issues to do with the "dark" part of our soul - fear, sadness, needs. E.g. phobias, depression, PTSD. Also: Sleep disorders. |
|  | **Clouds**: Problems which arise from a clouded view of reality, e.g. misunderstandings; lack of understanding, disorientation; illusionary thinking, hallucination, or paranoia. |
|  | **Birds**: Issues to do with extreme stress, worries, difficulties with concentration: e.g. nervousness, anxiety, obsessive compulsive behaviour, ADHD. |

 **Sadness**

|  |  |
| --- | --- |
|  | **Moon**: Melancholy and depression - sadness which arises from the perception of the whole world as a dark place. |
|  | **Coffin**: Grief - the type of "sadness" specific to the experience of a loss. |

**Moon vs. Sun - total opposites**

|  |  |
| --- | --- |
|  | **Moon**: Darkness, night, winter and autumn. Sadness, that of which we are only half- or even unaware; profoundness. |
|  | **Sun**: Light, day, spring and summer. Happiness, awareness, obviousness, possibly: superficiality. |
