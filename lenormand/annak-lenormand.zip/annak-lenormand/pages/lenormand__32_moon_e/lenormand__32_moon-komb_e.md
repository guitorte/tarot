---
title: "lenormand | moon | combinations"
source: https://www.annak-tarot.at/lenormand/32_moon-komb_e.html
---

**COMBINATIONS WITH THE
MOON**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Moon-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotionally unsettling news or changes. Profound change. Something or someone who brings fear with them; someone whose neediness is very importuning. Intrusive emotions. An emotional approach. Nightly activities. To act on one's emotions. Overwhelming intuition.

**Moon-Clover[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Untroubled by fears or needs. To make light of one's emotions. Advice: don't take this specific fear or need too seriously; don't give it too much importance. A little bit of depth. An opportunity to get in touch with one's emotions. "Nice" feelings only. Stroke of luck which is rather important. A lucky guess. To play with someone's emotions. Pleasant nights. To take the opportunity for a nap; an opportunity to rest. To take the necessity of rest/sleep not seriously enough.

**Moon-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Explorations or changes or departures that leave a deep mark on the psyche. To explore the unconscious. To explore something intuitively, without a conscious plan. Sadness because of a departure. Melancholic good-bye. Fear of the unexplored, fear of the unfamiliar. To explore something in depth. A restful journey. To leave so we can find rest. To meet our fears with courage. Strange emotions. Very profound need for a change of environment. To look into something in depth.

**Moon-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
The influence which how we were raised, or our family now, have on our subconscious or on our prevalent emotional state. Nights
at home; to stay in at night; to plan a night; rules regarding night time/sleep time. To find rest at home / in privacy. Something fearful goes on in the family. Familiar intuitions. To be familiar with and comfortable with acting according to intuition. Emotional family; depressed family member; a shadow lies on a home.

**Moon-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional health; that which grounds us emotionally; emotional resilience. Deeply rooted fears or needs or melancholy. Very deep roots.
Emotional health; that which grounds us emotionally; emotional resilience. Deeply rooted fears or needs or melancholy. Very deep roots. Instinct. Intuitions concerning our body. Natural intuition. Restful energy. To find rest in nature. A night in nature. Resting would be very healthy. Natural, healthy sleep patterns. Bio-rhythm. Strong but stable emotions. Pragmatic approach to our fears and needs. Physical trauma.

**Moon-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional confusion. Misunderstanding of emotion; or inability to understand emotions. Autism. Emotional disorder. To fog over our feelings. Someone is in dire need for a therapist! To hide away in order to find rest. Unclear intuition. Very vague inklings. Profound confusion; deep despair. Hidden darkness. Deceptive quiet. Tiredness so strong it clouds the mind. Things are so quiet we're bored. Deadheartedness; listlessness.

**Moon-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
To strive for knowledge about
the subconscious. To be drawn to the dark, to prefer nighttime. To be motivated by emotions/fears and needs. To follow one's intuition. To be good at directing other people's emotions; manipulation through playing on fears and needs. Profound cravings; deep wisdom. Conflict between our ambition and our need for rest. To seek out deep emotions.

**Moon-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
To put something to rest. To find rest after something has ended / someone has died. A loss casts a shadow on everything. Profound grief; grief which has turned to depression. To be unconsciously
aware of something ending. The emotional trauma of being witness to
death or sickness. The natural ups and downs one experiences after a loss. End of darkness; no more fears, or: to bury one's needs, to suppress one's fears or one's intuition. Loss of depth. To let go of an emotion.

**Moon-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Profound gratitude; very sincere compliments. Emotional visit; emotional compliments. Recognition causes deep emotions. To visit someone who is sad. Someone visits when all we want is to rest. To rest from social situations. Social phobias. A beautiful night. Exaggerated emotionality; to exaggerate a fear/need.

**Moon-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
To stop moaning. Interrupted sleep/rest/quiet. To wake up suddenly in a figurative sense: to become conscious of something suddenly and painfully. Deep hurt; emotional hurt. to reap neediness/fear. To stop being so needy. To take stock of one's emotional state. To make sleep more efficient (e.g. through proper sleep hygiene). Rest is urgently needed, now! To deserve rest. Something rips right down to the core. A rift which goes deep.

**Moon-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Confrontation with our fears/needs/emotions in general. Deep shame; profound remorse. To make someone deeply unhappy by shaming them or criticising them. Unconscious shame(ing). Conflicting needs or fears. Emotional violence. PTSD. Mental illnesses that have their root in abusive situations. Emotional injury; emotionally broken. To shame someone for their feelings. Discussion of fears/needs. Conflict about someone's (emotional) needs. Nightmares. A respite from conflict. Time out to lick our wounds.

**Moon-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotions all over the place; unstable emotions. Emotionally upset. Rest/respite from stress or chaos. Worries, or restlessness, disturb our sleep. Noisy, busy, or restless, night. Emotional reaction; intuitive reaction. Worries which are not conscious. Inability to let an emotion go. Profound anxiety; anxiety disorder.

**Moon-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Sad child, child with nightmares. A child needs rest. To put a child to sleep. The beginning of a journey into the deepest self. The inner child needs more
attention. Childhood traumata. Very little sleep / shallow sleep. The beginning of night; beginning of darkness. Childish emotions; immature emotions. What the inner child needs/fears. To belittle emotions or someone's needs/fears. Emotional vulnerability/suggestibility. Infantile emotions. Initial intuition. Intuition still needs to mature.

**Moon-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
To withdraw into oneself. A deep look into who one really is, deep down. A respite from emotionality. One's vital needs. Distrust that goes very deep, and maybe goes back to some kind
of trauma. Cautious handling of deep emotions. Deeply rooted suspicion. Self-care in the form of getting enough rest/sleep. When/because emotions are very strong it's important to practise proper self-care. Profound adaptation. To identify with darkness (figuratively speaking).

**Moon-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Strong emotions. Emotions dominate our life. Something or someone who has a dominant influence on the emotional life. Emotional/needy boss, parent, or teacher. Someone who can teach you how to deal with deep emotions, or with intuition. A therapist. To alternate
between being too choleric and overly melancholic. To be dominated by a certain fear or need or by sadness in general. Very profound influence (impact). Fluctuating power/strength. Powerful intuition. Possessiveness out of fear/neediness. To try to protect oneself or someone else from the dark sides of life. A dearly needed respite from someone's dominance or a dominant influence.

**Moon-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
To trust one's feelings, one's intuition. To find rest in escapism. Too many unfulfilled wishes, or daydreams, lead to melancholy. Daydreams and avoidance of reality. Profound spiritual experience. To find great depth and deep meaning in the emotional life. Emotional meaning. Idealisation of deep feelings. To be tired of hoping. Profound spiritual experience. A very profound illusion/delusion. Dark/sad fantasy. Very significant and meaningful connection. Intuition leads us to where we should be!

**Moon-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Very, very profound longing. A longing for profound experiences, for deep emotions. The slow process of moving into (or, depending on order of the cards, out of) a major depression. Emotional processes, emotional transformations. A transformation has led to more depth. To be a night person by nature. To feel a strong pull towards darkness (metaphorically speaking). Someone's transformation causes sadness. Very significant transition. Recurring sleepiness (during the day?). Recurring trauma. To be only half-aware or completely unconscious of a transformation or of a longing. Instinct (Stork) and intuition (Moon) are in some way relevant to the question.

**Moon-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Someone is extremely dependent in a needy sort of way. Sad or fearful or needy friend, follower, or employee. Emotional friend(ship). Emotional issues with a friend. Emotional support. Rest/a good night's sleep would help! A helper needs rest / a respite from helping. Loyalty to one's intuition - to always follow one's intuition. Tractable emotions. To abandon oneself to one's emotions. Profound worship.

**Moon-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional isolation. Emotional cold. To let nobody in emotionally. To need solitude. The profound experience of solitude. To find rest in solitude. Very deep loneliness. To withdraw from others in order to look at one's own emotions. Lonely nights, to sleep alone; to withdraw for a nap. To exert control over one's emotions. Conflict between the rational and what we want/need unconsciously. To have a clear-headed look at one's needs/fears.

**Moon-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
A respite from the public. Public places where we can rest. Fear of the public or of crowds or open spaces. Social phobias. A deep emotion that is very visible or should be owned up to publicly.
To openly flaunt deep emotions or needs - to publicly revel in emotions. Mass panic and similar occurrences where the individual's emotion is swallowed by the instinct of the whole crowd. Traumata that concern whole cultures.

**Moon-Mountain[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Difficult emotions; something is emotionally challenging. To tackle emotional issues. Inability to connect with deep needs and fears; intuition is blocked. Emotional blockade. Obstacle that lies in the emotional area. Difficulties/problems which go very deep and/or are very relevant. To rest before tackling a challenge. Inability to sleep. Something keeps us from sleeping. Finding time to rest is a challenge. Profound silence. Quietness is weighing on us. To overcome fear. To not give in to someone's neediness.

**Moon-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional choice. Emotional ambivalence. To deliberate on one's emotions (e.g. a fear, or need). Manifold fears, manifold needs. To fear making a decision. The emotional impact of having to make a decision. The emotional results of Choosing different options. Half-hearted (half-baked) intuition. A respite from complicated deliberations, or from a decision making process.

**Moon-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Unhealthy emotions; emotional neglect; lack of emotion. Emotions which have a "nagging" quality: doubts, worries, jealousy. Something is nibbling away at our emotional defences. Exhausting emotionality. To secretly harbour negative emotions. Destructive neediness. Sleep deprivation; bad sleep; nightmares. Bad sleep hygiene. "Fear eats away at the soul". Too little rest. Vague suspicion. Someone obscures something.

**Moon-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Soulful lover. To need love/tenderness/compassion. To fear love/tender feelings. Romanticisation of darkness/sadness. Romantic night. To spend a night with a loved one. To comfort someone who is sad. Very profound love that might also be mixed with sadness. Strong tender affections in general. Profound love. Empathy. Love helps us to quieten down. To help a loved one rest. Lover's grief.

**Moon-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Important relationship; significant connection. Shared
sadness; shared fear. A very profound, emotionally important relationship. A connection with the unconscious. To react with deep fear when faced with having to commit. A commitment to resting more. To make a connection intuitively. Emotional coherence. The cause for an emotion. Emotional ties - inability to let go of a relationship because the feelings involved are very strong. Predictable emotions. Reliable sleep. Relationship or connection with a dark component (= it brings sadness, fear, makes us more needy etc.). To rest together.

**Moon-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Sad facts. Profound truth. Psychology; to learn about the unconscious. Literature with a lot of depth. To study at night time. Knowledge about fears and needs. Hearing the truth results in emotional upheaval; confrontation with reality triggers fears. Rest from studying. To read books to rest. Reading before sleeping. A conflict between intellect and emotion. In-depth studies.

**Moon-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional conversation. A fear of expressing something. Need to talk. To express what we feel. Expressions of fear or sadness. Communication with our subconscious. Unconscious signals; to communicate intuitively. Conversations with a lot of depth. Obscure information. To let other's know we are tired. Nightly conversations. Dreams are telling us something. Lull in conversation. A respite from a conversation.

**Moon-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Man who has a lot of depth. Man who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A man at night/in the evening. Man of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a man. Traumatised by a man. To spend a night with a man. To rest in the company of a man.

**Moon-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Woman who has a lot of depth. Woman who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A woman at night/in the evening. Woman of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a woman. Traumatised by a woman. To spend a night with a woman. To rest in the company of a woman.

**Moon-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Man who has a lot of depth. Man who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A man at night/in the evening. Man of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a man. Traumatised by a man. To spend a night with a man. To rest in the company of a man.

**Moon-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Woman who has a lot of depth. Woman who is: quiet, restful, resting, tired, sleepy, sleeping, dark (literally and figuratively speaking), obscure, half-aware, unconscious (of something), full of foreboding, intuitive, emotional, soulful, fearful, needy, sad, melancholic, emotionally upset, traumatised.
A woman at night/in the evening. Woman of great significant for the querent or for answering the querent's question. A lot of feelings (not necessarily romantic!) for a woman. Traumatised by a woman. To spend a night with a woman. To rest in the company of a woman.

**Moon-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Very profound sexual or sensual experiences (which touch very deeply, or, negatively, trigger something). Deeply meaningful artwork; to express profound feelings creatively; art therapy. Intense emotions. Mature emotions; mature handling of difficult emotions. Harmonious, peaceful nights. Deep, restful sleep. Too much rest - laziness. To sleep too much. Extreme intensity. Highest quality.

**Moon-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Profound virtuousness. To deal with one's deepest needs and fears in a wise way. Or: To try and counter one's deeper needs and fears with self-discipline and renunciation instead of allowing them to be sated/eased. Virtue/purity is very important now. Even if you don't believe it of yourself, deep down you're a good person! A peaceful night, undisturbed sleep. Good sleep hygiene. Virtues which are relevant when dealing with strong emotions: e.g. compassion or equanimity.

**Moon-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Conflict between just wanting to be happy and having to confront something fearful. "They are like night and day!" Profound happiness. Shallow emotions. Warm, happy emotions. To spend day and night with something/someone. Happy dreams. Obvious emotions; to broadcast one's emotions very strongly. Happiness comes and goes. Obvious depth. To rest for a day. To sleep during the day. To stay awake a night. Awareness of one's emotions.

**Moon-Moon[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotions we are not processing consciously. Emotional trauma. Very emotional. Profound fear/need/sadness. Important intuition; significant forebodings. Deep sleep. To rest in the evening, sleep at night. A respite from something fearful.

**Moon-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Access to something that was hidden in the subconscious. Something which was not conscious comes into our awareness.
An understanding of emotions, especially fears, needs, and sadness. To let others come close
emotionally. An expert for the psyche. Finding something out has
confronted us with something profound. An emotional discovery. A feeling of relief. Profound relief. Complete surrender/abandon.

**Moon-Fish[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Too many emotions; too emotional. To value emotions/intuition/depth. Someone or something
means a whole lot to us emotionally. To profit from something emotionally. To gain depth. An emotional reaction to gainings (financial or otherwise). Fears and needs regarding our financial or job situation. To have fears concerning making a living. A respite from work. A night job. Quiet job. To profit from other people's fears, neediness, or sadness.

**Moon-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
A focus on emotions in general or on specific emotions. Fear and/or sadness have become normality. A terrible fear that things won't change. The deep need for someone or something one can hold on to. To stabilise one's emotions. Stable emotional life; boring emotional life. Mundane feelings. Sleeping routine, sleeping habits. Very profound sense of stability, or emotionally highly significant foothold. To take a break in order to rest. Boring night life.

**Moon-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Emotional suffering; emotional strain. Something weighs on our emotional wellbeing. Suffering which is very profound, goes down very deep. Painful needs. Fear of pain. The fear that something bad might happen. Acute feeling of responsibility; profound sense of duty. A respite from carrying a burden/responsibilities/suffering. Ideological/dogmatic views on emotions. To not tolerate emotionality. Needs feel like a burden. To bear dark emotions with dignity. Quiet suffering.

**Moon - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)**
Something is so profound that it's hard to grasp. Emotions which aren't clear-cut, or which we don't understand (yet). Emotions are the unknown factor which influences the concern we've asked about. To put a question to rest. A question mark influences the quality of our sleep. What our intuition says is often no clear-cut, and open to interpretation. An unknown factor of huge importance. To wonder about someone's emotions. We haven't rested yet (but we should).
A (possibly genderqueer) person with the attributes of the Moon (see the Moon's keywords).
