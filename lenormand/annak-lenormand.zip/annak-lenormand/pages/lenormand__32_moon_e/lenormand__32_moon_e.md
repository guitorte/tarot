---
title: "lenormand | moon | keywords"
source: https://www.annak-tarot.at/lenormand/32_moon_e.html
---

**MOON 32**

**Keywords**

***Nouns / phrases:***

Moon, night, evening. Autumn, winter. Quiet, rest, respite.
Sleep, dream. Darkness (literally and figuratively speaking); that of which we
are only half-aware; the subconscious. Vague guesses, foreboding, inkling, intuition.
Psyche, soul. Emotions, emotionality. Especially: fears, needs, sadness,
melancholy. Emotional upheaval, trauma. Depth, profoundness, significance, importance.
"Still waters run deep." For some people: attention, recognition/praise,
popularity/fame, imagination, creativity, art, romance, attraction.

 ***Activities:***

To spend an evening/a night with something or someone. To quieten down, rest, sleep,
dream. To darken. To be only half aware; to only guess, have an inkling/foreboding/intuition. To
feel something strongly; to fear, need, weep. To deepen, amplify, be immersed in something.
 ***Attributes:***

Moonlit, nightly, something that happens in the evening. Quiet, restful, restorative;
resting. Tired, sleepy, sleeping. Dark (literally and figuratively speaking), obscure, half-aware,
subconscious. Full of foreboding, intuitive. Emotional, soulful. Fearful, needy, sad, melancholic.
Emotionally upset, traumatised. Deep, profound, significant, important.
 **As a person:**  Person with the above attributes, esp.: someone intuitive, soulful, fearful, needy.
Nocturnal person; person who is tired or asleep. Someone who appears in our dreams. A still
water running deep. Someone who is traumatised. Someone who is very important to the querent.
 **As advice:**
 Take a nap; rest more! Listen to your intuition! It's important! Negatively: Don't get
worked up emotionally!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When it's quiet. After you've rested. Evening, night time; late autumn and winter.

 **See also** the *annakblogs* article [>> So, is the Moon a negative or a positive card?](https://annakblogs.wordpress.com/2018/08/05/moon/)
