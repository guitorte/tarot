---
title: "lenormand | key | comparisons"
source: https://www.annak-tarot.at/lenormand/33_key-comp_e.html
---

key

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Key, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Yes, maybe, no**

|  |  |
| --- | --- |
|  | **Key**: Yes. Acceptance. |
|  | **Crossroads**: Maybe. Ambivalence. |
|  | **Tower**: No. Refusal. |

 **Inclusion and Exclusion**

|  |  |
| --- | --- |
|  | **Key**: To open one's door to others - literally and figuratively speaking. To welcome; to integrate. |
|  | **House**: To not welcome people who are not already familiar; to exclude foreigners or people who do things differently. |
|  | **Tower**: To let no one in. To shut others out emotionally. |

**Frankness vs. Secretiveness**

|  |  |
| --- | --- |
|  | **Key**: Open and upfront. To find access to a secret; to reveal a secret. |
|  | **Garden**: That which everybody knows, that which is visible to all. To come out to the public. |
|  | **Sun**: That which is glaringly obvious. |
|  | **Birds**: To blab a secret. Gossip about a secret. |
|  | **Mice**:Someone secretly does something harmful. |
|  | **Clouds**: To fog over something; something is hidden. |
|  | **Book**: Esoteric knowledge - things only a few initiated people know. |

 **New things**

|  |  |
| --- | --- |
|  | **Key**:To be open to new things; to find out about something. Inspiration. |
|  | **Child**: A curious, playful, possibly naive, approach to new things. Innovation. |
|  | **House**: Conservatism - opposition to innovation. To want things to stay as they are. |
|  | **Anchor**: Nothing new; routine; always the same. |

 **Acceptance**

|  |  |
| --- | --- |
|  | **Key**: Acceptance in the sense that we actively want and allow something to happen. Acceptance in the sense of a welcome. |
|  | **Stork**: Acceptance in the sense that we stop fighting what is happening. The recognition that what is happening is inevitable, and so we go with the flow instead of trying to go against it. |
