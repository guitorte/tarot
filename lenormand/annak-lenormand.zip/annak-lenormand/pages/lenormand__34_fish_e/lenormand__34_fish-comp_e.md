---
title: "lenormand | fish | comparisons"
source: https://www.annak-tarot.at/lenormand/34_fish-comp_e.html
---

fish

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Fish, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Much / Little**

|  |  |
| --- | --- |
|  | **Fish**: Abundance, accumulation. Lots, enough of. Too many/much. |
|  | **Mice**: Scarcity; loss. Few, less of. Not enough. |

 **Wealth**

|  |  |
| --- | --- |
|  | **Fish**: Financial wealth, finances in general. Accumulation, or profit, for their own sake. To work on getting more money/goods. |
|  | **Bear**: Ownership, property. To accumulate wealth as provision for harder times. To look well after things we already have. |
