---
title: "lenormand | fish | combinations"
source: https://www.annak-tarot.at/lenormand/34_fish-komb_e.html
---

**COMBINATIONS WITH THE
FISH**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Fish-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Sudden changes in your working life; to get piled on with more and more work. To feel pressed to be more generous; someone or something is demanding a lot of what is valuable to you. Something makes it necessary for you to change (or impossible not to change) your view on what's valuable.

**Fish-Clover[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
A happy-go-lucky-approach to values - one's own values don't burden, don't pressure (or: they do, but they *shouldn't*). The untroubled life a stable income brings with it. To not take financial issues very seriously, or to think they aren't that important. To spend money on something that offers easy enjoyment; or to spend money freely without thought for the future. An opportunity to profit (not necessarily financially).

**Fish-Ship
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
A change or journey that costs or brings in money. To discover
new values. Valuable discovery. To value adventure. To busily collect new experiences - but to be unwilling or unable to really relish them. To not let to opportunity to make a valuable, special new experience go by unheeded. Adventurous or foolhardy business decisions. International business dealings. International job. A commuter; to commute. Job description that entails travelling a lot. Work-related changes (e.g. to quite you job, or to take a different career path). Journeys of the type "See all of Europe in 10 days!"

**Fish-House
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Rich family, a family who greatly value money or expensive objects. Family/tradition/rules are of great value. Specific valued traditions. To put great stock in following the rules. Family with many members. Lots of rules. Familiar rules, established rules. Established business; family business. To be comfortable around money, to be familiar with financial or business issues. Homemaker; house work. To value comfort, to value familiarity. Low-risk or conventional ways of dealing with finances. To make a living in a way considered "proper".

**Fish-Tree
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Financial stability; to be very secure in one's job. Steady income. Growing wealth. A thriving business, a family business. To be very relaxed about financial issues. To work on something steadily and diligently but without stress or pressuring yourself. To have very down-to earth values; to be pragmatic about money/income.

**Fish-Clouds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Confused values; unclear values. Behind the scenes goings-on in our job/business. Veiled/hidden interests - someone might try to profit by hiding their true motives. Business dealings without a clear sense of direction. Financial or material situation is not clear. To lack guidance in a work-related area. Maybe now it's not a good time to decide on anything to do with job or finances - we don't actually have all the facts or lack understanding in general. To be so tightfisted or greedy, or so obsessed with collecting more of the same, that it clouds our judgement or even borders on mental illness. A hoarder.

**Fish-Snake
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To have a very strong desire to earn a lot of money or to acquire a lot of goods. Extreme greed. To maybe even do immoral things in order to get whatever we want. Or, to be very intelligent about how we start a business or earn our living.

**Fish-Coffin[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To give up a business idea, or to lose one's business. To lose money. To give up the idea of becoming rich. To lose something or someone that meant a whole lot to us. To leave behind one's materialistic ideas. End of greed. To suppress one's greedy nature. Something valuable can be found in the experience of a loss. A loss/ending which turns into a gain. To suppress something in order to profit somewhere else.

**Fish-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To be very generous, to give away gifts or money. To receive a lot of flattery because people want your money (or other things of worth they feel you could give them). To view friendship as currency; to be friendly out of calculation (to gain something).
Bribes (not necessarily financial in nature).

**Fish-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To balance one's accounts; to settle financial affairs; to do one's tax return. To take stock: what do you have, what do you need, what can you spare? To part with money or possessions. Well-deserved profit. To cut away that which is too much.

**Fish-Whip[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To value dispute/argument. Lots of conflicts. Low quality arguments. A fight about financial (or generally material) issues, or about who owes whom (not necessarily *monetary* debts!). Financial retribution/compensation, or: there's a need for balancing/our your accounts with someone in non-financial matters. To pay a penalty - monetary or otherwise. To fine someone. To feel guilty for being rich; to be guilty of closefistedness, or greed.

**Fish-Birds
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Too much noise, too many thoughts, too many worries, too busy. To hecticly accumulate anything and everything, no matter whether one really needs it or not. To be worried or undecided about financial matters. To constantly change one's mind about what is important, or what is worth most. To profit from chaos, from a lack of structure. Finances (or material concerns in general) bother us. The bits and pieces of value hidden within idle chit-chat or within a messy situation.

**Fish-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Little profit. To behave in a way that minimizes one's profit. Inexperience with business, or financial affairs. To start a business. To put high value on having a child. To spend much money on a child. To feel the pressure to give a child lots of things. To be irresponsible with money or goods. To play around with money or business (for good or bad). Too many children. A job that's easily lost / profit which could very easily be lost. To gamble for money.

**Fish-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To be very cautious with finances or business decisions. Self-employment. To work hard on earning one's living. To highly value independence and integrity. To value only that which is of use to oneself. To adapt to the job, to adapt to the harsh laws of economy.

**Fish-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Too much power/influence; too bossy. Extreme possessiveness. To put great value in power. Job that gives authority. Financial issues or job-related issues dominate querent's life. Something or someone that dominates or tries to influence querent's work life, or what they consider valuable. To use money to put pressure on others and dominate them, or, more positively: to use money to provide for less fortunate people. To take charge of one's financial affairs. Someone who helps you settle financial issues. To make a financial investment as provision for the future. Wealth and money has bought you power. Great wealth.

**Fish-Stars
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Wishes and hopes concerning material goods, money, making a profit. A conflict between wanting things, wanting to earn a lot of money, and seeking deeper meaning in life. Too spiritual; too much daydreaming. To make money/wealth an idol. To aspire to something too much. To aspire to wealth. Trust that there will be abundance. Future profit. Imaginary profit; imaginary value. Business vision.
The wish to be financially secure, to not have to worry about making a living. To value spiritual ideas or a spiritual life style. A valuable spiritual insight/experience.

**Fish-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To slowly but profoundly change one's view on economics. One's business (or way of working) slowly transforms. The deep longing to change one's job to something more fulfilling, or more true to one's nature. A change of world view concerning the meaning of material goods. To find great value in a transformation. Greedy by nature. Strong pull towards business, or towards wealth. "Natural" cycles of business - e.g. first you have to invest, then you will profit. Someone gives back money, repays a (non financial) debt. You'll eventually profit greatly from tackling this transition! Profit is happening - but slowly. Accumulation of something is inevitable. Something to do with your job has triggered a transformation in you (could be good or bad).

**Fish-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Money or expensive gifts are viewed as a sign of appreciation or love. Lots of friends - but maybe the quality of these friendships is not that good. To admire people who are rich. Someone looks up to us because of our wealth. To value loyalty. An abundance of loyalty. "Too much" help - inappropriate, unnecessary help. Financial support. Financial dependence. To worship money.

**Fish-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To be a snob who judges people by their income (or possessions). The loneliness that results from being too stingy. An inability to connect with others emotionally because of looking at them only in terms of how they can be used for personal gain. The (felt) importance of presenting one's material successfulness. The great value of alone-time.

**Fish-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Taxes; money which belongs to the whole of society to spend. Public goods. Expensive publication - to make something public at great personal cost. Profitable announcement. To make money by making things public. (Too) much publicity; (too) many people; (too) large group. To value one's reputation. To present as wealthy. A job in public. To profit from teamwork. The mainstream values of a society.

**Fish-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To value challenges. Many problems. Financial concerns; financial issues weigh on
you. Nothing happens financially, no change in work life. Nothing moves in the order situation. challenging job. Hoarding, or being
close-fisted. Overcoming a difficulty will result in great profit in some way. An obstacle to profiting. Wanting to profit is an obstacle.
it.

**Fish-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
A decision concerning financial or material issues. To value differences, to value
diversity, or freedom of choice. Finances influence our decision. Too many alternatives; too much freedom. Different ways we can profit from something; facets of wealth. A different perspective on money, or on values. A job with many facets. To walk down a different path in one's job.

**Fish-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To lose money or goods, or something else which is valuable to us. Something loses it's value (to us). Less profit. Someone is exploiting us or we are exploiting someone else. To profit from other people's plights. Money which is earned dishonestly. Bribery. A dirty job; exhausting job. Burnout. Lack of money, poverty. Too little of one thing, too much of another. To have a lot but still think it's not enough.

**Fish-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To put high value in love or in affectionate behaviour. To have a very materialistic view on loving relationships. To pay for love (not talking prostitution here, more things like "To try to buy someone's affections" by giving them presents.)Or: the give-and-take side of loving relationships. Balance between giving and taking in a loving relationship. To find emotional support at at work. To love your job. A lot of love; too much love (total infatuation?); someone falls in love all the time, with many people, very easily but not profoundly (also works with non-romantic infatuation, or infatuation with ideas or hobbies etc).

**Fish-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Business connection. Financially relevant contract (mortgage
agreement; to give or secure credit) - or a non-financial give/take agreements. A relationship that is dominated by materialistic considerations. More connections; too many connections. Connections we profit from. To seek to profit from a relationship. To value commitment, or reliability. Predictable profit. Shared business interest. Shared values. To profit from strong cohesion.

**Fish-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Wealth of knowledge; lots of facts (but maybe not that
important); to desperately want to have the facts. Education in
the financial field. To seek education for financial gain.
Expensive education - maybe: gaining this knowledge will cost
you. To categorise something as valuable.

**Fish-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Conversation through which one wants to gain something. To profit greatly from (good) communication. To value communication. Financial/business documents; bills. Lots of conversation but the quality maybe isn't that great. Jobs for which communication skills are important. To work on one's communication skills. Too much information. To overshare. Expressions of greed.

**Fish-Man (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Man who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted; valued; cherished, esteemed. Man who is self-employed, working hard. Male business partner. To value men(s opinion, presence etc.). A man values something, cherishes something, is looking for profit.
Capitalist, man with a job to do with money. Man who views love or happiness etc. as something he can buy. To "buy" a man. To profit from a man. Too many men; too much of one man. That which the querent values in a male partner, or in men in general. Traditionally "male" values. To profit from male gender roles or stereotypes.

**Fish-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Woman who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted. Valued; cherished, esteemed. Woman who is self-employed, working hard. Female business partner. To value women(s opinion, presence etc.). A woman values something, cherishes something, is looking for profit.
Capitalist, woman with a job to do with money. Woman who views love or happiness etc. as something she can buy. To "buy" a woman. To profit from a woman. Too many women; too much of one woman. That which the querent values in a female partner, or in women in general. Traditionally "female" values. To profit from female gender roles or stereotypes.

**Fish-Man (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Man who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted; valued; cherished, esteemed. Man who is self-employed, working hard. Male business partner. To value men(s opinion, presence etc.). A man values something, cherishes something, is looking for profit.
Capitalist, man with a job to do with money. Man who views love or happiness etc. as something he can buy. To "buy" a man. To profit from a man. Too many men; too much of one man. That which the querent values in a male partner, or in men in general. Traditionally "male" values. To profit from male gender roles or stereotypes.

**Fish-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Woman who is: fulfilled; has (had) enough, wealthy, expensive (to keep), greedy, tight-fisted. Valued; cherished, esteemed. Woman who is self-employed, working hard. Female business partner. To value women(s opinion, presence etc.). A woman values something, cherishes something, is looking for profit.
Capitalist, woman with a job to do with money. Woman who views love or happiness etc. as something she can buy. To "buy" a woman. To profit from a woman. Too many women; too much of one woman. That which the querent values in a female partner, or in women in general. Traditionally "female" values. To profit from female gender roles or stereotypes.

**Fish-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Complete materialism (sensual pleasure and material objects are all there is). A suggestion that once should value sensual pleasure, the present moment, sex etc. more. To exploit someone sexually. A conflict of quality-over-quantity (e.g. but not necessarily concerning food/sex/other enjoyments). A mature handling of one's work situation or financial affairs. To profit but slowly. Slow work process; high quality work. Intense work effort. To find great pleasure in one's job. Flow experience in one's work.

**Fish-(Virtuous)Lily
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Business ethics. Honest business dealings. To give money for a good cause. To highly value virtuousness. Moral ways of dealing with money. Fair trade and fair trade products. To be extremely frugal, maybe in order to appear virtuous. Too virtuous (too pure, too honest, too prudent, too disciplined etc.) To give/lend to those who need. To give/pay back what was borrowed. To find peace in letting go of money/things; to feel peaceful because one doesn't need more.

**Fish-Sun [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
A LOT of happiness; too much entertainment. To seek lots of enjoyments; bad quality enjoyments. To look for happiness in accumulating money. Optimism concerning profit. Happiness is of great value. To be happy about one's business, or about financial success - to celebrate them. Obvious value. Something which is valuable only at first glance.

**Fish-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
Too many emotions; too emotional. To value emotions/intuition/depth. Someone or something
means a whole lot to us emotionally. To profit from something emotionally. To gain depth. An emotional reaction to gainings (financial or otherwise). Fears and needs regarding our financial or job situation. To have fears concerning making a living. A respite from work. A night job. Quiet job. To profit from other people's fears, neediness, or sadness.

**Fish-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
The key to profit. To profit from openness. To use someone or something only as means to profit. To gain understanding. To discover great wealth or value in something. To stop being stingy with money and spend more. To give presents to others; donations. To share something of value. Don't let this opportunity to break free / gain access / welcome somebody / understand something slip through your fingers! If you're open to *too much*, nothing gets truly close to you. To highly value the present moment.

**Fish-Fish[\*)](https://www.annak-tarot.at/lenormand/star_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To value money/wealth. *Huge* quantities. So much of something it is painfully *too* much. Too much work, too many orders/business dealings etc. Burnout. Finances, work, or profit(ing), play a very dominant role in the querent's life.

**Fish-Anchor [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To be tied down or confined by financial/material problems or considerations. Stable financial situation or job. To gain a foothold in the business world. A life centred around money, valuable possessions, or work. To hold on tightly to what you feel is valuable; inability to let go of anything because you fear you might not have enough left.

**Fish-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
To be the breadwinner (which might feel like a burden). (Too) many responsibilities. Mortgage. Debt - not necessarily in a monetary sense. Your ideology/religion means a lot to you. Wealth/too many possessions/money are a burden. The idea that accumulating money or possessions is the most important thing in life. The struggle of making a daily living. Your job has become a burden. To overwork. To endure suffering/struggles because they might pay off in the end.

**Fish - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)**
It's not clear whether we would profit from X. The unknown factor that plays a major role for whether we profit or not. To wonder about the value of something. Something has value in a way we haven't realised yet. Profit that hasn't been made yet. To value question marks, to value things which don't fit inside the box. The distinct feeling that you mustn't let something slip through your fingers but you don't know what it is exactly you should be holding on to. Too many question-marks, too difficult to pin down.
A (possibly genderqueer) person with the attributes of the Fish (see the Fish's keywords).
