---
title: "lenormand | fish | keywords"
source: https://www.annak-tarot.at/lenormand/34_fish_e.html
---

**FISH 34**

**Keywords**

***Nouns / phrases:***

(High) quantity, (over)abundance, wealth, profit, accumulations,
gainings. Fulfilment. Greed or parsimony, inability to share. Something of value,
something of great worth - not necessarily financially or materially! Finances.
Quantity over quality. Inability to appreciate what one has because it doesn't
seem enough. "Don't let X slip through your fingers!" Business, job, livelihood.
Self-employment.

 ***Activities:***

To profit, accumulate, gain. To fill, fulfil. To grab, be greedy for something.
To value. To put quantity over quality. To work. To run a business. To work for something,
to get a job done; to work too much and care too little about (emotional) health or family, etc.

 ***Attributes:***

(Too) many, (too) much, lots, full, fulfilled; enough. Wealthy, expensive, greedy, tightfisted.
Valuable; cherished, esteemed. Financial. Work-related, labour-intensive; (self)employed.
 **As a person:**  Someone with the above attributes. A (possibly well-established) business person.
Self-employed person. Someone who uses others for personal profit. Workaholic.
 **As advice:**
 Value it more! Get the job done! Seek fulfilment! Or, negatively: Don't be so greedy!
Money/quantity is not everything!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   When it's profitable. When/as long as it fulfils you. When there is plenty of
what's necessary. During work hours or working life.
