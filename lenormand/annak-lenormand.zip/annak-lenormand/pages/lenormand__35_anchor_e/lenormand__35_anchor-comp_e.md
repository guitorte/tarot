---
title: "lenormand | anchor | comparisons"
source: https://www.annak-tarot.at/lenormand/35_anchor-comp_e.html
---

anchor

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Anchor, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Stability**

|  |  |
| --- | --- |
|  | **Anchor**: Stability because of stagnation - because of an adherence to routines, because we are stuck in the same place where nothing ever changes or where we can't change anything. |
|  | **House**: Stability because of regularity - because tradition isn't questioned, habits are fixed, and rules are kept. |
|  | **Tree**: Stability comes from within oneself:, from a sense of inner strength and energetic balance, from a strong sense of belonging. Stable health. |
|  | **Birds**: The opposite of stability and regularity: instability and chaos. |

 **Settling Down**

|  |  |
| --- | --- |
|  | **Anchor**: To stay put; to stick with something or someone. |
|  | **House**: To settle down for good because we feel at home there; to settle for something or someone. |
|  | **Ship**: To be unable to settle down because you're "on the way" still, because of wanderlust, or because of commitment issues. |

**(In)Dependence**

|  |  |
| --- | --- |
|  | **Anchor**: Dependence in the sense of being stuck with something or someone, of being tied to someone or something by practical necessities. |
|  | **Ring**: Dependence in the sense that we're bound by a promise, or because we can't that easily "undo the ties that bind us". |
|  | **Dog**: Dependence - in general, but especially the dependence on the approval and love of others. |
|  | **Snake**: Independence in the sense that we are headstrong and go our own way, even when we have to go alone, and especially when others try to hinder us. |
|  | **Fox**: Independence from others' judgements (moral, aesthetic, political etc.) - to stick with what we have found to be true no matter what it costs. |
|  | **Tower**: The type of independence arising from a lack of close emotional relationships, or from working or living alone. |

**(Foot)hold**

|  |  |
| --- | --- |
|  | **Anchor:** We have foothold in the sense that we are able to maintain a certain status, are holding on to something, or even clinging to something, "hooking into something" like an anchor does into the sea bed. Possibly (not necessarily) an unproductive, negative thing to do. |
|  | **Tree:** We have foothold in the sense that we feel firmly, securely, rooted - because we have, metaphorically speaking, both feet firmly on the ground, or because we have built on a stable foundation. Definitely positive. |
