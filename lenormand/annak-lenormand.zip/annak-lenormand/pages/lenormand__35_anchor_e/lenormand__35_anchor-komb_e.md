---
title: "lenormand | anchor | combinations"
source: https://www.annak-tarot.at/lenormand/35_anchor-komb_e.html
---

**COMBINATIONS WITH THE
ANCHOR**

**Please note** that
the examples below are meant to be just that: examples. They are not in any sense exhaustive. Furthermore,they are constructed of individual meanings I myself use. If you use different keywords than I do your own combined meanings will look quite different. Also, what I did not take into account in these examples is the order of the paired cards (which card is left and which right). Lastly, if you want to learn more about how
to combine two cards' meanings
[>> here](https://www.annak-tarot.at/lenormand/combinations_e.html)
is an explanation of what works for me.

**Anchor-Rider [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/01-rider-extra.jpg)](https://www.annak-tarot.at/lenormand/01_rider_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
What used to be very stable changes drastically. Challenge or change of the status quo. Something or someone breaks the routine. To be freed from confinement. To wait for things to change. To try and hold on to routine when faced with change.

**Anchor-Clover [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/02-clover-extra.jpg)](https://www.annak-tarot.at/lenormand/02_clover_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To be quite comfortable with the status quo; to not feel responsible for changing an unpleasant status quo. Advice: Hold on to that bit of luck/chance! To hold on in vain to something which is fleeting. A little bit of stability which is enjoyable but probably won't last. To not take safety seriously(enough?). The opportunity to get a firm(er) foothold. To be very focused on looking out for opportunities.

**Anchor-Ship [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/03-ship-extra.jpg)](https://www.annak-tarot.at/lenormand/03_ship_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A journey finally comes to an end. To reach one's final destination. Conflict between wanting to leave and wanting to stay. To cling to someone who wants to leave. Something is holding us back from leaving (or from changing something). To change one's routines. To stick with a journey, with exploring something. Everyday life contains a lot of mobility, a lot of exploration, adventure (positive or negative). A safe journey. The feeling that our daily life, life's necessities, make it impossible for us to go exploring, have adventures. A focus on a search, on an exploration, on changes we want to make. Everything revolves around a departure.

**Anchor-House [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/04-house-extra.jpg)](https://www.annak-tarot.at/lenormand/04_house_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Stable family life. "My home is my castle". To make one's home; to take up residence; to establish oneself. To feel confined by tradition (or family). Stay-at-home. One's life is centred around family/home/tradition, maybe too much so. To be unable to leave parental home. To cling to tradition/rules. Established routines. Plans give you safety. Everything is horribly boring because nothing changes, ever.

**Anchor-Tree [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/05-tree-extra.jpg)](https://www.annak-tarot.at/lenormand/05_tree_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Physical restraint/confinement. To focus on health. Obsessive concern with one's body. Nature gives foothold. To take a break in nature. Very strong feeling of safety and stability. Routines (or pauses) dictated by one's nature (e.g. sleeping cycle). Stopping, pausing, helps to replenish one's energy reserves.

**Anchor-Clouds [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/06-clouds-extra.jpg)](https://www.annak-tarot.at/lenormand/06_clouds_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Unclear focus, confusion about what one should focus on. Find the one stable thing within all the confusion and despair and hold on to that! That which gives foothold in times of despair. To be stuck in confusion. To be stuck because it's unclear where else to go/what else to do. Everything revolves around our confusion, or a misunderstanding. Very dull routines; boring everyday life. So safe it's boring.

**Anchor-Snake[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/07-snake-extra.jpg)](https://www.annak-tarot.at/lenormand/07_snake_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To crave safety or stability; everything revolves around ambition (maybe advancing a career) for you. To focus on gaining knowledge/getting sex/getting power. To have a stable goal to work towards. To be so entangled with something you can't break away anymore.

**Anchor-Coffin [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/08-coffin-extra.jpg)](https://www.annak-tarot.at/lenormand/08_coffin_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To be stuck in a grieving state. Everything in one's life revolves around a loss. To be unable to let go of something which really is long over. Support in times of grief. To lose support; to lose one's grip. Loss of focus. To give up something in order to focus on something else.

**Anchor-Bouquet [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/09-bouquet-extra.jpg)](https://www.annak-tarot.at/lenormand/09_bouquet_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Focus on aesthetics. Stable circle of friends. To find safety in social niceties. To stick with pleasantries. To be confined/restricted by having to be nice. Pleasant status quo. Nice, pleasant stop or break. To welcome a break. To make a stay / residence pleasant.

**Anchor-Scythe [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/10-scythe-extra.jpg)](https://www.annak-tarot.at/lenormand/10_scythe_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To end the status quo; to cut off one's fetters; to abruptly untangle oneself from restraints. To break off a relationship with someone who wants a long-term commitment. Sudden end/change of routine. Unexpected, sudden stop. To take stock of the status quo. Deserved/self-inflicted hold-up/a break/residence/boring routine etc.

**Anchor-Whip [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/11-whip-extra.jpg)](https://www.annak-tarot.at/lenormand/11_whip_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A conflict or argument or something abusive is at the centre of one's concern. To hold on to an argument, to conflict. Long-lasting belligerent mood. To be stuck in a conflict. Abusive behaviour in the form of: stalking, possessiveness, physically restraining someone. Focus on shame/guilt/making amends. To be conflicted about a stay/the status quo.

**Anchor-Birds[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/12-birds-extra.jpg)](https://www.annak-tarot.at/lenormand/12_birds_e.html)
![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)**
Circling thoughts, worries which persist. To have ants in one's pants. A hold-up causes impatience, restlessness. Stress/chaos makes it difficult to focus. Inability to settle for one idea, or: to finally stop fidgeting and settle down. Chaotic status quo. That which gives foothold in chaos and stress.

**Anchor-Child [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/13-child-extra.jpg)](https://www.annak-tarot.at/lenormand/13_child_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To be solid as a rock for a child or inexperienced person. If we are the one who is young or inexperienced the Anchor might represent someone who can be our rock. To cling to a child too much; a child is the focus of our life. To think little of a stable life full of routines. Weak hold. Fragile residence (soon we might have to move on again). Weak focus (short attention span). New routine; the beginning of taking up residence, of putting down roots. To restrain one's curiosity/playfulness.

**Anchor-Fox [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/14-fox-extra.jpg)](https://www.annak-tarot.at/lenormand/14_fox_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Stable identity; unchanging self of self. Consistent, strong (self)interest. To hold on to something selfishly, out of self-interest. To be cautious about letting someone hold on to you or confine you too much. To be wary of settling down, tying oneself down.
Everything revolves around oneself; someone who makes everything revolve around them. Better safe than sorry. Safety precautions. Extreme caution; strong need of safety; avoidance of risks.

**Anchor-Bear [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/15-bear-extra.jpg)](https://www.annak-tarot.at/lenormand/15_bear_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A very, very dominant focal point which colours everything else in your life. To focus on power, parenthood, or on parent/teacher/boss. Someone or something who is a very strong, solid, stabilising presence in your life - or whose presence in your life is extremely confining. To life with one's parent(s). To be unable to let go of a parent/teacher/leader - to be unwilling or unable to stand on one's own feet. Confined strengths, bound power. To feel very safe with someone.

**Anchor-Stars [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/16-stars-extra.jpg)](https://www.annak-tarot.at/lenormand/16_stars_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To hold on to hope desperately; to be unhappy with how things are and try to aspire to more. Very strong faith; faith offers a foothold. Focus on one's hopes/dreams. Everything revolves around spirituality. Conflict between wanting to reach for the stars and one's daily routines or obligations. To be stuck in a daydream; to hold on to an illusion. Imaginary safety.

**Anchor-Stork [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/17-stork-extra.jpg)](https://www.annak-tarot.at/lenormand/17_stork_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A slow transformation of the status quo; slowly but surely everything is going to transform - always. The longing for a journey's end; longing for permanent residence (also metaphorically speaking). Focus on transformation. Everything revolves around longing, or a transition. Slow but significant change of routine, of everyday life, to something more fitting to one's inner nature. Following one's inner nature gives stable foothold, a sense of groundedness within oneself. Someone very stable (or clingy) by nature. Transformation or transition is halted, restricted, or put on pause.

**Anchor-Dog [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/18-dog-extra.jpg)](https://www.annak-tarot.at/lenormand/18_dog_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A friend who sticks with you no matter what. Stable friendship. Great loyalty. To stick with someone or something loyally. Someone who is the foothold for a dependent. Extreme dependence - inability to let go because of dependence. A clingy friend. To cling to a friend. Dependence on routines. To feel restricted by loyalty. To be bound to someone or by someone. Someone holds someone on a tight leash. Something hold all our attention. Devoted focus. To not question the status quo.

**Anchor-Tower [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/19-tower-extra.jpg)](https://www.annak-tarot.at/lenormand/19_tower_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
A very strong, unmovable, stable wall of defence. Isolation/loneliness has become normality. To find safety in being unemotional, or stability in solitude. Everything revolves around pride; to focus on achievement. The resident authority. To cling to authority; to look to authorities for stability, for foothold.

**Anchor-Garden [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/20-garden-extra.jpg)](https://www.annak-tarot.at/lenormand/20_garden_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To centre one's life around public opinion / around presentation. A focus on networking. The focus (or the central person) of a network, team, community. Things which stabilise or restrict a society/community/group. Stable culture/society. To be confined by cultural expectations. To present as firm, safe, stable. A lot of daily life takes place in public places. Routine announcements. To make a break/rest at a cafe/park etc.

**Anchor-Mountain [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/21-mountain-extra.jpg)](https://www.annak-tarot.at/lenormand/21_mountain_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Status quo will not change for a long time yet. Status quo is hard to bear. To find it challenging to stay put. An obstacle to settling down. To focus on difficulties. Whole life revolves around a specific problem or difficulties in general. To hold on stubbornly and/or patiently. Persisting silence. Everything revolves around the elephant in the room. No weight loss / continuing weight gain.

**Anchor-Crossroad [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/22-crossroad-extra.jpg)](https://www.annak-tarot.at/lenormand/22_crossroad_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Everything revolves around a decision or a choice. To just circle around the same thing - to always come back to the same crossroads. You have the freedom to leave / change - you just aren't using it! To stick with a choice. To hold on to freedom (to keep the options open). A decision makes one pause - hesitation. To pause before making a decision. Avoiding a decision has made us stuck, unable to move.

**Anchor-Mice [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/23-mice-extra.jpg)](https://www.annak-tarot.at/lenormand/23_mice_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Loss of stability; loss of foothold. Unhealthy status quo. Unhealthy holding on. Holding on is draining. Sneakiness/corruption/rumour is hard to get rid off - it tends to stick. Long-lasting lack of something. To be stuck in poverty. To hold on determinedly to something which is dwindling. To try and keep it together. As advice: "Don't let X be taken away!"

**Anchor-Heart [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/24-heart-extra.jpg)](https://www.annak-tarot.at/lenormand/24_heart_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Stable affection. Long term love relationship. To hold on to a relationship or to a loved one. A very clingy lover. To feel safe with someone. Love is an important foothold. To feel confined/held back by a loved one. Focus on love/compassion/forgiveness. Infatuation so big we can't focus on anything else. To take love for granted. Routine has entered a romantic relationship.

**Anchor-Ring [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/25-ring-extra.jpg)](https://www.annak-tarot.at/lenormand/25_ring_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Everything revolves around a promise, around commitment, around a relationship. To be totally bound, even tied down, by something or someone. A very, very stable and committed relationship. Long-term commitment. A safe connection, a steady link. Very strong attachment. To hold on extremely tightly. Mutual routines. A focus we share with someone. (Someone who is) the stabilising factor of a relationship, or a unit of people.

**Anchor-Book [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/26-book-extra.jpg)](https://www.annak-tarot.at/lenormand/26_book_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To find great safety in knowing the truth. To hold on to what's true even if it costs. To be bound to someone who one shares a certain knowledge with. To focus on one's studies. To focus on the truth. Education brings stability/safety. Everything revolves around the intellect, about intellectual pursuits. To categorise something as safe / stable.

**Anchor-Letter [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/27-letter-extra.jpg)](https://www.annak-tarot.at/lenormand/27_letter_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Steady flow of communication. Communication is the focus in one's life. Everything revolves around a certain information or conversation. A conversation has reached its conclusion and now there is nothing new to say (time to move on / time to act?). Conversation about the status quo. Conversation about what is most important. Restricted conversation; communication is stalled. Expressions of feeling safe / of feeling trapped.

**Anchor-Man (a) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Man who is abiding, has halted, stopped. Long-term male resident. Man is being held up or held back, caught, stuck, confined, restrained. Man who is stable, firm, secure, safe, "solid as rock", focused. Man with very set daily routines, mundane interests. Man we view as normal, ordinary, bland, boring.
Man who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a man; to confine or restrain or hold back a man. The man everything revolves around / everything revolves around men. To focus on a man. Man we share our daily life with. To hold on to, or find security in, traditionally male gender roles. Confining views about masculinity.

**Anchor-Woman (a)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Woman who is abiding, has halted, stopped. Long-term female resident. Woman is being held up or held back, caught, stuck, confined, restrained. Woman who is stable, firm, secure, safe, "solid as rock", focused. Woman with very set daily routines, mundane interests. Woman we view as normal, ordinary, bland, boring.
Woman who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a woman; to confine or restrain or hold back a woman. The woman everything revolves around / everything revolves around women. To focus on a woman. Woman we share our daily life with. To hold on to, or find security in, traditionally female gender roles. Confining views about femininity.

**Anchor-Man (b) [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/28-man2-extra.jpg)](https://www.annak-tarot.at/lenormand/28_man2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Man who is abiding, has halted, stopped. Long-term male resident. Man is being held up or held back, caught, stuck, confined, restrained. Man who is stable, firm, secure, safe, "solid as rock", focused. Man with very set daily routines, mundane interests. Man we view as normal, ordinary, bland, boring.
Man who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a man; to confine or restrain or hold back a man. The man everything revolves around / everything revolves around men. To focus on a man. Man we share our daily life with. To hold on to, or find security in, traditionally male gender roles. Confining views about masculinity.

**Anchor-Woman (b)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/29-woman2-extra.jpg)](https://www.annak-tarot.at/lenormand/29_woman2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Woman who is abiding, has halted, stopped. Long-term female resident. Woman is being held up or held back, caught, stuck, confined, restrained. Woman who is stable, firm, secure, safe, "solid as rock", focused. Woman with very set daily routines, mundane interests. Woman we view as normal, ordinary, bland, boring.
Woman who stays, who sticks with us, clings to us, who can't
let go; a stalker. To cling to a woman; to confine or restrain or hold back a woman. The woman everything revolves around / everything revolves around women. To focus on a woman. Woman we share our daily life with. To hold on to, or find security in, traditionally female gender roles. Confining views about femininity.

**Anchor-(Sensual)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Everything revolves around sensual pleasures/sex/an affair/art. To find great pleasure in the here and now, right where one is are now.
The status quo *can* be changed but only in a slow process. To hold on to pleasure - to be afraid of loss of passion. To be held back (to be restricted) or to hold back sexually. Too much sexual routine. To find safety and stability in sensual experiences. An intense sense of having arrived. A stalker. A lover who clings to you - or you cling to a lover - or both hold on to each other, giving each other great support but maybe also suffocating each other.

**Anchor-(Virtuous)Lily [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/30-lily2-extra.jpg)](https://www.annak-tarot.at/lenormand/30_lily2_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Virtues which have to do with steadfastness: consistency, decidedness, dedication etc. To firmly stick with what you know is right. To focus on certain virtues. To lead a life centred around virtuousness. To be constrained by what one thinks is "proper". To hold on to (find safety in) acting virtuously. To keep someone grounded who desperately needs it. To well-meaningly hold on to something - but maybe it's not helpful. To restrict someone else because of one's own moral considerations. To get detention/grounded/imprisoned for misbehaviour. Compulsion to wash.

**Anchor-Sun
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/31-sun-extra.jpg)](https://www.annak-tarot.at/lenormand/31_sun_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To be happy with the status quo; joyful everyday life. To try to hold on to happiness and ease; to always look on the bright side of life; to be in a state of stable happiness but maybe also superficiality. Celebration of having reached one's final destination. Happy ending.

**Anchor-Moon[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/32-moon-extra.jpg)](https://www.annak-tarot.at/lenormand/32_moon_e.html)![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)**
A focus on emotions in general or on specific emotions. Fear and/or sadness have become normality. A terrible fear that things won't change. The deep need for someone or something one can hold on to. To stabilise one's emotions. Stable emotional life; boring emotional life. Mundane feelings. Sleeping routine, sleeping habits. Very profound sense of stability, or emotionally highly significant foothold. To take a break in order to rest. Boring night life.

**Anchor-Key [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/33-key-extra.jpg)](https://www.annak-tarot.at/lenormand/33_key_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To say "yes" to taking up residence. To allow someone to hold on to us; to allow ourselves to hold on to something. To understand what confines us, or why. Conflict between wanting to break free and being tied down by something. A life centred around understanding, acceptance. The solution lies in sticking with something / taking a break. Liberation from boring routine. To step out of daily life and enter into something new.

**Anchor-Fish [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/34-fish-extra.jpg)](https://www.annak-tarot.at/lenormand/34_fish_e.html)
[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To be tied down or confined by financial/material problems or considerations. Stable financial situation or job. To gain a foothold in the business world. A life centred around money, valuable possessions, or work. To hold on tightly to what you feel is valuable; inability to let go of anything because you fear you might not have enough left.

**Anchor-Anchor[\*)](https://www.annak-tarot.at/lenormand/star_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
Stable routines. Stable everyday life. Routines offer foothold. To cling to routine. Very boring life. A very permanent residence. To stick with what one already knows well. Very ordinary everyday life.

**Anchor-Cross [![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/36-cross-extra.jpg)](https://www.annak-tarot.at/lenormand/36_cross_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To find great stability an safety in religion/ideology. God/Jesus/Buddha etc. as pillar of strength. To cling to dogma. To focus on one's life-task. Status quo, or everyday life, is burdensome. Workday life feels like a (painful) duty. Everything revolves around some kind of suffering. Focus on what's painful.

**Anchor - Wild Card[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/00-wildcard-extra.jpg)](https://www.annak-tarot.at/lenormand/00_wildcard_e.html)[![](https://www.annak-tarot.at/lenormand/pictures/thumbnails/35-anchor-extra.jpg)](https://www.annak-tarot.at/lenormand/35_anchor_e.html)**
To sink one's teeth into a question mark or into something that isn't clear-cut. To focus on the unknown factor. Foothold that we haven't yet found. A person or issue everything revolves around - like the spider in a web - but you haven't realised it yet. Something is holding you back but it's not clear what this something is.
A (possibly genderqueer) person with the attributes of the Anchor (see the Anchor's keywords).
