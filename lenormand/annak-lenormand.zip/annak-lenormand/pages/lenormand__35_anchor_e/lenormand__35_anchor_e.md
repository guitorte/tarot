---
title: "lenormand | anchor | keywords"
source: https://www.annak-tarot.at/lenormand/35_anchor_e.html
---

**ANCHOR 35**

**Keywords**

***Nouns / phrases:***

Stop(up)s, pause, (long-term) residence, abidance. Difficulties
with letting go. Confinement, detention. (Metaphorical) fetters; physical restraint.
Stability, foothold, safety, security, firmness. Focus; someone or something the
querent's life is revolving around. Status quo, routines, everyday life, workday
life.

 ***Activities:***

To stop, pause, take a break. To abide, reside. To stick with something
or someone. To stay put. To hold on, cling to or restrain something or someone.
To feel stuck, confined or held back. To stabilise. To focus, to revolve around.

 ***Attributes:***

Abiding, halted, stopped. Long-term, residing. Held up or held back, caught, stuck,
confined, restrained. Stable, firm, secure, safe, "solid as rock". Focused. Daily, routine, ordinary,
bland, boring.
 **As a person:**  Someone with the above attributes. Someone stable, solid as a rock. Someone who
the querent centres their life around. Person who can't let go, who clings to others. A stalker.
 **As advice:**
 Focus! Stop - hold on...! Don't let go! Negatively: Don't be clingy! Don't get stuck in
routines!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Daily. The status quo is not going to change any time soon. Or: It's not going to
happen - for it is / you are stuck.
