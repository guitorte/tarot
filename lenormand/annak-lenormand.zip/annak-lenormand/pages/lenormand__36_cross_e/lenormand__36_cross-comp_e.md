---
title: "lenormand | cross | comparisons"
source: https://www.annak-tarot.at/lenormand/36_cross-comp_e.html
---

cross

**COMPARISONS: OPPOSITES & SIMILARITIES**

To clarify and deepen my understanding of the Cross, I pondered the following comparisons with similar and/or opposing cards. Maybe my comparisons will inspire you to make your own!

 **Burden**

|  |  |
| --- | --- |
|  | **Cross**: To be burdened with something, e.g. with responsibilities. |
|  | **Clover**: To be unburdened, to be free of pressure. |

 **Religiosity**

|  |  |
| --- | --- |
|  | **Cross**: Religion, with all its dogmata and rules. |
|  | **Stars**: Spirituality; and mysticism. To experience transcendence. |

**What is right and wrong?**

|  |  |
| --- | --- |
|  | **Cross**: Dogmatic approach to morality. Strong beliefs about what's right and what's wrong. Strong adherence to one ideology. Moral absolutism. Intolerance. |
|  | **Crossroad**: To have no dogma - everything is open to discussion. To allow different opinions; to see the good in many different ideas. Moral relativism. Tolerance. |
