---
title: "lenormand | cross | keywords"
source: https://www.annak-tarot.at/lenormand/36_cross_e.html
---

**CROSS 36**

**Keywords**

***Nouns / phrases:***

Ideology (productive or harmful). (Unquestioned) beliefs, convictions.
Dogma, dogmatic thinking and acting, absolutism, intolerance. Indoctrination.
Principles; adherence to principles. Life's work, one's calling, a task or
quest. Fate/destiny, predetermination. Strokes of fate. Duties, responsibilities,
burden. Hardship, exertion, travail, struggle, exhaustion, pain, suffering. Traditionally
also: religion, religiosity.

 ***Activities:***

To believe something "religiously" - very strongly, without questioning it. To convince, or be convinced. To indoctrinate, or proselytize. To make absolute / render something in terms of absolutes. To not tolerate. To adhere to something firmly. To predetermine. To follow one's calling, or work hard. To fulfil a task, or follow a quest. To do one's duty. To take on responsibilities. To be responsible. To carry a burden, or burden someone. To shoulder something. To exert, travail, struggle, hurt, suffer.

 ***Attributes:***

Ideological. Convinced, dogmatic, absolutist, intolerant. Uncritical, unquestioned. Fateful,
predestined. Dutiful, responsible. Burdensome. Laborious, exhausting/exhausted, painful/
in pain.
 **As a person:**  Person with the above attributes. Strong adherent of an ideology/religion. Someone
who is on a quest. Person with a lot of responsibilities. Someone who is a burden for the querent.
Someone who is working (too) hard, suffering. **As advice:**
 No excuses; no ifs, ands, or buts! Do your duty! Pull yourself together! Negatively:
Don't be so dogmatic! Don't be so hard on yourself!

**Time factor [\*)](https://www.annak-tarot.at/lenormand/star-timefactor_e.html) :**   Always, or never. If/when it's supposed to happen - you can't make it happen.
